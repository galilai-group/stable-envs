import argparse, importlib.util, json, time
from pathlib import Path
from unittest.mock import patch
import numpy as np
import torch
from tensordict import TensorDict
import stable_envs as se
from stable_envs.envs import fetch_opengl
from stable_envs.testing.metrics import normalized_mse

p=argparse.ArgumentParser()
p.add_argument('witness');p.add_argument('old_module');p.add_argument('--device',required=True)
p.add_argument('--repeats',type=int,default=12);p.add_argument('--warmups',type=int,default=3)
args=p.parse_args()
spec=importlib.util.spec_from_file_location('stable_envs.envs._fetch_opengl_before_probe',args.old_module)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
with np.load(args.witness) as f:
    expected=f['source_frames'][:,0].copy()
    state=TensorDict({tuple(k.removeprefix('state/0/').split('/')):torch.from_numpy(f[k].copy()) for k in f.files if k.startswith('state/0/')},batch_size=[2])
new_render=fetch_opengl.render
report=[]
for batch in (2,64):
    indices=torch.arange(batch)%2
    states=state[indices].to(args.device)
    source=expected[indices.numpy()]
    with se.make('FetchPush',num_envs=batch,size=64,device=args.device,backend='opengl') as env:
        for label,render in [('direct64',old.render),('source480_resize64',new_render)]:
            with patch.object(fetch_opengl,'render',render):
                def sync():
                    if args.device=='cuda':torch.cuda.synchronize()
                for _ in range(args.warmups):env.render(states)
                sync()
                durations=[]
                for _ in range(args.repeats):
                    sync();start=time.perf_counter();actual=env.render(states);sync()
                    durations.append(time.perf_counter()-start)
                errors=normalized_mse(actual.cpu().numpy(),source)
                row=dict(batch=batch,mode=label,repeats=args.repeats,warmups=args.warmups,
                    seconds_mean=float(np.mean(durations)),seconds_sd=float(np.std(durations,ddof=1)),
                    frames_per_second=batch/float(np.mean(durations)),
                    mse_mean=float(errors.mean()),mse_max=float(errors.max()),raw_seconds=durations)
                report.append(row);print('FETCH_WARM_ROW',json.dumps(row),flush=True)
        result=env.render(states)
        out=torch.empty_like(result)
        returned=env.render(states,out=out)
        assert returned.data_ptr()==out.data_ptr() and torch.equal(result,out)
        if batch==2:
            image=env.render(states,size=96)
            assert tuple(image.shape)==(2,96,96,3)
            image=env.render(states,supersample=2)
            assert tuple(image.shape)==(2,64,64,3)
            print('FETCH_OUTPUT_CONTRACT_PASS',args.device,flush=True)
print('FETCH_WARM_PROBE',json.dumps(report),flush=True)
