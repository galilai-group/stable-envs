import argparse, json, time
import cv2
import numpy as np
import torch
from tensordict import TensorDict
import stable_envs as se
from stable_envs.testing.metrics import normalized_mse

p=argparse.ArgumentParser();p.add_argument('witness');p.add_argument('--device',required=True);args=p.parse_args()
with np.load(args.witness) as f:
    expected=f['source_frames'][:,0].copy()
    state=TensorDict({tuple(k.removeprefix('state/0/').split('/')):torch.from_numpy(f[k].copy()) for k in f.files if k.startswith('state/0/')},batch_size=[2])
with se.make('FetchPush',num_envs=2,size=64,device=args.device,backend='opengl') as env:
    rows=[]
    for size,ss in [(64,1),(64,2),(64,3),(64,4),(480,1)]:
        ts=time.perf_counter()
        result=env.render(state.to(args.device),size=size,supersample=ss).cpu().numpy()
        if size==480:result=np.stack([cv2.resize(x,(64,64)) for x in result])
        rows.append(dict(size=size,supersample=ss,mse=normalized_mse(result,expected).tolist(),wall=time.perf_counter()-ts))
    print('FETCH_SAMPLING_PROBE',json.dumps(rows),flush=True)
