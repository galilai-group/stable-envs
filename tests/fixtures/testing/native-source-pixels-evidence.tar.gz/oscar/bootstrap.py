import os,sys,tarfile,tempfile,subprocess,base64,json,io,platform
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='se-native-pixels-',dir=os.environ.get('TMPDIR','/tmp')))
print('JOB_TEMP',root,'JOB_ID',os.environ['SLURM_JOB_ID'],flush=True)
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|gz') as archive:archive.extractall(root,filter='data')
os.chdir(root)
os.environ.update(PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1',XDG_CACHE_HOME=str(root/'cache'),UV_CACHE_DIR=str(root/'cache/uv'),TRITON_CACHE_DIR=str(root/'cache/triton'),TORCH_EXTENSIONS_DIR=str(root/'cache/torch'),CUDA_CACHE_PATH=str(root/'cache/cuda'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',SDL_VIDEODRIVER='dummy',MUJOCO_GL='egl',PYTHONUNBUFFERED='1')
base='/oscar/scratch/sboughan/venvs/se7-ogb'
profile=root/'profile'
subprocess.run([base+'/bin/python','-m','venv','--without-pip',str(profile)],check=True)
python=str(profile/'bin/python')
subprocess.run(['/oscar/home/sboughan/.local/bin/uv','pip','install','--python',python,'--no-deps','numpy==2.5.3','gymnasium==1.3.0','pygame==2.6.1','pyyaml==6.0.3'],check=True)
(profile/'lib/python3.12/site-packages/base.pth').write_text(base+'/lib/python3.12/site-packages\n')
subprocess.run([python,'-c',"import torch,importlib.metadata as m,json,platform; from pathlib import Path; Path('hardware.json').write_text(json.dumps(dict(host=platform.node(),gpu=torch.cuda.get_device_name(),versions={p:m.version(p) for p in ('torch','numpy','gymnasium','pygame','triton')})))"],check=True)
files=['tests/contracts/test_'+name+'.py' for name in ('state','simulation','task','online','native_acceptance','native_source_pixels')]
status=0
for device in ('cpu','cuda'):
 result=subprocess.run([python,'-m','pytest','-x','-v','-rs',*files,'--contract-profile=native','--contract-device='+device,'--contract-source=/oscar/scratch/sboughan/se-semantic-recovery/swm-reference','--contract-candidate-manifest='+str(root/'candidate-manifest.json'),'--contract-output='+str(root/device),'--junitxml='+str(root/(device+'.xml')),'-o','junit_family=legacy'])
 status=max(status,result.returncode)
 report=json.loads((root/device/'result.json').read_text())
 if report['status']!='PASS' or report['required']!=128 or report['passed']!=128:status=1
 if status:break
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
 for name in ('cpu','cuda','cpu.xml','cuda.xml','hardware.json'):
  if (root/name).exists():archive.add(root/name,arcname=name)
 for p in root.glob('**/failure.npz'):archive.add(p,arcname='failures/'+str(p.relative_to(root)))
print('EVIDENCE_BASE64',base64.b64encode(buffer.getvalue()).decode(),flush=True)
print('NATIVE_PIXELS_EXIT',status,flush=True)
sys.exit(status)
