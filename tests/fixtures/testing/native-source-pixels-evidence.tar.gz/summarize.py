import base64, hashlib, io, json, tarfile, xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path
from stable_envs.testing.evidence import verify_seal
from tests.contracts.conftest import case_map

base=Path('/private/tmp/se-native-pixels-20261006')
run=base/'oscar-norm-v1'
log=(run/'run.log').read_text()
blob=next(line.split(' ',1)[1] for line in log.splitlines() if line.startswith('EVIDENCE_BASE64 '))
assert 'NATIVE_PIXELS_EXIT 0' in log
artifacts=run/'artifacts';artifacts.mkdir()
with tarfile.open(fileobj=io.BytesIO(base64.b64decode(blob)),mode='r:gz') as archive:archive.extractall(artifacts,filter='data')
manifest=json.loads((run/'manifest.json').read_text())
for name,digest in manifest['files'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
summary=dict(baseline_commit=manifest['commit'],scope='Five native classic-control source-pixel regression profiles; no registration promotion or performance certification',batch=2,source_renderer='CPU pygame at native resolution',per_frame_normalized_mse_limit=.001,job_id=next(line.split('JOB_ID ')[1].strip() for line in log.splitlines() if line.startswith('JOB_TEMP ')),hardware=json.loads((artifacts/'hardware.json').read_text()),profiles={},pixel_cases={},tested_files=manifest['files'])
for device in ('cpu','cuda'):
 verify_seal(artifacts/device)
 result=json.loads((artifacts/device/'result.json').read_text())
 required=set(case_map('native',device))
 assert result['status']=='PASS' and result['passed']==result['required']==128
 assert set(result['cases'])==required
 assert all(row['status']=='PASS' for row in result['cases'].values())
 cases=list(ET.parse(artifacts/(device+'.xml')).iter('testcase'))
 assert len(cases)==128 and all(not any(c.find(tag) is not None for tag in ('failure','error','skipped')) for c in cases)
 groups=defaultdict(list)
 for c in cases:
  if 'test_native_source_pixels' not in c.get('classname',''):continue
  props={p.get('name'):p.get('value') for p in c.findall('properties/property')}
  name=c.get('name'); values=dict(frames=int(props['frames']),mse_max=float(props['mse_max']))
  assert props['source_device']=='cpu' and values['mse_max']<=.001
  summary['pixel_cases'][device+'/'+name]=values
  groups[name.split('[')[1].split('-seed')[0]].append(values)
 assert sum(map(len,groups.values()))==56
 summary['profiles'][device]=dict(required=128,passed=128,failed=0,skipped=0,source_commit=result['source']['commit'],source_versions=result['source']['versions'],pixels={name:dict(cases=len(rows),frames=sum(r['frames'] for r in rows),mse_max=max(r['mse_max'] for r in rows)) for name,rows in groups.items()})
summary['artifacts']={name:hashlib.sha256((artifacts/name).read_bytes()).hexdigest() for name in ('cpu/result.json','cuda/result.json','cpu.xml','cuda.xml','hardware.json')}
(run/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['profiles'],indent=2))
