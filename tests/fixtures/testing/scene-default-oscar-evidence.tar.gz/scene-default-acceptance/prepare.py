from pathlib import Path
import subprocess,json,hashlib,tarfile,io,base64,shlex,sys
root=Path(__file__).parent;repo=Path('/private/tmp/stable-envs-scene-review');out=root/sys.argv[1];out.mkdir()
with tarfile.open('/private/tmp/se-cube-default-20261007/source-gate-v4/source.tar.gz') as t:blobs={m.name:t.extractfile(m).read() for m in t if m.isfile() and '__pycache__' not in m.name}
for n in list(blobs):
 if (repo/n).is_file():blobs[n]=(repo/n).read_bytes()
blobs['saved.npz']=Path('/private/tmp/se-cube-default-20261007/scene-diagnostic/cuda/artifacts/probe/states.npz').read_bytes()
blobs['probe.py']=(root/'probe.py').read_bytes()
manifest=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),tracked_dirty=bool(subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo,text=True)),files={n:hashlib.sha256(v).hexdigest() for n,v in blobs.items() if n not in ('manifest.json','required.json')})
blobs['manifest.json']=json.dumps(manifest,indent=2).encode();(out/'manifest.json').write_bytes(blobs['manifest.json'])
with tarfile.open(out/'source.tar.gz','w:gz') as t:
 for n,b in blobs.items():
  m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
bootstrap=Path('/private/tmp/se-cube-default-20261007/baseline-v3/bootstrap.py').read_text()
(out/'bootstrap.py').write_text(bootstrap)
cmd=['srun','--partition=gpu','--qos=norm-gpu','--constraint=a40|a6000|a5000|a5500|geforce3090|l40s','--cpus-per-task=2','--mem=32G','--time=00:20:00','--job-name=se-scene-parity-probe','--gres=gpu:1','python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))','ogbench','cuda']
d=out/'cuda';d.mkdir()
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
(d/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(d/'run.log'))+' 2> '+shlex.quote(str(d/'stderr.log'))+'\n')
