import json
from pathlib import Path
import numpy as np
r=Path(__file__).parent
p=r/'ablation-v1/cuda-general/artifacts/probe'
with np.load('/private/tmp/se-cube-default-20261007/scene-diagnostic/cuda/artifacts/probe/states.npz') as a:source=a['source_frames']
with np.load(p/'all-glass-4.npz') as a:ours=a['frames']
with np.load(p/'opaque-4.npz') as a:seg=a['seg']
err=np.square((ours.astype(float)-source)/255).mean(-1)
geoms=json.loads((p/'geoms.json').read_text());rows=[]
for g in geoms:
 mask=(seg==g['id']).reshape(32,64,4,64,4).mean((2,4))
 v=float(np.mean(mask*err))
 if v:rows.append(dict(**g,mse_contribution=v))
rows.sort(key=lambda a:-a['mse_contribution'])
(r/'geometry-attribution.json').write_text(json.dumps(rows,indent=2)+'\n')
for x in rows[:18]:print(x['id'],x['body'],x['material'],x['moving'],x['alpha'],x['mse_contribution'])
print('global mean MSE',err.mean())
