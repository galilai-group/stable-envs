import inspect,json,time
from pathlib import Path
import numpy as np
import torch
from tensordict import TensorDict
import stable_envs as se
from stable_envs.envs.ogbench import manipulation as core, manipulation_fidelity as fidelity, manipulation_renderer as renderer
from stable_envs.testing.evidence import EvidenceRun

torch.set_num_threads(1)
out=EvidenceRun('probe')
with np.load('saved.npz') as a:
 frames=a['source_frames'].copy()
 states=TensorDict({tuple(json.loads(k[6:])):torch.from_numpy(a[k].copy()) for k in a.files if k.startswith('state/')},[len(frames)]).to('cuda')
source=inspect.getsource(fidelity.draw)
namespace=dict(fidelity.__dict__)
exec(source.replace('if geom in bundle.movers:', 'if True:'), namespace)
all_glass=namespace['draw']
import warp as wp
original_context=core.MW.create_render_context
pattern=[]
def rotated_context(model,**kwargs):
 rc=original_context(model,**kwargs)
 assert rc.use_precomputed_rays
 rays=wp.to_torch(rc.ray)
 width,height=kwargs['cam_res']
 assert width==height and width%2==0
 grid=rays.reshape(height,width,3)
 plane=grid / -grid[...,2:3]
 dx=(plane[0,1,0]-plane[0,0,0]).clone();dy=(plane[1,0,1]-plane[0,0,1]).clone()
 plane[...,0]+=(torch.arange(height,device=grid.device)[:,None]%2-.5)*.5*dx
 plane[...,1]+=(.5-torch.arange(width,device=grid.device)[None,:]%2)*.5*dy
 grid.copy_(plane / torch.linalg.vector_norm(plane,dim=-1,keepdim=True))
 return rc
core.MW.create_render_context=rotated_context

report=[]
with se.make('OGBScene',device='cuda',num_envs=len(states),size=64) as env:
 rs=env.to_render_state(states)
 token,bundle=renderer.configured_bundle('Scene',rs[0].cpu())
 model=bundle.model
 alpha=core.MW.effective_alpha(model)
 geoms=[dict(id=i,name=model.geom(i).name,body=model.body(int(model.geom_bodyid[i])).name,material=model.material(int(model.geom_matid[i])).name if model.geom_matid[i]>=0 else None,rgba=model.geom_rgba[i].tolist(),alpha=float(alpha[i]),group=int(model.geom_group[i]),moving=i in bundle.movers) for i in range(model.ngeom)]
 out.json('geoms.json',geoms)
 for ss in (2,):
  rs['renderer','supersample'][:]=ss
  for label,draw in [('original',fidelity.draw),('all-glass',all_glass)]:
   images=draw(token,bundle,rs,'cuda',64,ss).cpu().numpy()
   errors=np.mean(((images.astype(float)-frames)/255)**2,axis=(1,2,3))
   out.arrays(f'{label}-{ss}.npz',frames=images)
   item=dict(mode=label,supersample=ss,mse_mean=float(errors.mean()),mse_max=float(errors.max()),worst=int(errors.argmax()))
   report.append(item);print(json.dumps(item),flush=True)
 # Independent candidate OpenGL remains a control against the saved source images.
 rs['renderer','supersample'][:]=1
 gl=env.render(rs,backend='opengl').cpu().numpy()
 out.arrays('opengl.npz',frames=gl)
 from stable_envs.envs.ogbench import manipulation_opengl
 from OpenGL import GL
 gl_env,gl_renderer,_,_=manipulation_opengl._renderer('Scene',rs[0].cpu(),64)
 gl_renderer._gl_context.make_current()
 GL.glBindFramebuffer(GL.GL_FRAMEBUFFER,gl_renderer._mjr_context.offFBO)
 samples=int(GL.glGetIntegerv(GL.GL_SAMPLES))
 positions=[np.asarray(GL.glGetMultisamplefv(GL.GL_SAMPLE_POSITION,i)).tolist() for i in range(samples)]
 out.json('sample-positions.json',dict(samples=samples,positions=positions))
 print('GL_SAMPLE_POSITIONS',positions,flush=True)

 report.append(dict(mode='opengl-control',mse_max=float(np.mean(((gl.astype(float)-frames)/255)**2,axis=(1,2,3)).max())))
out.json('result.json',report);out.seal()
