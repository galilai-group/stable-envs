import inspect,json,time
from pathlib import Path
import numpy as np
import torch
from tensordict import TensorDict
import stable_envs as se
from stable_envs.envs.ogbench import manipulation as core, manipulation_fidelity as fidelity, manipulation_renderer as renderer
from stable_envs.testing.evidence import EvidenceRun

torch.set_num_threads(1)
out=EvidenceRun('probe')
with np.load('saved.npz') as a:
 frames=a['source_frames'].copy()
 states=TensorDict({tuple(json.loads(k[6:])):torch.from_numpy(a[k].copy()) for k in a.files if k.startswith('state/')},[len(frames)]).to('cuda')
source=inspect.getsource(fidelity.draw)
namespace=dict(fidelity.__dict__)
exec(source.replace('if geom in bundle.movers:', 'if True:'), namespace)
all_glass=namespace['draw']
report=[]
with se.make('OGBScene',device='cuda',num_envs=len(states),size=64) as env:
 rs=env.to_render_state(states)
 token,bundle=renderer.configured_bundle('Scene',rs[0].cpu())
 model=bundle.model
 alpha=core.MW.effective_alpha(model)
 geoms=[dict(id=i,name=model.geom(i).name,body=model.body(int(model.geom_bodyid[i])).name,material=model.material(int(model.geom_matid[i])).name if model.geom_matid[i]>=0 else None,rgba=model.geom_rgba[i].tolist(),alpha=float(alpha[i]),group=int(model.geom_group[i]),moving=i in bundle.movers) for i in range(model.ngeom)]
 out.json('geoms.json',geoms)
 for ss in (2,4):
  rs['renderer','supersample'][:]=ss
  for label,draw in [('original',fidelity.draw),('all-glass',all_glass)]:
   images=draw(token,bundle,rs,'cuda',64,ss).cpu().numpy()
   errors=np.mean(((images.astype(float)-frames)/255)**2,axis=(1,2,3))
   out.arrays(f'{label}-{ss}.npz',frames=images)
   item=dict(mode=label,supersample=ss,mse_mean=float(errors.mean()),mse_max=float(errors.max()),worst=int(errors.argmax()))
   report.append(item);print(json.dumps(item),flush=True)
  res=64*ss
  raw=renderer._ConfiguredRenderer(token,bundle,'cuda',res,1)
  rgb,seg=raw.raster(rs)
  out.arrays(f'first-{ss}.npz',rgb=rgb.cpu().numpy(),seg=seg.cpu().numpy())
  raw.close()
  key=token+'/fidelity/opaque';raw=renderer._ConfiguredRenderer(key,core.get_bundle(key),'cuda',res,1)
  opaque=raw.draw(rs);ctx=core._context(key,res,32)
  out.arrays(f'opaque-{ss}.npz',rgb=opaque.cpu().numpy(),raw=ctx.bgra[...,[2,1,0]].cpu().numpy(),seg=ctx.seg.cpu().numpy(),reference=fidelity._REFERENCE.get((token,res,'cuda')).cpu().numpy())
  raw.close()
 # Independent candidate OpenGL remains a control against the saved source images.
 rs['renderer','supersample'][:]=1
 gl=env.render(rs,backend='opengl').cpu().numpy()
 out.arrays('opengl.npz',frames=gl)
 report.append(dict(mode='opengl-control',mse_max=float(np.mean(((gl.astype(float)-frames)/255)**2,axis=(1,2,3)).max())))
out.json('result.json',report);out.seal()
