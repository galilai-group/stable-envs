import csv,hashlib,json,shutil,subprocess,sys,tarfile
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
ROOT=Path(__file__).parent;REPO=Path('/private/tmp/stable-envs-scene-review');sys.path.insert(0,str(REPO))
from stable_envs.testing.evidence import EvidenceRun,sha256,verify_seal
candidate=ROOT/'candidate-v1';folder=REPO/'tests/fixtures/testing'
archive_path=folder/'scene-default-oscar-evidence.tar.gz';report_path=folder/'scene-default-oscar-validation.json';csv_path=folder/'scene-default-cuda-performance.csv'
assert not any(p.exists() for p in (archive_path,report_path,csv_path))
manifest=json.loads((candidate/'manifest.json').read_text())
for name,h in manifest['files'].items():
 if name.startswith(('stable_envs/','tests/')):assert sha256(REPO/name)==h,name
changed=subprocess.check_output(['git','diff','--name-only',manifest['commit'],'HEAD','--','stable_envs','tests'],cwd=REPO,text=True).splitlines()
report=dict(status='PASS',scope='Scene default CUDA fidelity with source-aligned four-sample coverage at 64px; complete OGBench source profiles; preserved explicit GPU goldens',baseline_commit=manifest['commit'],candidate_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),candidate_files={p:sha256(REPO/p) for p in changed},source_gates={})
scheduler=(ROOT/'scheduler-final.txt').read_text();jobs={r[0]:r for l in scheduler.splitlines() if len(r:=l.split('|'))>=7}
for job in ('7097647','7097648','7097650','7097651'):assert jobs[job][3:5]==['COMPLETED','0:0'],jobs[job]
report['jobs']=dict(cpu_source='7097647',cuda_source='7097648',benchmark='7097650',a40_regressions='7097651',terminal_evidence='scheduler-final.txt')
for device in ('cpu','cuda'):
 p=candidate/device/'artifacts';seal=verify_seal(p/'evidence');result=json.loads((p/'evidence/result.json').read_text());assert result['status']=='PASS' and result['passed']==result['required']==72
 cases=list(ET.parse(p/'run.xml').iter('testcase'));assert len(cases)==len({(c.attrib['classname'],c.attrib['name']) for c in cases})==72
 registrations={}
 for c in cases:
  assert all(c.find(k) is None for k in ('failure','error','skipped'))
  props={x.attrib['name']:x.attrib['value'] for x in c.findall('properties/property')}
  if 'mse_max' not in props:continue
  name=c.attrib['name'].split('[')[1].split('-seed')[0]
  row=registrations.setdefault(name,dict(pixel_cases=0,frame_comparisons=0,mse_max=0.,backend=props['candidate_backend']))
  row['pixel_cases']+=1;row['frame_comparisons']+=int(props['frames']);row['mse_max']=max(row['mse_max'],float(props['mse_max']))
 assert set(registrations)=={'OGBCube','OGBScene','PointMazeLargeNavigate'}
 assert all(x['pixel_cases']==8 and x['mse_max']<=.001 and x['backend']=='auto' for x in registrations.values())
 report['source_gates'][device]=dict(passed=72,required=72,registrations=registrations,hardware=json.loads((p/'hardware.json').read_text()),seal_files=len(seal),source_commit=result['source']['commit'])
p=candidate/'golden/artifacts';tests=list(ET.parse(p/'regressions.xml').iter('testcase'));assert len(tests)==5 and all(all(t.find(k) is None for k in ('skipped','failure','error')) for t in tests)
hardware=json.loads((p/'hardware.json').read_text());assert hardware['gpu']=='NVIDIA A40'
report['gpu_regressions']=dict(passed=5,tests=[t.attrib['name'] for t in tests],hardware=hardware,scope='Cube and Scene default-resolution batch/chunk/style/nonmutation, followed by three immutable exact golden tests for explicit paths; 257-row chunk boundary')
p=candidate/'benchmark/artifacts';old=json.loads((p/'baseline/probe/result.json').read_text());new=json.loads((p/'probe/result.json').read_text())
for part in ('baseline/probe','probe'):verify_seal(p/part)
with np.load(p/'baseline/probe/states.npz') as a,np.load(p/'probe/states.npz') as b:
 assert set(a.files)==set(b.files)
 for key in a.files:np.testing.assert_array_equal(a[key],b[key])
 source=b['source_frames'].copy()
with np.load(p/'probe/auto-None.npz') as a:errors=np.square((a['frames'].astype(np.float64)-source)/255).mean((1,2,3))
assert len(errors)==32 and errors.max()<=.001
np.testing.assert_allclose([errors.mean(),errors.std(ddof=1),errors.max()],[new[0]['mse_mean'],new[0]['mse_sd'],new[0]['mse_max']],rtol=1e-14,atol=1e-17)
rows=[]
for i,t in enumerate(new[0]['timings']):
 batch=t['batch'];row=dict(env='swm/OGBScene-v0',resolution=64,batch=batch,independent_states=32,warmups=3,timing_samples=6,mse_mean=float(errors.mean()),mse_sd=float(errors.std(ddof=1)),mse_max=float(errors.max()))
 for label,data in [('ours_gpu',new[0]),('source_gpu',new[1]),('previous_default_gpu',old[0])]:
  assert data['timings'][i]['batch']==batch
  seconds=np.array(data['timings'][i]['seconds']);row.update({label+'_fps':batch/seconds.mean(),label+'_fps_sd':float((batch/seconds).std(ddof=1)),label+'_batch_ms_mean':1000*seconds.mean(),label+'_batch_ms_sd':1000*seconds.std(ddof=1)})
 row['speedup_vs_source_gpu']=row['ours_gpu_fps']/row['source_gpu_fps'];row['speedup_vs_previous_default_gpu']=row['ours_gpu_fps']/row['previous_default_gpu_fps'];rows.append(row)
report['performance']=dict(rows=rows,hardware=json.loads((p/'hardware.json').read_text()),mse_threshold=.001,previous_default_mse={k:old[0][k] for k in ('mse_mean','mse_sd','mse_max')},source_and_state_corpora_identical=True,scope='Same RTX3090 allocation, public render plus output synchronization. Rollout, loading, projection, initial transfer and indexing excluded. Large batches repeat 32 independently reached saved States. Source OpenGL loops independently replayed ready instances and returns NumPy images including readback; ours returns CUDA RGB. Not an online or equal-output-destination benchmark. CPU throughput not measured.',statistics='FPS is batch divided by mean batch latency; FPS SD is sample SD of per-trial FPS. All SD use ddof=1; MSE statistics are across independently reached frames.')
report['diagnostics']=[dict(run='ablation-v1/cuda-general',job='7096640',finding='Fixed glass opacity lowers mean but does not bring worst 4x frame below .001; explicit candidate GL exactly matches saved source.'),dict(run='normals-v1/cuda',job='7096730',finding='Mesh corner-normal interpolation worsens MSE; rejected without production changes.'),dict(run='sampling-v1/cuda',job='7096790',finding='Four rotated rays without aligned background: worst .00100826, rejected. Later GL query fails due preexisting source GL error1281; scheduler FAILED retained.'),dict(run='sampling-v2/cuda',job='7096856',finding='Aligning static background samples gives mean .0007680611, worst .0009497399. Queried NVIDIA sample positions agree exactly with the source-derived pattern.')]
report['rendering_change']=dict(samples_per_pixel_per_pass=4,passes=2,sample_positions_bottom_up=[[.375,.125],[.875,.375],[.125,.625],[.625,.875]],static_background='One cached GL bake at 4x, sampled into the matching 2x layout; no per-frame source rendering',transparency='Both fixed and moving glass blended in Scene',rejected='Interpolated mesh normals did not improve the source comparison and were not adopted')
report['local_checks']=dict(unit_passed=15,unit_xml='local.xml',ruff='PASS',documentation_log='docs.log')
report['scope_limits']=['Registration-specific 64px source corpus, not arbitrary Variation or every reachable scene','B1 is slower than source; the new path is slower than the old inaccurate one','Explicit sampling in RenderState is preserved; 1x is not certified by the default 2x result','No all-38 or 1000-independent-frame benchmark refresh','Cube and prior accepted evidence remain unchanged; no golden regeneration']
with csv_path.open('x',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
report['performance']['csv_sha256']=sha256(csv_path)
run=EvidenceRun(ROOT/'accepted-sealed');logs=[]
def copy(src,dst):
 if src.is_dir():
  for p in sorted(src.iterdir()):
   if p.name!='__pycache__':copy(p,dst/p.name)
 elif src.is_file():
  assert not src.is_symlink();dst.parent.mkdir(parents=True,exist_ok=True)
  if src.name=='run.log':
   raw=src.read_bytes();dst.write_bytes(b''.join(line for line in raw.splitlines(keepends=True) if not line.startswith(b'EVIDENCE_BASE64 ')));logs.append(dict(path=str(dst.relative_to(run.root)),original_sha256=hashlib.sha256(raw).hexdigest(),packaged_sha256=sha256(dst)))
  else:shutil.copy2(src,dst)
for mode in ('cpu','cuda','golden','benchmark'):copy(candidate/mode,run.root/'candidate'/mode)
for name in ('source.tar.gz','manifest.json','probe.py','scheduling.txt'):copy(candidate/name,run.root/'candidate'/name)
for info in report['diagnostics']:
 source_dir=ROOT/info['run'];copy(source_dir,run.root/'diagnostics'/info['run'])
 for name in ('manifest.json','bootstrap.py'):copy(source_dir.parent/name,run.root/'diagnostics'/source_dir.parent.name/name)
 with tarfile.open(source_dir.parent/'source.tar.gz') as t:
  body=t.extractfile('probe.py').read();dest=run.root/'diagnostics'/source_dir.parent.name/'probe.py';dest.write_bytes(body)
for name in ('scheduler-final.txt','local.xml','local.log','docs.log','package.py','prepare.py','prepare_gates.py','analyze.py','geometry-attribution.json','sampling.py','sampling-diagnostic.png','upstream_render.py','upstream-render-search.txt'):copy(ROOT/name,run.root/name)
image=folder/'scene-default-comparison.png';report['comparison_image']=dict(path=str(image.relative_to(REPO)),sha256=sha256(image));copy(image,run.root/'comparison.png')
copy(csv_path,run.root/'performance.csv');run.json('transport-log-index.json',logs);run.json('summary.json',report);seal=run.seal()
with archive_path.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as t:t.add(run.root,arcname='scene-default-acceptance')
report['artifact_archive']=dict(path=str(archive_path.relative_to(REPO)),sha256=sha256(archive_path),seal='scene-default-acceptance/SHA256SUMS',seal_files=len(seal))
with report_path.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print('Packaged',archive_path.stat().st_size,'bytes,',len(seal),'sealed files')
print(json.dumps(rows,indent=2))
