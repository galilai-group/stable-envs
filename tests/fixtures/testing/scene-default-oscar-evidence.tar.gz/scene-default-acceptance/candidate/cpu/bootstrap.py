import os,sys,tarfile,tempfile,subprocess,base64,json,io,platform,select
from pathlib import Path
family,device=sys.argv[1:]
root=Path(tempfile.mkdtemp(prefix='se-parallel-pixels-',dir=os.environ.get('TMPDIR','/tmp')))
print('JOB_TEMP',root,'JOB_ID',os.environ['SLURM_JOB_ID'],'FAMILY',family,'DEVICE',device,flush=True)
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|gz') as archive:archive.extractall(root,filter='data')
os.chdir(root)
os.environ.update(PYTHONPATH=str(root),PYTHONDONTWRITEBYTECODE='1',XDG_CACHE_HOME=str(root/'cache'),UV_HTTP_TIMEOUT='30',UV_HTTP_RETRIES='1',UV_CACHE_DIR=str(root/'cache/uv'),WARP_CACHE_PATH=str(root/'cache/warp'),TRITON_CACHE_DIR=str(root/'cache/triton'),TORCH_EXTENSIONS_DIR=str(root/'cache/torch'),CUDA_CACHE_PATH=str(root/'cache/cuda'),MPLCONFIGDIR=str(root/'cache/matplotlib'),MPLBACKEND='Agg',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',LP_NUM_THREADS='1',SDL_VIDEODRIVER='dummy',PYTHONUNBUFFERED='1')
base='/oscar/scratch/sboughan/venvs/se7-ogb'
profile=root/'profile'
subprocess.run([base+'/bin/python','-m','venv','--without-pip',str(profile)],check=True)
python=str(profile/'bin/python')
pins=['numpy==2.2.6', 'gymnasium==1.2.3', 'ogbench==1.2.1', 'mujoco==3.12.0', 'dm-control==1.0.45', 'pyyaml==6.0.3']
subprocess.run(['/oscar/home/sboughan/.local/bin/uv','pip','install','--python',python,*pins],check=True)
(profile/'lib/python3.12/site-packages/base.pth').write_text(base+'/lib/python3.12/site-packages\n/oscar/scratch/sboughan/venvs/se7-rocket/lib/python3.12/site-packages\n')
xvfb=None; read_fd=None
try:
 if device=='cpu':
  os.environ['CUDA_VISIBLE_DEVICES']=''
  if family in ('dmc','fetch','ogbench'):
   os.environ.update(MUJOCO_GL='glfw',PYOPENGL_PLATFORM='glx',LIBGL_ALWAYS_SOFTWARE='1',GALLIUM_DRIVER='llvmpipe')
   read_fd,write_fd=os.pipe()
   with (root/'xvfb.log').open('w') as log:
    xvfb=subprocess.Popen(['Xvfb','-displayfd',str(write_fd),'-noreset','-screen','0','1024x768x24','-nolisten','tcp'],pass_fds=(write_fd,),stdout=log,stderr=subprocess.STDOUT)
   os.close(write_fd)
   if not select.select([read_fd],[],[],15)[0]:raise RuntimeError('Xvfb startup failed')
   display=os.read(read_fd,64).decode().strip()
   if not display.isdigit() or xvfb.poll() is not None:raise RuntimeError('Invalid Xvfb display')
   os.environ['DISPLAY']=':'+display
 else:os.environ.update(MUJOCO_GL='egl',PYOPENGL_PLATFORM='egl')
 subprocess.run([python,'-c',"import torch,importlib.metadata as m,json,platform;from pathlib import Path;Path('hardware.json').write_text(json.dumps(dict(host=platform.node(),gpu=torch.cuda.get_device_name() if torch.cuda.is_available() else None,versions={p:m.version(p) for p in ('torch','numpy','gymnasium','pygame','matplotlib','dm-control','mujoco') if any(d.metadata['Name'].lower()==p for d in m.distributions())})))"],check=True)
 nodes=json.loads((root/'required.json').read_text())[family]
 status=subprocess.run([python,'-m','pytest','-v','-rs',*nodes,'--contract-profile='+family,'--contract-device='+device,'--contract-source=/oscar/scratch/sboughan/se-semantic-recovery/swm-reference','--contract-candidate-manifest='+str(root/'manifest.json'),'--contract-output='+str(root/'evidence'),'--junitxml=run.xml','--basetemp=pytest-temp','-o','junit_family=legacy']).returncode
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
  for name in ('probe','baseline/probe','hardware.json','xvfb.log','evidence','run.xml','pytest-temp','regressions.xml'):
   if (root/name).exists():archive.add(root/name,arcname=name,filter=lambda entry: None if entry.issym() or entry.islnk() else entry)
 durable=Path('/oscar/scratch/sboughan/se-semantic-recovery/scene-parity-20261007')/os.environ['SLURM_JOB_ID']
 try:
  durable.mkdir(parents=True,exist_ok=False)
  (durable/'evidence.tar.gz').write_bytes(buffer.getvalue())
  print('DURABLE_EVIDENCE',durable/'evidence.tar.gz',flush=True)
 except OSError as error:
  print('DURABLE_EVIDENCE_ERROR',str(error),file=sys.stderr,flush=True)
 print('EVIDENCE_BASE64',base64.b64encode(buffer.getvalue()).decode(),flush=True)
 print('SOURCE_PIXELS_EXIT',status,flush=True)
 sys.exit(status)
finally:
 if xvfb is not None:
  xvfb.terminate()
  try:xvfb.wait(timeout=10)
  except subprocess.TimeoutExpired:xvfb.kill();xvfb.wait()
 if read_fd is not None:os.close(read_fd)
