from pathlib import Path
import json,hashlib,tarfile,io,base64,shlex,subprocess
r=Path(__file__).parent;repo=Path('/private/tmp/stable-envs-scene-review');out=r/'candidate-v1';out.mkdir()
with tarfile.open('/private/tmp/se-cube-default-20261007/source-gate-v4/source.tar.gz') as t:b={m.name:t.extractfile(m).read() for m in t if m.isfile() and '__pycache__' not in m.name}
for n in list(b):
 if (repo/n).is_file():b[n]=(repo/n).read_bytes()
b['saved.npz']=Path('/private/tmp/se-cube-default-20261007/scene-diagnostic/cuda/artifacts/probe/states.npz').read_bytes()
probe=Path('/private/tmp/se-cube-default-20261007/probe.py').read_text().replace("c.domain=='Cube'","c.domain=='Scene'").replace("'OGBCube'","'OGBScene'").replace('oracle.OwnedCube','oracle.OwnedScene')
a=probe.index('traces=');z=probe.index('with np.load',a)
probe=probe[:a]+"frames=np.load('saved.npz')['source_frames']\n(out.root/'states.npz').write_bytes(Path('saved.npz').read_bytes())\n"+probe[z:]
probe=probe.replace("[('auto',None),('mjwarp',1),('mjwarp_fidelity',1),('mjwarp_fidelity',2),('opengl',1)]","[('auto',None)]")
b['probe.py']=probe.encode();(out/'probe.py').write_text(probe)
baseline_files=subprocess.check_output(['git','ls-files','stable_envs'],cwd=repo,text=True).splitlines();buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as t:
 for n in baseline_files:
  data=subprocess.check_output(['git','show','53f9ad58:'+n],cwd=repo);m=tarfile.TarInfo(n);m.size=len(data);t.addfile(m,io.BytesIO(data))
b['baseline-code.tar.gz']=buf.getvalue()
m=dict(commit='53f9ad58a5bbfa57cddedc3f55c9d81194d29da1',tracked_dirty=True,files={n:hashlib.sha256(v).hexdigest() for n,v in b.items() if n not in ('manifest.json','required.json')})
b['manifest.json']=json.dumps(m,indent=2).encode();(out/'manifest.json').write_bytes(b['manifest.json'])
with tarfile.open(out/'source.tar.gz','w:gz') as t:
 for n,v in b.items():
  m=tarfile.TarInfo(n);m.size=len(v);t.addfile(m,io.BytesIO(v))
source_bootstrap=Path('/private/tmp/se-cube-default-20261007/source-gate-v4/bootstrap.py').read_text().replace('cube-default-20261007','scene-parity-20261007')
regression_bootstrap=Path('/private/tmp/se-cube-default-20261007/regressions-a40/bootstrap.py').read_text().replace("'tests/gpu/test_ogbench_golden.py','tests/unit/test_fidelity_backends.py::test_cube_fidelity_batch_and_nonmutation'","'tests/unit/test_fidelity_backends.py::test_ogbench_fidelity_batch_and_nonmutation','tests/gpu/test_ogbench_golden.py'")
benchmark_bootstrap=Path('/private/tmp/se-cube-default-20261007/baseline-v3/bootstrap.py').read_text();benchmark_bootstrap=benchmark_bootstrap.replace(" status=subprocess.run([python,'probe.py']).returncode", """ baseline=root/'baseline';baseline.mkdir()
 with tarfile.open(root/'baseline-code.tar.gz') as t:t.extractall(baseline,filter='data')
 for name in ('tests','scripts'):
  import shutil
  shutil.copytree(root/name,baseline/name)
 for name in ('probe.py','saved.npz'):shutil.copy2(root/name,baseline/name)
 status=subprocess.run([python,'probe.py'],cwd=baseline,env=dict(os.environ,PYTHONPATH=str(baseline))).returncode
 if status==0:status=subprocess.run([python,'probe.py']).returncode""").replace("('probe','hardware.json','xvfb.log')","('probe','baseline/probe','hardware.json','xvfb.log')")
for mode,device,bootstrap in [('cpu','cpu',source_bootstrap),('cuda','cuda',source_bootstrap),('golden','cuda',regression_bootstrap),('benchmark','cuda',benchmark_bootstrap)]:
 d=out/mode;d.mkdir();(d/'bootstrap.py').write_text(bootstrap)
 if mode=='cpu':opts=['--partition=batch','--qos=normal','--cpus-per-task=2']
 else:opts=['--partition=gpu','--qos=norm-gpu','--cpus-per-task=1','--gres=gpu:nvidia_a40:1'] if mode=='golden' else ['--partition=gpu','--qos=norm-gpu','--cpus-per-task=2','--gres=gpu:1','--constraint=geforce3090' if mode=='benchmark' else '--constraint=a40|a6000|a5000|a5500|geforce3090|l40s']
 cmd=['srun',*opts,'--mem=32G','--time=00:30:00','--job-name=se-scene-'+mode,'python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))','ogbench',device]
 ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
 (d/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(d/'run.log'))+' 2> '+shlex.quote(str(d/'stderr.log'))+'\n')
