import json
from pathlib import Path
import numpy as np
r=Path(__file__).parent;p=r/'ablation-v1/cuda-general/artifacts/probe'
with np.load('/private/tmp/se-cube-default-20261007/scene-diagnostic/cuda/artifacts/probe/states.npz') as a:source=a['source_frames']
with np.load(p/'first-4.npz') as a:first=a['rgb'].astype(np.float32);first_seg=a['seg']
with np.load(p/'opaque-4.npz') as a:opaque=a['rgb'].astype(np.float32);raw=a['raw'].astype(np.float32);seg=a['seg'];ref=a['reference']
geoms=json.loads((p/'geoms.json').read_text());moving=np.array([False]+[g['moving'] for g in geoms]);opacity=np.array([1.]+[g['alpha'] if 0<g['alpha']<1 else 1 for g in geoms],dtype=np.float32)
ratio=np.clip((np.clip(raw/ref,0,1)-.3)/.7,0,1)
shadows=np.where(moving[seg+1][...,None],opaque,opaque*ratio)
amount=opacity[first_seg+1][...,None]
image=np.where(amount<1,amount*first+(1-amount)*shadows,shadows).reshape(32,64,4,64,4,3)
patterns={'grid16':[(x,y) for x in range(4) for y in range(4)],'rotated4':[(1,0),(3,1),(0,2),(2,3)],'rotated4-flipy':[(1,3),(3,2),(0,1),(2,0)],'grid4':[(0,0),(2,0),(0,2),(2,2)]}
for name,points in patterns.items():
 actual=np.rint(np.stack([image[:,:,y,:,x,:] for x,y in points]).mean(0)).clip(0,255).astype(np.uint8)
 errors=np.square((actual.astype(float)-source)/255).mean((1,2,3))
 print(name,'mean',errors.mean(),'max',errors.max())
 np.savez_compressed(r/(name+'.npz'),frames=actual)
