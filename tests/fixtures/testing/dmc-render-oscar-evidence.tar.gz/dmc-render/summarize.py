import csv,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path('/Users/samib/stable-envs'); root=Path(__file__).parent
sys.path.insert(0,str(repo))
from stable_envs.testing.evidence import verify_seal,sha256
from tests.helpers.reference.profiles import PROFILES
registrations={case.name:case.registration for case in PROFILES['dmc']}
gates={}; benchmarks={}; rows=[]
for device in ('cpu','cuda'):
 run_name='gate-v2' if device=='cpu' else 'gate-v3'
 p=root/run_name/device/'artifacts'
 report=json.loads((p/'evidence/result.json').read_text())
 assert report['status']=='PASS' and report['passed']==report['required']==288
 sealed=verify_seal(p/'evidence')
 candidate=json.loads((p/'evidence/candidate.json').read_text())
 for file,digest in candidate['files'].items():
  if device=='cpu' and file=='stable_envs/render/trackcom_reflection.py':continue
  if file.startswith(('stable_envs/','tests/contracts/','tests/helpers/reference/','tests/unit/','scripts/benchmarks/')):assert sha256(repo/file)==digest,file
 cases=[]
 for case in ET.parse(p/'run.xml').getroot().iter('testcase'):
  assert not any(case.find(kind) is not None for kind in ('failure','error','skipped')),case.attrib
  if not case.get('name').startswith('test_source_rollout_pixels'):continue
  props={v.get('name'):v.get('value') for v in case.findall('properties/property')}
  name=case.get('name').split('[')[1].split('-seed')[0]
  cases.append(dict(registration=registrations[name],mse_max=float(props['mse_max']),frames=int(props['frames'])))
 assert len(cases)==96 and sum(c['frames'] for c in cases)==1536
 assert max(c['mse_max'] for c in cases)<=.001
 gates[device]=dict(required=288,passed=288,pixel_cases=96,frame_comparisons=1536,mse_max=max(c['mse_max'] for c in cases),registrations={reg:dict(pixel_cases=sum(c['registration']==reg for c in cases),mse_max=max(c['mse_max'] for c in cases if c['registration']==reg)) for reg in sorted(registrations.values())},seal_files=len(sealed),hardware=json.loads((p/'hardware.json').read_text()),artifact=f'{run_name}/{device}/artifacts')
 if device=='cpu':
  unit=list(ET.parse(p/'renderer-tests.xml').getroot().iter('testcase'))
  assert not any(c.find('failure') is not None or c.find('error') is not None for c in unit)
  skipped=[c.get('name') for c in unit if c.find('skipped') is not None]
  assert skipped==['test_unknown_device_raises_rather_than_falling_back[mps]'],skipped
  gates[device]['unit_regressions']=dict(passed=len(unit)-len(skipped),skipped=skipped)
 gates[device]['job_id']={'cpu':'7077085','cuda':'7077189'}[device]
 verify_seal(p/'benchmark')
 b=json.loads((p/'benchmark/result.json').read_text());benchmarks[device]=b
 gates[device]['runtime_versions']=b['versions']
 assert b['runner_sha256']==sha256(repo/'scripts/benchmarks/dmc_render.py')
 for r in b['rows']:
  assert r['mse_after']['max']<=.001
  rows.append(dict(env=r['env'],device=device,batch=r['batch'],before_fps=r['before']['fps'],after_fps=r['after']['fps'],after_over_before=r['speedup'],before_seconds_mean=r['before']['seconds_mean'],before_seconds_sd=r['before']['seconds_sd'],after_seconds_mean=r['after']['seconds_mean'],after_seconds_sd=r['after']['seconds_sd'],before_mse_mean=r['mse_before']['mean'],before_mse_sd=r['mse_before']['sd'],before_mse_max=r['mse_before']['max'],after_mse_mean=r['mse_after']['mean'],after_mse_sd=r['mse_after']['sd'],after_mse_max=r['mse_after']['max'],unique_source_states=32,repeats=12,host=b['host'],gpu=b['gpu']))
output=repo/'tests/fixtures/testing/dmc-render-performance.csv'
with output.open('x',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
files=['stable_envs/envs/dmcontrol/_cells.py','stable_envs/envs/dmcontrol/quadruped.py','stable_envs/envs/dmcontrol/trackcom.py','stable_envs/render/cpu3d.py','stable_envs/render/texture_mip.py','stable_envs/render/trackcom_texture.py','stable_envs/render/trackcom_reflection.py','tests/unit/test_cpu3d.py','tests/unit/test_cpu3d_reflections.py','tests/unit/test_texture_mip.py','scripts/benchmarks/dmc_render.py']
report=dict(status='PASS',scope='Five default DMC body-tracking renderer corrections; unchanged per-frame source MSE <=0.001; no API or backend-switch changes',baseline_commit='d4d06216abd56456e7769adcc5dc20a0d46c0a42',source_commit='176d54532b3c0a251a4f509b74f2fdacc143a63d',candidate_files={f:sha256(repo/f) for f in files},source_gates=gates,shared_source_pixel_registrations=30,non_craftax_registrations=38,performance=dict(csv=str(output.relative_to(repo)),comparison='Our renderer before/after on the same device; source throughput not measured',states_per_domain=32,seeds=[17,42],lanes=2,horizon=8,warmups=3,repeats=12,cpu_batches=[1,64],cuda_batches=[1,64,256],timing_scope='Public render of device-resident full States plus output synchronization; includes State packing',excluded='Source rollout, disk loading, initial device transfer, batch indexing and initialization',sampling='Larger batches repeat 32 independently reached States; samples are not 1000 unique frames'),limitations=['Default appearance at 64px is the source gate; separate variation/lifecycle/large-batch obligations remain.','Analytic geometry edges and primary GPU body shadow shading still approximate source rasterization.','Source-style floor mesh interpolation and filtered textures are implemented; bright non-default vertex-color clamping and nonzero ambient on shadow-casting lights retain differences.','Source physics is CPU on both paths. CPU source rendering uses llvmpipe, GPU uses NVIDIA EGL.','Historical visual_fidelity dictionaries retain their old MuJoCo3.11 measurements; maintained acceptance uses pinned MuJoCo3.12.','Earlier failed or cancelled prototype jobs are diagnostic history and not acceptance evidence.','CPU gate-v2 and CUDA gate-v3 differ only in the GPU-only reflection implementation; every CPU implementation/test/benchmark file matches the final candidate. CPU device-honesty regression confirms no Warp/MJWarp runtime is loaded by CPU rendering.'])
(root/'summary-draft.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(gates,indent=2))
