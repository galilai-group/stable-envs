import json,shutil,sys,tarfile
from pathlib import Path
root=Path(__file__).parent;repo=Path('/Users/samib/stable-envs');sys.path.insert(0,str(repo))
from stable_envs.testing.evidence import EvidenceRun,sha256,verify_seal
report=json.loads((root/'summary-draft.json').read_text())
run=EvidenceRun(root/'sealed')
for name in ['baseline',*[f'candidate-v{i}' for i in range(1,8)],'gate-v1','gate-v2','gate-v3']:
 for path in (root/name).rglob('*'):
  if not path.is_file():continue
  dest=run.root/path.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True)
  if path.name=='run.log':dest.write_text('\n'.join(line for line in path.read_text().splitlines() if not line.startswith('EVIDENCE_BASE64'))+'\n')
  else:shutil.copy2(path,dest)
for file in ('scheduler.txt','prepare.py','prepare_gate.py','probe.py','collect.py','summarize.py','package.py','source-mechanisms.json'):
 shutil.copy2(root/file,run.root/file)
for file in ('packed-final-paired.json','shade-opt-results.json','gouraud-local.json'):
 src=Path('/private/tmp/se-dmc-hq-audit')/file
 if src.exists():
  dest=run.root/'local-diagnostics'/file;dest.parent.mkdir(exist_ok=True);shutil.copy2(src,dest)
shutil.copy2(repo/'tests/fixtures/testing/dmc-render-performance.csv',run.root/'performance.csv')
for file in report['candidate_files']:
 dest=run.root/'candidate'/file;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/file,dest)
run.json('summary.json',report);run.seal();verify_seal(run.root)
archive=repo/'tests/fixtures/testing/dmc-render-oscar-evidence.tar.gz'
with archive.open('xb') as stream:
 with tarfile.open(fileobj=stream,mode='w:gz') as tar:tar.add(run.root,arcname='dmc-render')
report['artifact_archive']=dict(path=str(archive.relative_to(repo)),sha256=sha256(archive),seal='dmc-render/SHA256SUMS')
report['scheduler_evidence']='dmc-render/scheduler.txt'
report['source_per_frame_normalized_mse_limit']=.001
with (repo/'tests/fixtures/testing/dmc-render-oscar-validation.json').open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
print(archive,archive.stat().st_size,report['artifact_archive']['sha256'])
