import base64,hashlib,json,shlex,subprocess,tarfile,sys,io
from pathlib import Path
root=Path.cwd();base=Path('/private/tmp/se-dmc-pixels-20261007');out=base/sys.argv[1];out.mkdir()
files=set(json.loads(Path('/private/tmp/se-fetch-readback-20261007/gate-v2/manifest.json').read_text())['files'])
files.discard('fetch_opengl_before_readback.py')
files.update(str(p.relative_to(root)) for folder in ('stable_envs','tests/contracts','tests/helpers/reference') for p in (root/folder).rglob('*.py'))
# Baseline must be the committed checkpoint even while agents edit the worktree.
baseline=sys.argv[1]=='baseline'
blobs={n:subprocess.check_output(['git','show','HEAD:'+n]) if baseline else (root/n).read_bytes() for n in sorted(files) if (root/n).exists() and (not baseline or subprocess.run(['git','cat-file','-e','HEAD:'+n],stderr=subprocess.DEVNULL).returncode==0)}
manifest=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tracked_dirty=not baseline,files={n:hashlib.sha256(v).hexdigest() for n,v in blobs.items()})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','w:gz') as archive:
 for name,data in blobs.items():
  info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
 archive.add(out/'manifest.json',arcname='manifest.json');archive.add(base/'probe.py',arcname='probe.py')
bootstrap=Path('/private/tmp/se-fetch-readback-20261007/gate-v2/bootstrap.py').read_text()
a=bootstrap.index(' integration=subprocess.run');b=bootstrap.index(' buffer=io.BytesIO()',a)
bootstrap=bootstrap[:a]+" status=subprocess.run([python,'probe.py',device]).returncode\n"+bootstrap[b:]
bootstrap=bootstrap.replace("'evidence','run.xml','hardware.json','xvfb.log','pytest-temp','readback-tests.xml','benchmark'","'probe','hardware.json','xvfb.log'")
(out/'bootstrap.py').write_text(bootstrap)
for device in ('cpu','cuda'):
 folder=out/device;folder.mkdir();gpu=device=='cuda'
 cmd=['srun','--partition='+('3090-gcondo' if gpu else 'batch'),'--qos='+('cs-3090-gcondo' if gpu else 'normal'),'--cpus-per-task=2','--mem=24G','--time=00:45:00','--job-name=se-dmc-'+sys.argv[1]+'-'+device]
 if gpu:cmd+=['--gres=gpu:1']
 cmd+=['python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))','dmc',device]
 ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
 (folder/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(folder/'run.log'))+' 2> '+shlex.quote(str(folder/'stderr.log'))+'\n')
print(out)
