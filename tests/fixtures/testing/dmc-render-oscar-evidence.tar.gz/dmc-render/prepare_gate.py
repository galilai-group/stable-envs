import base64,hashlib,json,shlex,subprocess,tarfile,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from tests.contracts.conftest import case_map
repo=Path.cwd();base=Path('/private/tmp/se-dmc-pixels-20261007');out=base/sys.argv[1];out.mkdir()
files=set(json.loads((base/'candidate-v2/manifest.json').read_text())['files'])
files.update(str(p.relative_to(repo)) for folder in ('stable_envs','tests/contracts','tests/helpers/reference','tests/unit') for p in (repo/folder).rglob('*.py'))
files.add('scripts/benchmarks/dmc_render.py')
for name in ('DMCCheetahRun','DMCHopperHop','DMCWalkerWalk'):
 files.add('tests/fixtures/regression/join/step4/states/'+name+'.npz')
files.add('tests/fixtures/semantics/dmc_humanoid/humanoid_walk_swm_176d545_mujoco312.npz')
manifest=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tracked_dirty=True,files={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in sorted(files)})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'required.json').write_text(json.dumps({'dmc':sorted(case_map('dmc'))},indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','w:gz') as tar:
 for name in sorted(files):tar.add(repo/name,arcname=name)
 for name in ('manifest.json','required.json'):tar.add(out/name,arcname=name)
 # A frozen baseline only serves the separately labeled performance comparison.
 tar.add(base/'baseline/source.tar.gz',arcname='baseline-source.tar.gz')
bootstrap=Path('/private/tmp/se-fetch-readback-20261007/gate-v2/bootstrap.py').read_text()
bootstrap=bootstrap.replace(" integration=subprocess.run([python,'-m','pytest','-v','-rs','tests/integration/test_fetch_opengl.py','--junitxml='+str(root/'readback-tests.xml')])", " integration=subprocess.run([python,'-m','pytest','-v','-rs','tests/unit/test_texture_mip.py','tests/unit/test_cpu3d_reflections.py','tests/unit/test_cpu3d_scene.py','tests/unit/test_cpu3d.py','--junitxml='+str(root/'renderer-tests.xml')]) if device=='cpu' else subprocess.CompletedProcess([],0)")
a=bootstrap.index(' if status==0:\n  benchmark=');b=bootstrap.index(' buffer=io.BytesIO()',a)
bootstrap=bootstrap[:a]+''' if status==0:
  baseline=root/'baseline';baseline.mkdir()
  with tarfile.open(root/'baseline-source.tar.gz') as archive:archive.extractall(baseline,filter='data')
  benchmark=subprocess.run([python,'scripts/benchmarks/dmc_render.py','--device',device,'--baseline-root',str(baseline),'--source-root','/oscar/scratch/sboughan/se-semantic-recovery/swm-reference','--output','benchmark'])
  status=benchmark.returncode
'''+bootstrap[b:]
bootstrap=bootstrap.replace("'readback-tests.xml'","'renderer-tests.xml'")
(out/'bootstrap.py').write_text(bootstrap)
for device in ('cpu','cuda'):
 folder=out/device;folder.mkdir();gpu=device=='cuda'
 cmd=['srun','--partition='+('gpu' if gpu else 'batch'),'--qos='+('norm-gpu' if gpu else 'normal'),'--cpus-per-task=2','--mem=32G','--time=01:00:00','--job-name=se-dmc-gate-'+device]
 if gpu:cmd+=['--gres=gpu:1']
 cmd+=['python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))','dmc',device]
 ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
 (folder/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(folder/'run.log'))+' 2> '+shlex.quote(str(folder/'stderr.log'))+'\n')
print(out)
