import json,sys,time
from pathlib import Path
import numpy as np
import torch
import stable_envs as se
from tests.helpers.reference.bridges import load_source
from tests.helpers.reference.profiles import PROFILES
from tests.helpers.reference.dmc_pixels import dmc_trace
load_source(Path('/oscar/scratch/sboughan/se-semantic-recovery/swm-reference'),'dmc')
device=sys.argv[1]
out=Path('probe');out.mkdir()
report=[]
for case in PROFILES['dmc']:
 if case.domain not in ('walker','cheetah','hopper','humanoid','quadruped'):continue
 trace,identity=dmc_trace(case,17,'float32',8,device)
 corpus=torch.stack(trace.states,dim=1).reshape(-1).to(device)
 source=trace.frames.reshape(-1,64,64,3)
 with se.make(case.name,num_envs=2,device=device,size=64) as env:
  for _ in range(2):env.render(corpus)
  frames=env.render(corpus).cpu().numpy()
  error=np.mean(((frames.astype(float)-source)/255)**2,axis=(1,2,3))
  timings={}
  for batch in ((1,16,64) if device=='cpu' else (1,16,64,256)):
   states=corpus[torch.arange(batch,device=device)%len(corpus)]
   env.render(states)
   vals=[]
   for _ in range(6):
    if device=='cuda':torch.cuda.synchronize()
    start=time.perf_counter();env.render(states)
    if device=='cuda':torch.cuda.synchronize()
    vals.append(time.perf_counter()-start)
   timings[batch]={'seconds':vals,'fps':batch/np.mean(vals)}
  row=dict(domain=case.domain,source_identity=identity,mse_mean=float(error.mean()),mse_max=float(error.max()),timing=timings)
  print(json.dumps(row),flush=True);report.append(row)
  arrays={'source':source,'ours':frames,'mse':error}
  arrays.update({'state/'+('/'.join(k) if isinstance(k,tuple) else k):v.cpu().numpy() for k,v in corpus.items(True,True)})
  np.savez_compressed(out/(case.domain+'.npz'),**arrays)
  (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
