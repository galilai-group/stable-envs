import json,re,sys,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).parent;repo=Path('/Users/samib/stable-envs');sys.path.insert(0,str(repo))
from stable_envs.testing.evidence import verify_seal,sha256
from tests.contracts.conftest import case_map
from tests.helpers.reference.profiles import PROFILES
runs={'pusht':'pusht-v2','ogbench':'ogbench-v4','fetch':'fetch-v1'}
gates={};registrations={}; mismatches={}
for family,name in runs.items():
 gates[family]={};mapping={c.name:c.registration for c in PROFILES[family]}
 for device in ('cpu','cuda'):
  d=root/name/device;p=d/'artifacts';r=json.loads((p/'evidence/result.json').read_text())
  assert r['status']=='PASS' and r['passed']==r['required']==len(case_map(family)),(family,device,r['status'])
  assert not r['duplicates'] and not r['missing']
  assert set(r['cases'])==set(case_map(family))
  assert r['source']['commit']=='176d54532b3c0a251a4f509b74f2fdacc143a63d'
  nseal=len(verify_seal(p/'evidence'));candidate=json.loads((p/'evidence/candidate.json').read_text())
  # All mismatches are retained for explicit review; relevant family code must match.
  mismatches[family+'/'+device]=[f for f,v in candidate['files'].items() if sha256(repo/f)!=v]
  assert all(not f.startswith('stable_envs/') or f=='stable_envs/envs/dmcontrol/trackcom.py' for f in mismatches[family+'/'+device]),mismatches[family+'/'+device]
  relevant=[f for f in candidate['files'] if (f.startswith(('tests/contracts/','tests/helpers/reference/')) and (family in f or Path(f).name in ('pixels.py','conftest.py','profiles.py','semantics.py'))) or (f.startswith('stable_envs/') and family in f)]
  for f in relevant:assert sha256(repo/f)==candidate['files'][f],f
  cases=[]
  for t in ET.parse(p/'run.xml').getroot().iter('testcase'):
   assert not any(t.find(k) is not None for k in ('failure','error','skipped')),t.attrib
   if not t.get('name').startswith('test_source_rollout_pixels'):continue
   props={q.get('name'):q.get('value') for q in t.findall('properties/property')}
   env=mapping[t.get('name').split('[')[1].split('-seed')[0]]
   error=float(props['mse_max']);assert error<=.001
   cases.append(dict(env=env,mse_max=error,frames=int(props['frames'])))
  for env in mapping.values():
   rows=[c for c in cases if c['env']==env];assert rows
   registrations.setdefault(env,{})[device]=dict(pixel_cases=len(rows),frame_comparisons=sum(c['frames'] for c in rows),mse_max=max(c['mse_max'] for c in rows))
  job=re.search(r'JOB_ID (\d+)',(d/'run.log').read_text()).group(1)
  assert 'SOURCE_PIXELS_EXIT 0' in (d/'run.log').read_text()
  gates[family][device]=dict(required=r['required'],passed=r['passed'],pixel_cases=len(cases),frame_comparisons=sum(c['frames'] for c in cases),mse_max=max(c['mse_max'] for c in cases),seal_files=nseal,job_id=job,hardware=json.loads((p/'hardware.json').read_text()),versions=r['source']['versions'],artifact=str(p.relative_to(root)))
report=dict(status='PASS',baseline_commit='d5947b65a1a3491ca982104aa100d6c8f06a9f18',source_commit='176d54532b3c0a251a4f509b74f2fdacc143a63d',scope='Maintained independent source-pixel coverage for final eight non-Craftax registrations, with complete family State/simulation/task/online profiles',shared_source_pixel_registrations=38,non_craftax_registrations=38,previous_source_pixel_registrations=30,profiles=gates,registrations=registrations,snapshot_differences=mismatches,per_frame_normalized_mse_limit=.001,backend_scope={'ogbench':'Cube/Scene explicit OpenGL, Maze default','fetch':'explicit OpenGL','pusht':'CPU raster on both output devices'},limitations=['Cube/Scene default fast GPU MJWarp is not covered by this acceptance; a separately retained Cube probe exceeds .001 MSE.','Default appearance at64px, batch2, seeds17/42 and horizons1/8; not universal Variation/lifecycle/throughput certification.','PushT source and candidate rasterize on CPU for both output devices; CUDA proves State/output placement, not native GPU rasterization.','Cube/Scene retain controlled-entropy source scope and independent native field/RNG/task/model witnesses before candidate checkpoint extraction.','PickAndPlace renders disposable independently reset and forward-replayed source branches; source render mutates controller caches, so continuous-render source continuation is a required rejected control, not an equivalence claim.','Prior acceptance evidence remains unchanged. Source pixels are never produced by candidate rendering or by restoring the source from candidate serialization.'])
files=['scripts/benchmarks/online_stepping/ogbench_parallel_source.py','tests/contracts/conftest.py','tests/contracts/test_fetch_source_pixels.py','tests/contracts/test_ogbench_source_pixels.py','tests/contracts/test_pusht_source_pixels.py','tests/helpers/reference/fetch_pixels.py','tests/helpers/reference/pixels.py','tests/helpers/reference/inventory.py','tests/helpers/reference/ogbench_pixels.py','tests/helpers/reference/pusht_pixels.py','tests/unit/test_contract_inventory.py','tests/unit/test_final_source_pixels.py','tests/unit/test_ogbench_source_frames.py']
report['candidate_files']={f:sha256(repo/f) for f in files}
report['snapshot_difference_scope']='Only unrelated DMC tracking renderer optimization may differ in production; all family renderer/adapter and common source-checker files match the accepted snapshots.'
(root/'summary-draft.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(gates,indent=2));print('Snapshot differences',mismatches)
