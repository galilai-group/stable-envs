import json,re,shutil,sys,tarfile
from pathlib import Path
root=Path(__file__).parent;repo=Path('/Users/samib/stable-envs');sys.path.insert(0,str(repo))
from stable_envs.testing.evidence import EvidenceRun,sha256,verify_seal
report=json.loads((root/'summary-draft.json').read_text());assert report['status']=='PASS'
scheduler=(root/'scheduler.txt').read_text()
for g in report['profiles'].values():
 for d in g.values():assert re.search(r'^'+d['job_id']+r'\|COMPLETED\|0:0\|',scheduler,re.M),d['job_id']
run=EvidenceRun(root/'sealed');transports={}
for family,name in {'pusht':'pusht-v2','ogbench':'ogbench-v4','fetch':'fetch-v1'}.items():
 for device in ('cpu','cuda'):
  verify_seal(root/name/device/'artifacts/evidence')
for name in ('pusht-v1','pusht-v2','fetch-v1','ogbench-v1','ogbench-v2','ogbench-v3','ogbench-v4'):
 for p in (root/name).rglob('*'):
  if not p.is_file():continue
  assert not p.is_symlink()
  dest=run.root/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True)
  if p.name=='run.log':
   ls=p.read_text().splitlines();dest.write_text('\n'.join(s for s in ls if not s.startswith('EVIDENCE_BASE64 '))+'\n')
   transports[str(p.relative_to(root))]=dict(original_sha256=sha256(p),packaged_sha256=sha256(dest))
  else:shutil.copy2(p,dest)
for p in root.iterdir():
 if p.is_file() and p.name not in ('summary-draft.json',):shutil.copy2(p,run.root/p.name)
report['scheduler_evidence']='final-source-pixels/scheduler.txt'
report['rejected_runs']={'pusht-v1':'Contact trajectory missed intended collision; deterministic first contact corrected in v2.','ogbench-v1':'Known source cutoff100 left GL1281 before identity query; scoped handling reused from prior accepted source gate.','ogbench-v2':'Default fast CUDA MJWarp failed source MSE; retained as a real renderer gap, not promoted. Explicit OpenGL is accepted scope.','ogbench-v3':'Submission failed SSH authentication; no acceptance evidence.'}
report['backend_scope']={'pusht':'CPU raster with CPU/CUDA State and output delivery','ogbench':'Cube/Scene explicit OpenGL; Maze default backend','fetch':'explicit OpenGL'}
for name,digest in report['candidate_files'].items():
 assert sha256(repo/name)==digest
 dest=run.root/'candidate'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,dest)
run.json('transport-log-index.json',transports);run.json('summary.json',report);run.seal();verify_seal(run.root)
archive=repo/'tests/fixtures/testing/final-source-pixels-oscar-evidence.tar.gz'
with archive.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as tar:tar.add(run.root,arcname='final-source-pixels')
report['artifact_archive']=dict(path=str(archive.relative_to(repo)),sha256=sha256(archive),seal='final-source-pixels/SHA256SUMS')
with (repo/'tests/fixtures/testing/final-source-pixels-oscar-validation.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(archive,archive.stat().st_size)
