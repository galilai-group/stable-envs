import hashlib,json,shutil,sys,tarfile
from pathlib import Path
ROOT=Path(__file__).parent;REPO=Path('/private/tmp/stable-envs-cube-default-review');sys.path.insert(0,str(REPO))
from stable_envs.testing.evidence import EvidenceRun,sha256,verify_seal
folder=REPO/'tests/fixtures/testing';out=folder/'cube-default-oscar-evidence.tar.gz';validation=folder/'cube-default-oscar-validation.json'
assert not out.exists() and not validation.exists()
report=json.loads((ROOT/'summary-draft.json').read_text())
for name,h in report['candidate_files'].items():assert sha256(REPO/name)==h,name
scheduler=(ROOT/'scheduler-final.txt').read_text();rows={r[0]:r for l in scheduler.splitlines() if len(r:=l.split('|'))>=7}
for job in ('7095709','7092268','7095719'):assert rows[job][3:5]==['COMPLETED','0:0'],rows[job]
assert rows['7092266'][3:5]==['FAILED','4:0']
report['jobs']={'cuda_source':'7095709','cpu_source':'7092268','a40_regressions':'7095719','terminal_evidence':'scheduler-final.txt'}
parent=folder/'cube-default-candidate-evidence.tar.gz';parent_report=json.loads((folder/'cube-default-candidate-validation.json').read_text())
assert sha256(parent)==parent_report['archive']['sha256']
report['prior_evidence']=dict(path=str(parent.relative_to(REPO)),sha256=sha256(parent),scope='Immutable pending checkpoint: code/test snapshots, numeric source/baseline/candidate frames, paired timing samples, rejected runs and Scene diagnostics. This new report completes only Cube acceptance.',seal='cube-default-candidate/SHA256SUMS')
run=EvidenceRun(ROOT/'acceptance-sealed');logs=[]
def copy(src,dst):
 if src.is_dir():
  for p in sorted(src.iterdir()):
   if p.name!='__pycache__':copy(p,dst/p.name)
 elif src.is_file():
  assert not src.is_symlink();dst.parent.mkdir(parents=True,exist_ok=True)
  if src.name=='run.log':
   raw=src.read_bytes();dst.write_bytes(b''.join(l for l in raw.splitlines(keepends=True) if not l.startswith(b'EVIDENCE_BASE64 ')))
   logs.append(dict(path=str(dst.relative_to(run.root)),original_sha256=hashlib.sha256(raw).hexdigest(),packaged_sha256=sha256(dst)))
  else:shutil.copy2(src,dst)
for device,source in [('cpu',ROOT/'candidate-v2/cpu/artifacts'),('cuda',ROOT/'source-gate-v4/cuda-general/artifacts'),('a40',ROOT/'regressions-a40/cuda-typed/artifacts')]:
 if device!='a40':verify_seal(source/'evidence')
 copy(source,run.root/'accepted'/device)
for label in ('source-gate-v4','regressions-a40'):
 for name in ('manifest.json','bootstrap.py'):copy(ROOT/label/name,run.root/'snapshots'/label/name)
 source=ROOT/label/'source.tar.gz';member='cube-default-candidate/'+('source-gate-v3' if label=='source-gate-v4' else label)+'/source.tar.gz'
 with tarfile.open(parent) as t:assert hashlib.sha256(t.extractfile(member).read()).hexdigest()==sha256(source)
 report.setdefault('snapshot_references',{})[label]=dict(parent_archive_member=member,sha256=sha256(source))
for label,path in [('source-recovery',ROOT/'source-gate-v4/cuda-general'),('a40',ROOT/'regressions-a40/cuda-typed')]:
 for p in path.iterdir():
  if p.is_file() and p.suffix in ('.log','.sh'):copy(p,run.root/'logs'/label/p.name)
for name in ('scheduler-final.txt','summarize_acceptance.py','package_acceptance.py','oscar-resume-skills.txt','docs-acceptance.log'):copy(ROOT/name,run.root/name)
csv=folder/'cube-default-cuda-performance.csv';copy(csv,run.root/'performance.csv');report['performance']['csv_sha256']=sha256(csv)
report['superseded_runs']=[dict(job='7093278',state='COMPLETED',accepted=False,reason='SSH transport was interrupted; compute-local artifacts were deleted after the allocation ended. Replaced by a fresh complete source profile.'),dict(job='7095610',state='COMPLETED',accepted=False,reason='Constraint a40 allocated an RTX A6000; 1 passed and 3 immutable A40 tests skipped. Replaced with typed gpu:nvidia_a40:1 request.'),dict(job='7095676',state='CANCELLED',accepted=False,reason='Queued on condo GPU group quota; replaced with general-partition source correctness run. Paired performance still uses RTX 3090.') ]
for name in ('a40-nodes.txt','queue-quota-resume.txt','scheduling-detail.txt'):copy(ROOT/name,run.root/'diagnostics'/name)
report['local_tests']['artifact']='prior_evidence:cube-default-candidate/local.xml'
report['wheel']['log']='prior_evidence:cube-default-candidate/wheel-smoke.log'
report['wheel']['distribution_directory']='prior_evidence:cube-default-candidate/dist/'
report['documentation']=dict(status='PASS',command='python -m mkdocs build --strict',log='docs-acceptance.log')
report['scope_limits']=['Only Cube default backend is newly accepted; Scene remains explicit OpenGL in source gate','64px source corpus; no 1000-frame or full 38-registration benchmark claim','Explicit RenderStates retain supplied sampling settings; 1x is not promoted by the 2x result','B1 candidate renderer remains slower than same-device source','Historical pending evidence and immutable golden fixtures are unchanged']
run.json('transport-log-index.json',logs);run.json('summary.json',report);seal=run.seal();verify_seal(run.root)
with out.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as t:t.add(run.root,arcname='cube-default-acceptance')
report['artifact_archive']=dict(path=str(out.relative_to(REPO)),sha256=sha256(out),seal='cube-default-acceptance/SHA256SUMS',seal_files=len(seal))
with validation.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(out,out.stat().st_size,'sealed files',len(seal))
