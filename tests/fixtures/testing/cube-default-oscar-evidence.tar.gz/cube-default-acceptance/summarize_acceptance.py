import csv,json,subprocess,sys
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
ROOT=Path(__file__).parent
REPO=Path('/private/tmp/stable-envs-cube-default-review')
sys.path.insert(0,str(REPO))
from stable_envs.testing.evidence import sha256,verify_seal
run=ROOT/'candidate-v2'
manifest=json.loads((run/'manifest.json').read_text())
changed=subprocess.check_output(['git','diff','--name-only',manifest['commit'],'HEAD'],cwd=REPO,text=True).splitlines()
files={f:manifest['files'][f] for f in changed if f in manifest['files']}
assert len(files)==6,files
for f,h in manifest['files'].items():
 if f.startswith('stable_envs/') or f in files:assert sha256(REPO/f)==h,f
for snapshot in ('source-gate-v4', 'regressions-a40'):
 exported=json.loads((ROOT/snapshot/'manifest.json').read_text())
 for f,h in exported['files'].items():
  if f.startswith(('stable_envs/','tests/')) and '__pycache__' not in Path(f).parts:assert sha256(REPO/f)==h,(snapshot,f)
report=dict(status='PASS',candidate_commit='94f4788bd6d4cad7bff15115ca78a8072a4cc81c',baseline_commit=manifest['commit'],source_commit='176d54532b3c0a251a4f509b74f2fdacc143a63d',scope='Cube default CUDA fidelity at 64px; OGBench shared source contracts; unchanged explicit GPU golden paths',candidate_files=files,source_gates={})
for device in ('cpu','cuda'):
 p=(run/device/'artifacts') if device=='cpu' else (ROOT/'source-gate-v4/cuda-general/artifacts');seal=verify_seal(p/'evidence');result=json.loads((p/'evidence/result.json').read_text())
 assert result['status']=='PASS' and result['passed']==result['required']==72,result
 registrations={}
 cases=list(ET.parse(p/'run.xml').iter('testcase'))
 assert len(cases)==72 and len({(t.attrib['classname'],t.attrib['name']) for t in cases})==72
 for t in cases:
  assert t.find('failure') is None and t.find('error') is None and t.find('skipped') is None
  props={x.attrib['name']:x.attrib['value'] for x in t.findall('properties/property')}
  if 'mse_max' not in props:continue
  name=t.attrib['name'].split('[')[1].split('-seed')[0]
  r=registrations.setdefault(name,dict(pixel_cases=0,frame_comparisons=0,mse_max=0.,backend=props['candidate_backend']))
  r['pixel_cases']+=1;r['frame_comparisons']+=int(props['frames']);r['mse_max']=max(r['mse_max'],float(props['mse_max']))
 assert set(registrations)=={'OGBCube','OGBScene','PointMazeLargeNavigate'}
 assert all(r['pixel_cases']==8 and r['mse_max']<=.001 for r in registrations.values())
 report['source_gates'][device]=dict(required=72,passed=72,registrations=registrations,seal_files=len(seal),hardware=json.loads((p/'hardware.json').read_text()),artifact=str(p.relative_to(ROOT)))
p=ROOT/'regressions-a40/cuda-typed/artifacts';regress=list(ET.parse(p/'regressions.xml').iter('testcase'))
assert len(regress)==4 and all(not any(t.find(k) is not None for k in ('skipped','error','failure')) for t in regress)
hardware=json.loads((p/'hardware.json').read_text());assert hardware['gpu']=='NVIDIA A40',hardware
report['gpu_regressions']=dict(hardware=hardware,artifact='regressions-a40/cuda-typed/artifacts',passed=4,tests=[t.attrib['name'] for t in regress],scope='Three exact explicit backend golden images (257 rows), plus Cube batch/chunk/style/nonmutation at default resolution')
p=run/'cuda/artifacts'
for prefix in ('baseline/probe','probe'):verify_seal(p/prefix)
old=json.loads((p/'baseline/probe/result.json').read_text());new=json.loads((p/'probe/result.json').read_text())
lookup=lambda rows,backend,ss:next(r for r in rows if r['backend']==backend and r['supersample']==ss)
for backend,ss in [('mjwarp',1),('mjwarp_fidelity',1),('mjwarp_fidelity',2)]:
 with np.load(p/f'baseline/probe/{backend}-{ss}.npz') as a,np.load(p/f'probe/{backend}-{ss}.npz') as b:np.testing.assert_array_equal(a['frames'],b['frames'])
with np.load(p/'baseline/probe/states.npz') as a,np.load(p/'probe/states.npz') as b:
 assert set(a.files)==set(b.files)
 for k in a.files:np.testing.assert_array_equal(a[k],b[k])
rows=[];candidate=lookup(new,'auto',None);previous=lookup(old,'auto',None);fid=lookup(old,'mjwarp_fidelity',2);source=lookup(new,'source-opengl',1)
with np.load(p/'probe/auto-None.npz') as a,np.load(p/'probe/states.npz') as b:
 mse=np.square((a['frames'].astype(np.float64)-b['source_frames'].astype(np.float64))/255).mean(axis=(1,2,3))
 assert mse.shape==(32,)
 np.testing.assert_allclose([mse.mean(),mse.std(ddof=1),mse.max()],[candidate['mse_mean'],candidate['mse_sd'],candidate['mse_max']],rtol=1e-14,atol=1e-17)
for i,t in enumerate(candidate['timings']):
 b=t['batch'];r=dict(env='swm/OGBCube-v0',resolution=64,batch=b,independent_states=32,warmups=3,timing_samples=6,mse_mean=candidate['mse_mean'],mse_sd=candidate['mse_sd'],mse_max=candidate['mse_max'])
 for label,data in [('ours_gpu',candidate),('source_gpu',source),('previous_default_gpu',previous),('previous_fidelity_gpu',fid)]:
  samples=np.array(data['timings'][i]['seconds']);assert data['timings'][i]['batch']==b
  r.update({label+'_fps':b/samples.mean(),label+'_fps_sd':float((b/samples).std(ddof=1)),label+'_batch_ms_mean':1000*samples.mean(),label+'_batch_ms_sd':1000*samples.std(ddof=1)})
 r['speedup_vs_source_gpu']=r['ours_gpu_fps']/r['source_gpu_fps'];r['speedup_vs_previous_default_gpu']=r['ours_gpu_fps']/r['previous_default_gpu_fps'];r['speedup_vs_previous_fidelity_gpu']=r['ours_gpu_fps']/r['previous_fidelity_gpu_fps']
 rows.append(r)
report['performance']=dict(statistics='FPS is batch divided by mean batch latency; FPS SD is the sample SD of per-trial FPS. Latency SD uses ddof=1. MSE mean/SD/max summarize per-frame normalized RGB MSE over the 32 independently reached States.',hardware=json.loads((run/'cuda/artifacts/hardware.json').read_text()),rows=rows,scope='Public render of saved RenderStates, warmed, synchronized; disk/rollout/projection/initial transfer/indexing excluded. Source public OpenGL render loops over independently replayed ready source instances; returned NumPy images include source readback. Candidate returns CUDA RGB. Both use the same GPU allocation. Large batches repeat 32 independently reached States; this is not 1000 independent frames.',mse_threshold=.001,previous_default_mse=dict(mean=previous['mse_mean'],sd=previous['mse_sd'],max=previous['mse_max']),explicit_paths_pixel_identical=True,source_and_state_corpora_identical=True)
report['benchmark_job']=dict(id='7092266',state='FAILED',exit='4:0',reason='Benchmark and source suite completed and sealed; subsequent unrelated regression collection failed because export omitted common.py. Acceptance uses standalone source and A40 regression jobs.',artifact='candidate-v2/cuda/artifacts')
report['local_tests']=dict(passed=28,artifact='local.xml')
report['wheel']=dict(status='PASS',scope='Installed-wheel PushT smoke outside checkout with preinstalled dependencies; not a clean dependency-resolution or all-family runtime gate',artifacts={p.name:sha256(p) for p in (ROOT/'dist').iterdir()},log='wheel-smoke.log',archive_audit='159 package modules, metadata, licenses and sdist sources')
(ROOT/'summary-draft.json').write_text(json.dumps(report,indent=2)+'\n')
out=REPO/'tests/fixtures/testing/cube-default-cuda-performance.csv'
with out.open('x') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(report['source_gates'],indent=2));print(json.dumps(rows,indent=2))
