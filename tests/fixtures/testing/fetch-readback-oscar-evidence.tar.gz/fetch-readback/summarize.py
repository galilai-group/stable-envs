import hashlib,json,re,sys,tarfile,shutil,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/samib/stable-envs')
sys.path.insert(0,str(repo))
from stable_envs.testing.evidence import verify_seal,sha256

source_gates={}
for device,name in (('cpu','gate-v1'),('cuda','gate-v2')):
 p=root/name/device/'artifacts'
 if not (p/'evidence/result.json').exists():raise SystemExit('Waiting for '+device+' source gate')
 result=json.loads((p/'evidence/result.json').read_text())
 assert result['status']=='PASS' and result['passed']==result['required']==336
 sealed=verify_seal(p/'evidence')
 candidate=json.loads((p/'evidence/candidate.json').read_text())
 for file,digest in candidate['files'].items():
  if file.startswith(('stable_envs/','tests/contracts/','tests/helpers/reference/')):assert sha256(repo/file)==digest,file
 pixels=[]
 for case in ET.parse(p/'run.xml').getroot().iter('testcase'):
  if not case.get('name').startswith('test_source_rollout_pixels'):continue
  assert not any(case.find(kind) is not None for kind in ('failure','error','skipped'))
  props={v.get('name'):v.get('value') for v in case.findall('properties/property')}
  assert props['candidate_backend']=='opengl'
  pixels.append(dict(registration='swm/'+case.get('name').split('[')[1].split('-seed')[0]+'-v3',mse_max=float(props['mse_max']),frames=int(props['frames'])))
 assert len(pixels)==144 and sum(p['frames'] for p in pixels)==2304
 assert max(p['mse_max'] for p in pixels)<=.001
 source_gates[device]=dict(required=336,passed=336,pixel_cases=144,frame_comparisons=2304,mse_max=max(p['mse_max'] for p in pixels),registrations={reg:dict(cases=sum(p['registration']==reg for p in pixels),mse_max=max(p['mse_max'] for p in pixels if p['registration']==reg)) for reg in sorted({p['registration'] for p in pixels})},seal_files=len(sealed),hardware=json.loads((p/'hardware.json').read_text()),artifact=f'{name}/{device}/artifacts')

regressions={}
for device,name in (('cpu','cpu-tests-v3'),('cuda','validation-v3')):
 p=root/name/device/'artifacts';suite=ET.parse(p/'readback-tests.xml').getroot()[0]
 assert all(suite.get(k)=='0' for k in ('errors','failures','skipped')) and suite.get('tests')=='5'
 values=[json.loads(prop.get('value')) for prop in suite.findall('testcase/properties/property') if prop.get('name').startswith('resize_')]
 assert len(values)==28 and max(v['max_channel'] for v in values)<=2
 regressions[device]=dict(passed=5,max_channel=max(v['max_channel'] for v in values),mse_max=max(v['mse'] for v in values),hardware=json.loads((p/'hardware.json').read_text()),artifact=f'{name}/{device}/artifacts')

report=dict(status='PASS',scope='Fetch high-fidelity OpenGL resize/readback optimization; no registration promotions or API changes',baseline_commit='a2f8f8203b0db135f794e72a6ae831969c7f7379',candidate_files={f:sha256(repo/f) for f in ('stable_envs/envs/fetch_opengl.py','tests/integration/test_fetch_opengl.py','scripts/benchmarks/fetch_readback.py')},source_gates=source_gates,renderer_regressions=regressions,performance=dict(csv='tests/fixtures/testing/fetch-readback-performance.csv',baseline='previous library high-fidelity implementation, not the source simulator',cpu_artifact='validation-v2/cpu/artifacts/benchmark',cuda_artifact='validation-v3/cuda/artifacts/benchmark',states_per_scene=1024,warmups=3,measurements_per_implementation=12,cpu_batches=[1,64],cuda_batches=[1,64,256],fps='frames / mean batch latency',sd='sample SD of batch latency',frames_per_cell='batch * 12; B64 covers 768 distinct saved States, B256 covers all 1024 three times'),notes=['Source profile covers 12 registrations for State/simulation/task/online-State, and nine Reach/Push/Slide registrations for source pixels. PickAndPlace source-pixel exclusion remains unchanged.','CPU source gate job includes an earlier integration-test failure from an inconsistent 1x1 MSE bound; the independently sealed 336-case source profile passes. Final integration tests pass in cpu-tests-v3.','Earlier GPU integration tests found up to two channel levels of interpolation/quantization difference on L40S. Final regression limits are max channel error <=2 and RMS channel error <=1; the source MSE limit remains 0.001.','The full 480px raster and MSAA remain; final-sized chunks pass through host memory before CUDA output upload. Explicit supersample>1 retains the previous path.','CPU and CUDA timings are same-device paired before/after measurements; CPU and GPU hardware differ. Single-frame timing is noisier; all raw samples are preserved.'])
(root/'summary-draft.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(source_gates,indent=2))
