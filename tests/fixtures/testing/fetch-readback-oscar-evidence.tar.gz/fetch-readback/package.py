import json, shutil, sys, tarfile
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/samib/stable-envs')
sys.path.insert(0,str(repo))
from stable_envs.testing.evidence import EvidenceRun,sha256,verify_seal
report=json.loads((root/'summary-draft.json').read_text())
run=EvidenceRun(root/'sealed')
for name in ('gate-v1','gate-v2','validation-v2','validation-v3','cpu-tests-v3','probe-v1','probe-v2'):
 src=root/name
 for path in src.rglob('*'):
  if not path.is_file():continue
  rel=path.relative_to(root)
  dest=run.root/rel
  dest.parent.mkdir(parents=True,exist_ok=True)
  if path.name=='run.log':
   dest.write_text('\n'.join(line for line in path.read_text().splitlines() if not line.startswith('EVIDENCE_BASE64'))+'\n')
  else:shutil.copy2(path,dest)
for file in ('scheduler.txt','collect.py','summarize.py','package.py'):
 shutil.copy2(root/file,run.root/file)
shutil.copy2('/private/tmp/fetch_opengl_before_readback.py',run.root/'baseline.py')
shutil.copy2(repo/'tests/fixtures/testing/fetch-readback-performance.csv',run.root/'performance.csv')
for file in report['candidate_files']:
 dest=run.root/'candidate'/file
 dest.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(repo/file,dest)
run.json('summary.json',report)
run.seal()
verify_seal(run.root)
archive=repo/'tests/fixtures/testing/fetch-readback-oscar-evidence.tar.gz'
with archive.open('xb') as stream:
 with tarfile.open(fileobj=stream,mode='w:gz') as tar:tar.add(run.root,arcname='fetch-readback')
report['artifact_archive']={'path':str(archive.relative_to(repo)),'sha256':sha256(archive),'seal':'fetch-readback/SHA256SUMS'}
report['scheduler_evidence']='fetch-readback/scheduler.txt'
report['source_commit']='176d54532b3c0a251a4f509b74f2fdacc143a63d'
report['source_per_frame_normalized_mse_limit']=.001
out=repo/'tests/fixtures/testing/fetch-readback-oscar-validation.json'
with out.open('x') as stream:stream.write(json.dumps(report,indent=2)+'\n')
print(archive,archive.stat().st_size,report['artifact_archive']['sha256'])
