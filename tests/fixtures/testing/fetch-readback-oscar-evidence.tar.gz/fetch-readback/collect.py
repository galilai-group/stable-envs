from pathlib import Path
import base64,hashlib,io,json,tarfile
root=Path(__file__).parent
for run in ('gate-v1','gate-v2','validation-v2','validation-v3','cpu-tests-v3'):
 for device in ('cpu','cuda'):
  p=root/run/device
  if not (p/'run.log').exists():continue
  evidence=[line.split(' ',1)[1] for line in (p/'run.log').read_text().splitlines() if line.startswith('EVIDENCE_BASE64 ')]
  if not evidence:continue
  assert len(evidence)==1
  data=base64.b64decode(evidence[0]); digest=hashlib.sha256(data).hexdigest()
  if (p/'artifacts.sha256').exists():assert (p/'artifacts.sha256').read_text()==digest
  else:
   (p/'artifacts').mkdir()
   with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:t.extractall(p/'artifacts',filter='data')
   (p/'artifacts.sha256').write_text(digest)
  print(run,device,'collected')
  benchmark=p/'artifacts/benchmark/result.json'
  if benchmark.exists():
   report=json.loads(benchmark.read_text()); print('hardware',report['host'],report['gpu'])
   for row in report['rows']:
    before=row['measurements']['baseline']['fps'];after=row['measurements']['candidate']['fps']
    print(row['scene'],row['batch'],round(before,1),round(after,1),round(after/before,3),'mse',row['mse_max_vs_baseline'])
