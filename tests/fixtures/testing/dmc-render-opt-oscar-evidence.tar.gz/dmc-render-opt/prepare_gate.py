import base64, hashlib, io, json, shlex, subprocess, sys, tarfile
from pathlib import Path
repo=Path.cwd();sys.path.insert(0,str(repo))
from tests.contracts.conftest import case_map
root=Path('/private/tmp/se-dmc-opt-20261007');out=root/sys.argv[1];out.mkdir()
files=set(json.loads((root/'candidate-v2/manifest.json').read_text())['files'])
files.update(str(p.relative_to(repo)) for folder in ('stable_envs','tests/contracts','tests/helpers/reference','tests/unit') for p in (repo/folder).rglob('*.py'))
files.add('tests/integration/test_dmc_trackcom_batching.py')
files.add('tests/fixtures/regression/join/step6/raycast3d/experiments/r6_kind_cost.json')
files.add('tests/fixtures/regression/join/step7/dmc-quadruped/phase1/cpu_oscar/kind_cost_ellipsoid.json')
for folder in ('dmc_continuation','dmc_humanoid','dmc_aligned'):
 files.update(str(p.relative_to(repo)) for p in (repo/'tests/fixtures/semantics'/folder).glob('*.npz'))
blobs={f:(repo/f).read_bytes() for f in sorted(files) if (repo/f).exists()}
manifest=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tracked_dirty=True,files={n:hashlib.sha256(v).hexdigest() for n,v in blobs.items()})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');nodes=sorted(case_map('dmc'));(out/'required.json').write_text(json.dumps({'dmc':nodes},indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','w:gz') as tar:
 for f,data in blobs.items():
  info=tarfile.TarInfo(f);info.size=len(data);tar.addfile(info,io.BytesIO(data))
 for f in ('manifest.json','required.json'):tar.add(out/f,arcname=f)
 tar.add(root/'baseline/source.tar.gz',arcname='baseline-source.tar.gz')
bootstrap=Path('/private/tmp/se-dmc-pixels-20261007/gate-v3/bootstrap.py').read_text()
a=bootstrap.index(' integration=subprocess.run');b=bootstrap.index('\n nodes=',a)
regressions=['tests/unit/test_texture_mip.py','tests/unit/test_cpu3d_reflections.py','tests/unit/test_cpu3d_scene.py','tests/unit/test_cpu3d.py','tests/unit/test_cpu3d_shadow_rays.py']
regressions+=sorted(str(p.relative_to(repo)) for p in (repo/'tests/unit').glob('test_raycast*.py'))
bootstrap=bootstrap[:a]+" integration=subprocess.run([python,'-m','pytest','-v','-rs',*("+repr(regressions)+" if device=='cpu' else ['tests/integration/test_dmc_trackcom_batching.py']),'--junitxml='+str(root/'renderer-tests.xml')])"+bootstrap[b:]
if sys.argv[1] in ('gate-v3','gate-v4'):
 a=bootstrap.index(' nodes=');b=bootstrap.index(' buffer=io.BytesIO()',a);bootstrap=bootstrap[:a]+' status=integration.returncode\n'+bootstrap[b:]
(out/'bootstrap.py').write_text(bootstrap)
for device in ('cpu','cuda'):
 d=out/device;d.mkdir();gpu=device=='cuda'
 cmd=['srun','--partition='+('3090-gcondo' if gpu else 'batch'),'--qos='+('cs-3090-gcondo' if gpu else 'normal'),'--cpus-per-task=2','--mem=32G','--time=01:00:00','--job-name=se-opt-gate-'+device]
 if gpu:cmd+=['--gres=gpu:1']
 cmd+=['python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))','dmc',device]
 ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
 (d/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(d/'run.log'))+' 2> '+shlex.quote(str(d/'stderr.log'))+'\n')
print(out,len(nodes))
