import base64,hashlib,json,shlex,subprocess,tarfile,sys,io
from pathlib import Path
repo=Path.cwd();root=Path('/private/tmp/se-dmc-opt-20261007');name=sys.argv[1];out=root/name;out.mkdir()
files=set(json.loads(Path('/private/tmp/se-dmc-pixels-20261007/gate-v3/manifest.json').read_text())['files'])
files.update(str(p.relative_to(repo)) for folder in ('stable_envs','tests/contracts','tests/helpers/reference','tests/unit') for p in (repo/folder).rglob('*.py'))
baseline=name=='baseline' or name.startswith('profile-')
blobs={n:subprocess.check_output(['git','show','HEAD:'+n]) if baseline else (repo/n).read_bytes() for n in sorted(files) if (repo/n).exists() and (not baseline or subprocess.run(['git','cat-file','-e','HEAD:'+n],stderr=subprocess.DEVNULL).returncode==0)}
manifest=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tracked_dirty=not baseline,files={n:hashlib.sha256(v).hexdigest() for n,v in blobs.items()})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','w:gz') as archive:
 for n,data in blobs.items():
  info=tarfile.TarInfo(n);info.size=len(data);archive.addfile(info,io.BytesIO(data))
 archive.add(out/'manifest.json',arcname='manifest.json')
 if baseline:
  archive.add(root/'gpu-agent/profile_stages.py',arcname='profile_stages.py')
  for p in Path('/private/tmp/se-dmc-pixels-20261007/candidate-v7/cuda/artifacts/probe').glob('*.npz'):archive.add(p,arcname='corpus/'+p.name)
 else:archive.add(root/'baseline/source.tar.gz',arcname='baseline-source.tar.gz')
 if name.startswith('chunks-'):
  archive.add(root/'cpu-agent/dmc_cpu_chunks.py',arcname='dmc_cpu_chunks.py')
  for p in Path('/private/tmp/se-dmc-pixels-20261007/gate-v2/cpu/artifacts/benchmark').glob('*/states.npz'):archive.add(p,arcname='corpus/'+p.parent.name+'/states.npz')
bootstrap=Path('/private/tmp/se-fetch-readback-20261007/gate-v2/bootstrap.py').read_text()
a=bootstrap.index(' integration=subprocess.run');b=bootstrap.index(' buffer=io.BytesIO()',a)
if baseline:command=" status=subprocess.run([python,'profile_stages.py','--corpus-dir','corpus','--output','probe','--inner','10']).returncode\n"
elif name.startswith('chunks-'):command=" status=subprocess.run([python,'dmc_cpu_chunks.py','--root',str(root),'--corpus-root','corpus','--output','benchmark','--threads','1','--repeats','5']).returncode\n"
else:command=" baseline=root/'baseline';baseline.mkdir()\n with tarfile.open(root/'baseline-source.tar.gz') as archive:archive.extractall(baseline,filter='data')\n status=subprocess.run([python,'scripts/benchmarks/dmc_render.py','--baseline-root',str(baseline),'--source-root','/oscar/scratch/sboughan/se-semantic-recovery/swm-reference','--device',device,'--output','benchmark']).returncode\n"
bootstrap=bootstrap[:a]+command+bootstrap[b:]
bootstrap=bootstrap.replace("'evidence','run.xml','hardware.json','xvfb.log','pytest-temp','readback-tests.xml','benchmark'","'probe','hardware.json','xvfb.log','benchmark'")
(out/'bootstrap.py').write_text(bootstrap)
for device in (['cuda'] if baseline else ['cpu','cuda']):
 d=out/device;d.mkdir();gpu=device=='cuda'
 cmd=['srun','--partition='+('3090-gcondo' if gpu else 'batch'),'--qos='+('cs-3090-gcondo' if gpu else 'normal'),'--cpus-per-task=2','--mem=32G','--time=00:30:00','--job-name=se-opt-'+name+'-'+device]
 if gpu:cmd+=['--gres=gpu:1']
 cmd+=['python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))','dmc',device]
 ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
 (d/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(d/'run.log'))+' 2> '+shlex.quote(str(d/'stderr.log'))+'\n')
print(out)
