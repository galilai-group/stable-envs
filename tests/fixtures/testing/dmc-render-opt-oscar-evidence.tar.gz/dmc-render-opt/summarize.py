"""Validate completed Oscar optimization evidence; write new outputs only."""
import csv
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/samib/stable-envs')
sys.path.insert(0, str(REPO))
from stable_envs.testing.evidence import sha256, verify_seal
from tests.helpers.reference.profiles import PROFILES

BASELINE = 'd5947b65a1a3491ca982104aa100d6c8f06a9f18'
CSV = REPO / 'tests/fixtures/testing/dmc-render-opt-performance.csv'
SUMMARY = ROOT / 'summary-draft.json'
RUNS = {'cpu': 'gate-v1', 'cuda': 'gate-v2'}
CPU_MODULES = {
    'test_texture_mip', 'test_cpu3d_reflections', 'test_cpu3d_scene', 'test_cpu3d',
    'test_cpu3d_shadow_rays', 'test_raycast3d_composite_compact',
    'test_raycast3d_cpu_components', 'test_raycast3d_ellipsoid', 'test_raycast3d_primitive_bounds',
}
MPS_SKIP = 'test_unknown_device_raises_rather_than_falling_back[mps]'
MISSING_FIXTURE_SKIP = 'test_the_bounded_kinds_are_the_ones_the_committed_MEASUREMENT_chose'
CPU_FIXTURES = (
    'tests/fixtures/regression/join/step6/raycast3d/experiments/r6_kind_cost.json',
    'tests/fixtures/regression/join/step7/dmc-quadruped/phase1/cpu_oscar/kind_cost_ellipsoid.json',
)
OTHER_FAMILY = ('fetch', 'ogbench', 'pusht', 'native', 'rocket', 'navigation', 'state_view')


def relevant(path, device):
    if path.startswith('stable_envs/') or path == 'scripts/benchmarks/dmc_render.py':
        return True
    if path in {'tests/conftest.py', 'tests/contracts/conftest.py'}:
        return True
    if path.startswith(('tests/contracts/', 'tests/helpers/reference/')) and path.endswith('.py'):
        return not any(word in Path(path).name for word in OTHER_FAMILY)
    if device == 'cpu' and path.startswith('tests/unit/'):
        return Path(path).stem in CPU_MODULES
    if device == 'cuda' and path == 'tests/integration/test_dmc_trackcom_batching.py':
        return True
    return path.startswith(('tests/fixtures/semantics/dmc_', 'tests/fixtures/semantics/dmc/'))


def read(path):
    return json.loads(path.read_text())


def check_xml(path, *, skips=()):
    cases = list(ET.parse(path).getroot().iter('testcase'))
    assert cases, path
    names = [(c.get('classname'), c.get('name')) for c in cases]
    assert len(names) == len(set(names)), ('Duplicate test cases', path)
    assert not any(c.find('failure') is not None or c.find('error') is not None for c in cases), path
    skipped = [c.get('name') for c in cases if c.find('skipped') is not None]
    assert skipped == list(skips), (path, skipped)
    return cases


def main():
    assert not CSV.exists() and not SUMMARY.exists(), 'Refusing to overwrite prior outputs'
    scheduler = (ROOT / 'scheduler.txt').read_text()
    assert scheduler.strip(), 'Missing scheduler terminal evidence'
    baseline = read(ROOT / 'baseline/manifest.json')
    assert baseline['commit'] == BASELINE and not baseline['tracked_dirty']
    archive = subprocess.check_output(['git', 'archive', BASELINE, 'stable_envs'], cwd=REPO)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for member in tar.getmembers():
            if member.isfile() and member.name in baseline['files']:
                assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == baseline['files'][member.name]
    registrations = {case.name: case.registration for case in PROFILES['dmc']}
    rows, gates, snapshots, verified_files = [], {}, {}, {}
    for device, run_name in RUNS.items():
        run = ROOT / run_name
        artifacts = run / device / 'artifacts'
        report = read(artifacts / 'evidence/result.json')
        required = read(run / 'required.json')['dmc']
        assert len(required) == len(set(required)) == 288
        assert report['status'] == 'PASS' and report['passed'] == report['required'] == 288
        assert set(report['cases']) == set(required)
        assert all(case['status'] == 'PASS' for case in report['cases'].values())
        sealed = verify_seal(artifacts / 'evidence')
        candidate = read(artifacts / 'evidence/candidate.json')
        manifest = read(run / 'manifest.json')
        expected_candidate = {
            name for name in manifest['files']
            if name in {'tests/conftest.py', 'pyproject.toml'}
            or (name.endswith('.py') and name.startswith((
                'stable_envs/', 'tests/contracts/', 'tests/helpers/reference/', 'scripts/testing/',
            )))
        }
        assert set(candidate['files']) == expected_candidate
        assert all(manifest['files'][name] == digest for name, digest in candidate['files'].items())
        assert candidate['commit'] == manifest['commit']
        checked, unrelated = {}, {}
        for name, digest in manifest['files'].items():
            path = REPO / name
            if relevant(name, device):
                assert path.is_file() and sha256(path) == digest, (device, name)
                checked[name] = digest
                verified_files[name] = digest
            elif path.is_file() and sha256(path) != digest:
                unrelated[name] = {'snapshot': digest, 'current': sha256(path)}
        assert all(name in checked for name in (
            'stable_envs/render/cpu3d.py', 'stable_envs/render/raycast3d.py',
            'stable_envs/envs/dmcontrol/trackcom.py', 'tests/helpers/reference/pixels.py',
            'tests/helpers/reference/dmc_pixels.py', 'tests/contracts/test_dmc_source_pixels.py',
        ))
        snapshots[device] = {'manifest': f'{run_name}/manifest.json', 'verified_files': checked,
                             'unrelated_current_differences': unrelated}
        cases = check_xml(artifacts / 'run.xml')
        assert len(cases) == 288
        pixels = []
        for case in cases:
            if not case.get('name').startswith('test_source_rollout_pixels'):
                continue
            props = {v.get('name'): v.get('value') for v in case.findall('properties/property')}
            name = case.get('name').split('[')[1].split('-seed')[0]
            pixels.append({'registration': registrations[name], 'mse_max': float(props['mse_max']),
                           'frames': int(props['frames'])})
        assert len(pixels) == 96 and sum(c['frames'] for c in pixels) == 1536
        assert max(c['mse_max'] for c in pixels) <= .001
        if device == 'cpu':
            original_units = check_xml(artifacts / 'renderer-tests.xml', skips=(MPS_SKIP, MISSING_FIXTURE_SKIP))
            assert len(original_units) == 243
            supplemental = ROOT / 'gate-v4/cpu'
            supplemental_manifest = read(ROOT / 'gate-v4/manifest.json')
            supplemental_checked = {}
            for name, digest in supplemental_manifest['files'].items():
                if relevant(name, 'cpu') or name in CPU_FIXTURES:
                    assert (REPO / name).is_file() and sha256(REPO / name) == digest, ('CPU supplemental', name)
                    supplemental_checked[name] = digest
                    verified_files[name] = digest
            for name, digest in checked.items():
                assert supplemental_checked.get(name) == digest, ('Supplement missing or changed file', name)
            assert all(name in supplemental_checked for name in CPU_FIXTURES)
            units = check_xml(supplemental / 'artifacts/renderer-tests.xml', skips=(MPS_SKIP,))
            assert {c.get('classname').split('.')[-1] for c in units} == CPU_MODULES
            assert len(units) == 243
            assert {(c.get('classname'), c.get('name')) for c in units} == {                (c.get('classname'), c.get('name')) for c in original_units}
            supplemental_job = re.search(r'JOB_ID (\d+)', (supplemental / 'run.log').read_text()).group(1)
            assert re.search(rf'^\s*{supplemental_job}(?:\s|\|).*COMPLETED.*0:0', scheduler, re.M)
            if (supplemental / 'artifacts/SHA256SUMS').exists():
                verify_seal(supplemental / 'artifacts')
            snapshots['cpu_regressions'] = {'manifest': 'gate-v4/manifest.json',
                                            'verified_files': supplemental_checked}
        else:
            units = check_xml(artifacts / 'renderer-tests.xml')
            assert len(units) == 8
            assert all(c.get('name').startswith('test_gpu_batch_capacity_and_per_row_style[') for c in units)
        job = re.search(r'JOB_ID (\d+)', (run / device / 'run.log').read_text()).group(1)
        assert re.search(rf'^\s*{job}(?:\s|\|).*COMPLETED.*0:0', scheduler, re.M), ('Nonterminal or failed job', job)
        gates[device] = {
            'required': 288, 'passed': 288, 'pixel_cases': 96, 'frame_comparisons': 1536,
            'mse_max': max(c['mse_max'] for c in pixels), 'seal_files': len(sealed),
            'registrations': {reg: {'pixel_cases': sum(c['registration'] == reg for c in pixels),
                                    'mse_max': max(c['mse_max'] for c in pixels if c['registration'] == reg)}
                              for reg in sorted(registrations.values())},
            'renderer_regressions': {'passed': len(units) - (device == 'cpu'),
                                     'skipped': [MPS_SKIP] if device == 'cpu' else []},
            'hardware': read(artifacts / 'hardware.json'), 'job_id': job,
            'artifact': f'accepted/{device}/artifacts',
        }
        if device == 'cpu':
            gates[device]['renderer_regressions'].update(
                job_id=supplemental_job, artifact='accepted/cpu-regressions/artifacts',
                original_run={'passed': 241, 'skipped': [MPS_SKIP, MISSING_FIXTURE_SKIP],
                              'artifact': 'accepted/cpu/artifacts/renderer-tests.xml',
                              'superseded': True, 'reason': 'Export omitted committed primitive-cost fixtures'},
            )
        benchdir = artifacts / 'benchmark'
        verify_seal(benchdir)
        bench = read(benchdir / 'result.json')
        assert bench['device'] == device and bench['repeats'] == 12 and bench['warmups'] == 3
        assert bench['runner_sha256'] == sha256(REPO / 'scripts/benchmarks/dmc_render.py')
        assert bench['seeds'] == [17, 42] and bench['lanes'] == 2 and bench['horizon'] == 8
        batches = [1, 64] if device == 'cpu' else [1, 64, 256]
        assert len(bench['rows']) == 5 * len(batches)
        domains = {r['domain'] for r in bench['rows']}
        assert domains == {'walker', 'hopper', 'cheetah', 'humanoid', 'quadruped'}
        for domain in sorted(domains):
            assert sorted(r['batch'] for r in bench['rows'] if r['domain'] == domain) == batches
            before = read(benchdir / domain / 'before.json')
            after = read(benchdir / domain / 'after.json')
            assert before['unique_source_states'] == after['unique_source_states'] == 32
            assert before['corpus_sha256'] == after['corpus_sha256'] == sha256(benchdir / domain / 'states.npz')
            for worker, identity in ((before, baseline), (after, manifest)):
                for name, digest in worker['code_sha256'].items():
                    assert identity['files'][name] == digest, (domain, name)
            with np.load(benchdir / domain / 'before.npz', allow_pickle=False) as data:
                previous = data['frames'].copy()
            with np.load(benchdir / domain / 'after.npz', allow_pickle=False) as data:
                current = data['frames'].copy()
            assert previous.shape == current.shape == (32, 64, 64, 3)
            assert previous.dtype == current.dtype == np.uint8 and np.array_equal(previous, current), domain
        gates[device]['runtime_versions'] = bench['versions']
        for row in bench['rows']:
            assert row['mse_before']['max'] <= .001 and row['mse_after']['max'] <= .001
            assert row['change_from_baseline'] == {'identical': True, 'max_channel_error': 0,
                                                    'differing_channels': 0, 'mse_max': 0.0}
            result = {'env': row['env'], 'device': device, 'batch': row['batch'],
                      'before_fps': row['before']['fps'], 'after_fps': row['after']['fps'],
                      'after_over_before': row['speedup']}
            for label in ('before', 'after'):
                values = np.asarray(row[label]['seconds'])
                assert len(values) == 12 and np.isfinite(values).all() and (values > 0).all()
                assert np.isclose(values.mean(), row[label]['seconds_mean'], rtol=1e-12)
                assert np.isclose(values.std(ddof=1), row[label]['seconds_sd'], rtol=1e-12)
                assert np.isclose(row[label]['fps'], row['batch'] / values.mean(), rtol=1e-12)
                for key in ('seconds_mean', 'seconds_sd'):
                    result[label + '_' + key] = row[label][key]
                for key in ('mean', 'sd', 'max'):
                    result[label + '_mse_' + key] = row['mse_' + label][key]
            assert np.isclose(row['speedup'], row['before']['seconds_mean'] / row['after']['seconds_mean'], rtol=1e-12)
            result.update(unique_source_states=32, repeats=12, exact_baseline_pixels=True,
                          host=bench['host'], gpu=bench['gpu'])
            rows.append(result)
    summary = {
        'status': 'PASS', 'baseline_commit': BASELINE,
        'scope': 'Five DMC default renderer performance improvements with unchanged accepted pixels',
        'source_commit': '176d54532b3c0a251a4f509b74f2fdacc143a63d',
        'source_per_frame_normalized_mse_limit': .001, 'source_gates': gates,
        'snapshot_verification': snapshots, 'candidate_files': verified_files,
        'performance': {'csv': str(CSV.relative_to(REPO)), 'rows': len(rows),
                        'comparison': 'Our before/after on the same device; source FPS not measured',
                        'states_per_domain': 32, 'seeds': [17, 42], 'lanes': 2, 'horizon': 8,
                        'warmups': 3, 'repeats': 12, 'cpu_batches': [1, 64], 'cuda_batches': [1, 64, 256],
                        'timing_scope': 'Public render of device-resident full States and synchronization; includes State packing',
                        'excluded': 'Source rollout, disk loading, initial transfer, batch indexing and initialization',
                        'sampling': 'Larger batches repeat the 32 reached States; SD is sample SD'},
        'limitations': ['Default source-pixel gates retain the 0.001 threshold; generalization is bounded by the tested corpus.',
                        'DMC source physics remains CPU; source rendering uses llvmpipe on CPU and NVIDIA EGL on CUDA.',
                        'GPU stage timings exclude public upload/packing/output costs and are diagnostic only.',
                        'Exploratory rejected/failed probes are archived separately and confer no acceptance.',
                        'Final-eight family extensions are outside this report; differing unrelated source files are recorded explicitly.'],
    }
    with CSV.open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0], lineterminator='\n'); writer.writeheader(); writer.writerows(rows)
    with SUMMARY.open('x') as stream:
        json.dump(summary, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps(gates, indent=2))


if __name__ == '__main__':
    main()
