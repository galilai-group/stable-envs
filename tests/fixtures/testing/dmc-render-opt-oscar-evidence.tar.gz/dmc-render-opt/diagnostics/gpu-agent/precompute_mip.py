from pathlib import Path
p=Path('stable_envs/render/trackcom_reflection.py');s=p.read_text()
s=s.replace('''        if not context.use_precomputed_rays:
            raise ValueError("TrackCom reflection requires precomputed camera rays")
''','''        if not context.use_precomputed_rays:
            raise ValueError("TrackCom reflection requires precomputed camera rays")
        camera = int(context.cam_id_map.numpy()[0])
        if source_model.cam_mode[camera] != mujoco.mjtCamLight.mjCAMLIGHT_TRACKCOM or source_model.geom_bodyid[reflective[0]] != 0:
            raise ValueError("TrackCom reflection requires fixed camera orientation and a world-body plane")
''')
s=s.replace('''            grid_y: wp.array[float]
''','''            grid_y: wp.array[float]
            mip_scale: wp.array[float]
''')
start=s.index('            footprint = float(1.0)');end=s.index('            lod = wp.log(footprint)',start)
old=s[start:end]
body=old[old.index('            for axis'):]
body=body.replace('''neighbor_point = origin + ray_neighbor * (wp.dot(plane_pos - origin, normal_plane) / divisor)''','''neighbor_point = ray_neighbor / divisor''')
body=body.replace('''on_plane''','''unit_hit''')
body=body.replace('''            for axis in range(2):''','''            for axis in range(2):''')
prefunc='''        @wp.kernel(module="unique", enable_backward=False)
        def cache_mip_scales(s: Scene):
            pixel = wp.tid()
            camera = s.cam_id_map[0]
            rotation = s.cam_xmat[0, camera]
            plane_rotation = s.geom_xmat[0, wp.static(plane)]
            normal_plane = plane_rotation[:, 2]
            direction = rotation @ s.ray[pixel]
            divisor = wp.dot(direction, normal_plane)
            footprint = float(0.0)  # noqa: UP018
            if wp.abs(divisor) > 1.0e-8:
                unit_hit = direction / divisor
'''
# Only initialization is frame-independent; all per-world geometry/shading remains in the render kernel.
prefunc+='\n'.join('    '+line for line in body.rstrip().splitlines())+'\n'
prefunc+='''            s.mip_scale[pixel] = footprint

'''
s=s[:start]+'''            plane_rotation = s.geom_xmat[world, wp.static(plane)]
            height = wp.dot(plane_pos - origin, normal_plane)
            footprint = wp.max(1.0, wp.abs(height) * s.mip_scale[pixel])
'''+s[end:]
pos=s.index('        @wp.kernel(module="unique", enable_backward=False)\n        def reflected_pixels')
s=s[:pos]+prefunc+s[pos:]
s=s.replace('''        for name in Scene.vars:
''','''        grid_arrays["mip_scale"] = wp.empty(int(context.total_rays), dtype=float, device=data.geom_xpos.device)
        for name in Scene.vars:
''')
s=s.replace('''        self._wp, self._kernel, self._scene = wp, reflected_pixels, scene
''','''        wp.launch(cache_mip_scales, dim=int(context.total_rays), inputs=[scene], device=data.geom_xpos.device)
        self._wp, self._kernel, self._scene = wp, reflected_pixels, scene
''')
p.write_text(s)
