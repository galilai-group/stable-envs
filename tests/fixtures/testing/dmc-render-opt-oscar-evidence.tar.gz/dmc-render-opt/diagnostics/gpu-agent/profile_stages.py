"""Run on Oscar: accepted saved States, public render, then captured GPU stages."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import time

import numpy as np
import torch
import warp as wp
from tensordict import TensorDict

import stable_envs as se
from stable_envs.envs.dmcontrol.trackcom import _tc_frame
from tests.helpers.reference.profiles import PROFILES

parser = argparse.ArgumentParser()
parser.add_argument('--corpus-dir', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--domains', nargs='+', default=['walker','humanoid','quadruped','hopper','cheetah'])
parser.add_argument('--repeats', type=int, default=12)
parser.add_argument('--inner', type=int, default=50)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
rows=[]
wp.init()
torch_stream = torch.cuda.Stream()
stream = wp.stream_from_torch(torch_stream)

for case in PROFILES['dmc']:
    if case.domain not in args.domains:
        continue
    path=args.corpus_dir/(case.domain+'.npz')
    with np.load(path) as saved:
        count=len(saved['source'])
        states=TensorDict({tuple(k[6:].split('/')):torch.from_numpy(saved[k].copy())
                          for k in saved if k.startswith('state/')}, batch_size=[count]).to('cuda')
        source=saved['source'].copy()
    with se.make(case.name,num_envs=64,device='cuda',size=64) as env:
        batch=states[torch.arange(64,device='cuda') % count]
        rendered=env.render(batch)
        error=((rendered.cpu().numpy().astype(float)-source[np.arange(64)%count])/255)**2
        context=env._context(64)
        stages={
            'kinematics':lambda:context.mjw.kinematics(context.wm,context.wd),
            'com_pos':lambda:context.mjw.com_pos(context.wm,context.wd),
            'camlight':lambda:context.mjw.camlight(context.wm,context.wd),
            'refit_bvh':lambda:context.mjw.refit_bvh(context.wm,context.wd,context.rc),
            'upstream_render':lambda:context.mjw.render(context.wm,context.wd,context.rc),
            'cached_sky':context.textures.render,
            'floor_and_reflection':context.reflection.render,
            'complete_frame':lambda:_tc_frame(context),
        }
        row={'domain':case.domain,'device':torch.cuda.get_device_name(),'batch':64,
             'corpus_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
             'mse_max':float(error.mean((1,2,3)).max()),'stages':{}}
        torch_stream.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(torch_stream), wp.ScopedStream(stream):
            for label,operation in stages.items():
                operation();wp.synchronize()
                with wp.ScopedCapture(stream=stream) as capture:
                    for _ in range(args.inner):
                        operation()
                for _ in range(3):
                    wp.capture_launch(capture.graph,stream=stream)
                wp.synchronize()
                vals=[]
                for _ in range(args.repeats):
                    start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
                    start.record(torch_stream)
                    wp.capture_launch(capture.graph,stream=stream)
                    end.record(torch_stream);end.synchronize()
                    vals.append(start.elapsed_time(end)/args.inner)
                row['stages'][label]={'gpu_ms_mean':statistics.mean(vals),'gpu_ms_sd':statistics.stdev(vals),'raw_ms':vals}
                print(case.domain,label,row['stages'][label]['gpu_ms_mean'],flush=True)
        vals=[]
        for _ in range(3):env.render(batch)
        for _ in range(args.repeats):
            torch.cuda.synchronize();start=time.perf_counter();env.render(batch);torch.cuda.synchronize()
            vals.append((time.perf_counter()-start)*1000)
        row['public_render']={'ms_mean':statistics.mean(vals),'ms_sd':statistics.stdev(vals),'raw_ms':vals}
        rows.append(row)
        (args.output/'report.json').write_text(json.dumps(rows,indent=2)+'\n')
        print(json.dumps(row),flush=True)
