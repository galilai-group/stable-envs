# CPU shadow optimization probe

Local Apple M5 CPU, Torch one thread; compiled source model and 16 saved poses. Baseline d5947b65 source copies preserved alongside scripts. This is render-kernel timing, excluding source-state/model preparation. B64 repeats the 16 source-reached poses; 12 alternating paired samples per variant after warmup. All output images exactly equal. Oscar public-render validation remains required.

| Domain | Batch | Before median ms | After median ms | Speedup |
|---|---:|---:|---:|---:|
| walker | 1 | 7.139 | 6.619 | 1.079x |
| walker | 64 | 226.685 | 180.472 | 1.256x |
| humanoid | 1 | 14.327 | 13.719 | 1.044x |
| humanoid | 64 | 475.005 | 454.556 | 1.045x |
| quadruped | 1 | 18.125 | 17.751 | 1.021x |
| quadruped | 64 | 274.332 | 264.579 | 1.037x |
| hopper | 1 | 5.460 | 5.086 | 1.074x |
| hopper | 64 | 85.643 | 78.874 | 1.086x |
| cheetah | 1 | 9.968 | 9.190 | 1.085x |
| cheetah | 64 | 104.387 | 98.271 | 1.062x |

Implementation: compact CPU shadows retain per-ray world IDs, skip already-blocked rays, and use the same primitive equations without constructing normals. Nonunit rays preserve generic unbounded fallback. No MSE threshold, rendering fidelity, API, or default chunk-size changes.

Focused tests: 140 existing tests passed plus 17 new distance-only/compact-shadow tests. Ruff check/format and git diff --check passed.

Prototypes flat-shadow-paired.json and distance-flat-paired.json preceded production-paired.json; no previous evidence was overwritten.

## Chunk diagnostic

B64, three warm timed samples per chunk, all exact pixels. Sequential exploratory order; compare on Oscar before changing defaults.

| Domain | Chunk4 ms | Chunk8 ms | Chunk16 ms | Chunk32 ms | Chunk64 ms |
|---|---:|---:|---:|---:|---:|
| walker | 241.297 | 187.319 | 188.637 | 162.980 | 154.996 |
| humanoid | 459.855 | 364.249 | 313.413 | 278.799 | 260.774 |
| quadruped | 432.637 | 311.262 | 263.123 | 231.101 | 215.304 |
| hopper | 138.146 | 93.163 | 82.855 | 65.523 | 59.142 |
| cheetah | 202.121 | 129.725 | 96.784 | 79.783 | 71.646 |
