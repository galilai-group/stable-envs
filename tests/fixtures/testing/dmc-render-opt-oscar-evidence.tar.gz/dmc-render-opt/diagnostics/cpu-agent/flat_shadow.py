def flat_shadow(scene,xpos_rel,xmat,env,o,d,lim):
    blocked=torch.zeros(env.shape,device=o.device,dtype=torch.bool)
    dd=R3.dot3(d,d)
    for k,kind in enumerate(scene.kinds):
        active=(~blocked)&(lim>0)
        if R3._kind_is_bounded(kind):
            radius=R3.bound_radius_tensor(kind,scene.sizes[k])
            active &= R3._rays_near(xpos_rel[env,k],radius,o,d,dd)
        js=active.nonzero(as_tuple=True)[0]
        if not js.numel():
            continue
        distance,_=R3.intersect(kind,scene.sizes[k],xpos_rel[env[js],k],xmat[env[js],k],o[js],d[js])
        blocked[js]=(distance>0)&(distance<lim[js])
    return blocked
