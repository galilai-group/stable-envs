def _sphere_distance(o, d, pos, r):
    oc = o - pos
    b = dot3(oc, d)
    c = dot3(oc, oc) - r * r
    disc = b * b - c
    sq = torch.sqrt(torch.clamp(disc, min=0))
    t = -b - sq
    t = torch.where(t > 0, t, -b + sq)
    hit = (disc > 0) & (t > 0)
    t = torch.where(hit, t, torch.full_like(t, INF))
    return t, None


def _ellipsoid_distance(o, d, pos, R, size):
    """Intersect an ellipsoid by scaling local rays to a unit sphere.

    Normals are normalised gradients in the local frame, rotated back to world space.
    A nonpositive semi-axis produces a miss."""
    ol = mtv3(R, o - pos)
    dl = mtv3(R, d)
    inv = 1.0 / torch.clamp(size, min=1e-12)
    olx = ol[..., 0] * inv[..., 0]
    oly = ol[..., 1] * inv[..., 1]
    olz = ol[..., 2] * inv[..., 2]
    dlx = dl[..., 0] * inv[..., 0]
    dly = dl[..., 1] * inv[..., 1]
    dlz = dl[..., 2] * inv[..., 2]
    a = dlx * dlx + dly * dly + dlz * dlz
    b = olx * dlx + oly * dly + olz * dlz
    c = olx * olx + oly * oly + olz * olz - 1.0
    disc = b * b - a * c
    sq = torch.sqrt(torch.clamp(disc, min=0))
    a_safe = torch.clamp(a, min=1e-12)
    t = (-b - sq) / a_safe
    t = torch.where(t > 0, t, (-b + sq) / a_safe)
    hit = (disc > 0) & (t > 0) & (a > 1e-12) & (size[..., 0] > 0) & (size[..., 1] > 0) & (size[..., 2] > 0)
    t = torch.where(hit, t, torch.full_like(t, INF))
    return t, None


def _capsule_distance(o, d, pos, R, r, hh):
    """Intersect a local Z-axis capsule with radius r and cylinder half-length hh."""
    ol = mtv3(R, o - pos)
    dl = mtv3(R, d)
    a = dl[..., 0] ** 2 + dl[..., 1] ** 2
    b = ol[..., 0] * dl[..., 0] + ol[..., 1] * dl[..., 1]
    c = ol[..., 0] ** 2 + ol[..., 1] ** 2 - r * r
    disc = b * b - a * c
    sq = torch.sqrt(torch.clamp(disc, min=0))
    best = torch.full_like(a, INF)
    for sgn in (-1.0, 1.0):
        t = (-b + sgn * sq) / torch.clamp(a, min=1e-12)
        z = ol[..., 2] + t * dl[..., 2]
        ok = (disc > 0) & (a > 1e-12) & (t > 0) & (z.abs() <= hh)
        best = torch.where(ok & (t < best), t, best)
    for sz in (-1.0, 1.0):
        zc = sz * hh
        oc = ol - torch.stack(
            [torch.zeros_like(ol[..., 0]), torch.zeros_like(ol[..., 0]), torch.zeros_like(ol[..., 0]) + zc], -1
        )
        bb = dot3(oc, dl)
        cc = dot3(oc, oc) - r * r
        dd = bb * bb - cc
        s2 = torch.sqrt(torch.clamp(dd, min=0))
        for sgn in (-1.0, 1.0):
            t = -bb + sgn * s2
            ok = (dd > 0) & (t > 0)
            best = torch.where(ok & (t < best), t, best)
    return best, None


def _cylinder_distance(o, d, pos, R, r, hh):
    ol = mtv3(R, o - pos)
    dl = mtv3(R, d)
    a = dl[..., 0] ** 2 + dl[..., 1] ** 2
    b = ol[..., 0] * dl[..., 0] + ol[..., 1] * dl[..., 1]
    c = ol[..., 0] ** 2 + ol[..., 1] ** 2 - r * r
    disc = b * b - a * c
    sq = torch.sqrt(torch.clamp(disc, min=0))
    best = torch.full_like(a, INF)
    side = torch.zeros_like(a, dtype=torch.bool)
    for sgn in (-1.0, 1.0):
        t = (-b + sgn * sq) / torch.clamp(a, min=1e-12)
        z = ol[..., 2] + t * dl[..., 2]
        ok = (disc > 0) & (a > 1e-12) & (t > 0) & (z.abs() <= hh)
        upd = ok & (t < best)
        best = torch.where(upd, t, best)
        side = side | upd
    capz = torch.zeros_like(a)
    for sgn in (-1.0, 1.0):
        zc = sgn * hh
        t = (zc - ol[..., 2]) / torch.where(dl[..., 2].abs() > 1e-12, dl[..., 2], torch.full_like(dl[..., 2], 1e-12))
        px = ol[..., 0] + t * dl[..., 0]
        py = ol[..., 1] + t * dl[..., 1]
        ok = (t > 0) & (px * px + py * py <= r * r) & (dl[..., 2].abs() > 1e-12)
        upd = ok & (t < best)
        best = torch.where(upd, t, best)
        side = side & ~upd
        capz = torch.where(upd, torch.full_like(capz, sgn), capz)
    return best, None


def _box_distance(o, d, pos, R, size):
    ol = mtv3(R, o - pos)
    dl = mtv3(R, d)
    inv = 1.0 / torch.where(dl.abs() < 1e-12, torch.full_like(dl, 1e-12), dl)
    t1 = (-size - ol) * inv
    t2 = (size - ol) * inv
    tmin = torch.minimum(t1, t2).max(-1).values
    tmax = torch.maximum(t1, t2).min(-1).values
    hit = tmax >= torch.clamp(tmin, min=0.0)
    t = torch.where(tmin > 0, tmin, tmax)
    t = torch.where(hit & (t > 0), t, torch.full_like(t, INF))
    return t, None


def distance_intersect(
    kind: int, size: torch.Tensor, pos: torch.Tensor, R: torch.Tensor, o: torch.Tensor, d: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return ray parameters and world-space normals, with t=INF on misses.

    Poses (..., 3) and rotations (..., 3, 3) broadcast against rays (..., 3).
    Unsupported MuJoCo geometry kinds raise ValueError."""
    if kind == SPHERE:
        return _sphere_distance(o, d, pos, size[..., 0:1].squeeze(-1))
    if kind == CAPSULE:
        return _capsule_distance(o, d, pos, R, size[..., 0:1].squeeze(-1), size[..., 1:2].squeeze(-1))
    if kind == CYLINDER:
        return _cylinder_distance(o, d, pos, R, size[..., 0:1].squeeze(-1), size[..., 1:2].squeeze(-1))
    if kind == BOX:
        return _box_distance(o, d, pos, R, size)
    if kind == ELLIPSOID:
        return _ellipsoid_distance(o, d, pos, R, size)
    if kind == PLANE:
        return _plane(o, d, pos, R, size)
    raise ValueError(f"raycast3d has no intersector for mjtGeom {kind}; scenes here are primitive-only")
