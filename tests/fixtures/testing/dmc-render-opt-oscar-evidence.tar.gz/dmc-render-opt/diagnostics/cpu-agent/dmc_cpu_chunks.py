"""Sweep CPU render chunks on saved DMC States without timing corpus preparation."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import resource
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import torch


def _states(path: Path):
    from tensordict import TensorDict

    with np.load(path, allow_pickle=False) as saved:
        source = saved["source_frames"]
        if source.dtype != np.uint8 or source.shape[1:] != (64, 64, 3) or len(source) == 0:
            raise ValueError("Expected a nonempty uint8 source RGB corpus at 64 pixels")
        leaves = {
            tuple(key.removeprefix("state/").split("/")): torch.from_numpy(saved[key])
            for key in saved.files
            if key.startswith("state/")
        }
        if not leaves:
            raise ValueError("Corpus contains no full State leaves")
        return TensorDict(leaves, batch_size=[len(source)]), source


def _peak_rss_bytes() -> int:
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value if platform.system() == "Darwin" else value * 1024)


def _worker(plan: dict) -> None:
    root = Path(plan["root"])
    sys.path.insert(0, str(root))
    import stable_envs as se
    from scripts.benchmarks.dmc_render import _code, _hardware, _hash

    torch.set_num_threads(plan["threads"])
    corpus = Path(plan["corpus"])
    states, source = _states(corpus)
    batch = states[torch.arange(64) % len(states)]
    code = _code(root, "stable_envs")
    report = {
        **_hardware("cpu"),
        "name": plan["name"],
        "domain": plan["domain"],
        "size": plan["size"],
        "batch": 64,
        "unique_source_states": len(states),
        "corpus_sha256": _hash(corpus),
        "code_sha256": code,
        "timing_scope": "Public env.render(full CPU State); CPU wall clock; output allocation included",
        "excluded": "Disk loading, State construction/indexing, initialization, warmup, equality checks",
        "rss_scope": "Fresh worker peak RSS for the entire size/chunk sweep; cumulative, not per-config allocation",
        "orders": [],
        "measurements": [],
    }
    with se.make(plan["name"], num_envs=1, size=plan["size"], device="cpu") as env:
        default = int(env.CPU_RENDER_CHUNK)
        reference = env.render(batch).clone()
        assert reference.shape == (64, plan["size"], plan["size"], 3)
        assert reference.dtype == torch.uint8 and reference.device.type == "cpu"
        labels = ("default", "16", "32", "64")
        chunks = (default, 16, 32, 64)
        rows = [dict(label=label, chunk=chunk, seconds=[], exact=True) for label, chunk in zip(labels, chunks)]
        for row in rows:
            env.CPU_RENDER_CHUNK = row["chunk"]
            for _ in range(3):
                frame = env.render(batch)
                assert torch.equal(frame, reference), f"Warmup changed pixels: {row['label']}"
        for repeat in range(plan["repeats"]):
            shift = repeat % len(rows)
            order = list(range(shift, len(rows))) + list(range(shift))
            report["orders"].append([labels[index] for index in order])
            for index in order:
                row = rows[index]
                env.CPU_RENDER_CHUNK = row["chunk"]
                start = time.perf_counter()
                frame = env.render(batch)
                elapsed = time.perf_counter() - start
                assert torch.equal(frame, reference), f"Timed render changed pixels: {row['label']}"
                row["seconds"].append(elapsed)
        for row in rows:
            samples = np.asarray(row["seconds"])
            row.update(
                seconds_mean=float(samples.mean()),
                seconds_sd=float(samples.std(ddof=1)),
                seconds_median=float(np.median(samples)),
                fps=64 / float(samples.mean()),
                speedup_vs_default=float(np.median(rows[0]["seconds"]) / np.median(samples)),
            )
        report.update(default_chunk=default, warmups_per_config=3, measurements=rows)
        if plan["size"] == 64:
            target = source[np.arange(64) % len(source)]
            mse = np.mean(((reference.numpy().astype(np.float64) - target) / 255) ** 2, axis=(1, 2, 3))
            report["default_mse_vs_source"] = dict(mean=float(mse.mean()), max=float(mse.max()))
        report["reference_sha256"] = hashlib.sha256(reference.numpy().tobytes()).hexdigest()
    report["peak_rss_bytes"] = _peak_rss_bytes()
    assert code == _code(root, "stable_envs"), "Production code changed during measurement"
    with Path(plan["result"]).open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd(), help="Candidate checkout")
    parser.add_argument("--corpus-root", type=Path, help="Accepted benchmark directory containing <domain>/states.npz")
    parser.add_argument("--output", type=Path, help="New evidence directory; existing paths are refused")
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--worker", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        _worker(json.loads(args.worker.read_text()))
        return
    if args.corpus_root is None or args.output is None or args.threads < 1 or args.repeats < 2:
        parser.error("Provide corpus-root, output, threads >= 1 and repeats >= 2")
    root = args.root.resolve()
    sys.path.insert(0, str(root))
    import stable_envs as se
    from scripts.benchmarks.dmc_render import DOMAINS, _hash
    from stable_envs.testing.evidence import EvidenceRun
    from tests.helpers.reference.profiles import PROFILES

    evidence = EvidenceRun(args.output)
    results = []
    for domain in DOMAINS:
        case = next(case for case in PROFILES["dmc"] if case.domain == domain)
        for size in dict.fromkeys((64, getattr(se, case.name).default_size)):
            prefix = f"{domain}/{size}"
            plan = dict(
                root=str(root),
                domain=domain,
                name=case.name,
                size=size,
                corpus=str((args.corpus_root / domain / "states.npz").resolve()),
                result=str(evidence.root / f"{prefix}/result.json"),
                threads=args.threads,
                repeats=args.repeats,
            )
            evidence.json(f"{prefix}/plan.json", plan)
            with (evidence.root / f"{prefix}/worker.log").open("x") as stream:
                subprocess.run(
                    [
                        sys.executable,
                        str(Path(__file__).resolve()),
                        "--worker",
                        str(evidence.root / f"{prefix}/plan.json"),
                    ],
                    cwd=root,
                    stdout=stream,
                    stderr=subprocess.STDOUT,
                    check=True,
                )
            result = json.loads(Path(plan["result"]).read_text())
            results.append(result)
            print(json.dumps(result), flush=True)
    evidence.json("result.json", dict(runner_sha256=_hash(Path(__file__)), rows=results))
    evidence.seal()


if __name__ == "__main__":
    main()
