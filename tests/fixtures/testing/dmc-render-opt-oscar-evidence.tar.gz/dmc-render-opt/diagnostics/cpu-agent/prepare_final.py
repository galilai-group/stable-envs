from pathlib import Path
p=Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/probe.py');s=p.read_text()
s=s.replace('report={}','''report={}
import types
old_r=types.ModuleType('stable_envs.render._old_ray')
exec(Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/raycast3d-before.py').read_text(),old_r.__dict__)
old_c=types.ModuleType('stable_envs.render._old_cpu');old_c.__package__='stable_envs.render'
exec(Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/cpu3d-before.py').read_text(),old_c.__dict__)
old_c.R3=old_r
''')
start=s.index(' originals=c._any_blocking_flat');end=s.index(' for batch in ',start)
s=s[:start]+' stats={}\n'+s[end:]
s=s.replace('c._any_blocking_flat=originals;before=c.render','before=old_c.render').replace('c._any_blocking_flat=optimized;after=c.render','after=c.render')
s=s.replace('    c._any_blocking_flat=(originals,optimized)[j]\n    start=time.perf_counter();c.render(scene,*inputs,chunk_size=chunk);times[j].append(time.perf_counter()-start)','    render=(old_c.render,c.render)[j]\n    start=time.perf_counter();render(scene,*inputs,chunk_size=chunk);times[j].append(time.perf_counter()-start)')
s=s.replace(' c._any_blocking_flat=originals;report[domain]=stats',' report[domain]=stats').replace('flat-shadow-paired.json','production-paired.json')
Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/final_probe.py').write_text(s)
