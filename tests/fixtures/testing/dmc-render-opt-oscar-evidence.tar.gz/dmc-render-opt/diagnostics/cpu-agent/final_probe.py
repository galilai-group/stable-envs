import sys,time,json,contextlib,cProfile,pstats,io
from pathlib import Path
import numpy as np
import torch
from stable_envs._mujoco_gl import configure_mujoco_gl
configure_mujoco_gl()
import mujoco
from stable_envs.render import cpu3d as c
from stable_envs.envs.dmcontrol._model import _effective_alpha
from stable_envs._adapters.dmcontrol_continuation import _make_env
from stable_envs._adapters.dmcontrol_humanoid import _make_env as humanoid_env
from stable_envs.envs.dmcontrol.quadruped import _transcribed_quadruped_env

torch.set_num_threads(1)
root=Path('/private/tmp/se-dmc-pixels-20261007/candidate-v2/cpu/artifacts/probe')
report={}
import types
old_r=types.ModuleType('stable_envs.render._old_ray');sys.modules[old_r.__name__]=old_r
exec(Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/raycast3d-before.py').read_text(),old_r.__dict__)
old_c=types.ModuleType('stable_envs.render._old_cpu');sys.modules[old_c.__name__]=old_c;old_c.__package__='stable_envs.render'
exec(Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/cpu3d-before.py').read_text(),old_c.__dict__)
old_c.R3=old_r

for domain in ['walker','humanoid','quadruped','hopper','cheetah']:
 env=humanoid_env(17) if domain=='humanoid' else _transcribed_quadruped_env(17) if domain=='quadruped' else _make_env(domain,17)
 model=env.physics.model.ptr;data=mujoco.MjData(model)
 alpha=_effective_alpha(model,'geom')
 movers=[g for g in range(model.ngeom) if model.geom_group[g] in (0,1,2) and alpha[g]>0 and model.geom_type[g]!=0]
 camera=2 if domain=='quadruped' else 0
 scene=c.Scene(model,camera,64,movers)
 states=np.load(root/(domain+'.npz'))['state/qpos']; rows=[]
 for qpos in states:
  data.qpos[:]=qpos;mujoco.mj_forward(model,data)
  rows.append((data.cam_xpos[camera].copy(), data.geom_xpos[movers].copy(),data.geom_xmat[movers].reshape(-1,3,3).copy(),data.light_xpos.copy(),data.light_xdir.copy()))
 args=[torch.tensor(np.stack([r[k] for r in rows]),dtype=torch.float32) for k in range(5)]
 args+=[torch.tensor(model.mat_rgba[:,:3].copy()).expand(16,-1,-1),torch.tensor(model.light_diffuse.copy()).expand(16,-1,-1)]
 stats={}
 for batch in (1,64):
  inputs=[x[torch.arange(batch)%16] for x in args]
  chunk=4 if domain=='humanoid' else 16
  before=old_c.render(scene,*inputs,chunk_size=chunk)
  after=c.render(scene,*inputs,chunk_size=chunk)
  assert torch.equal(before,after),(domain,batch,int((before!=after).sum()))
  times=[[],[]]
  for i in range(12):
   for j in ([0,1] if i%2==0 else [1,0]):
    render=(old_c.render,c.render)[j]
    start=time.perf_counter();render(scene,*inputs,chunk_size=chunk);times[j].append(time.perf_counter()-start)
  stats[batch]=dict(before=times[0],after=times[1],speedup=float(np.median(times[0])/np.median(times[1])),exact=True)
 report[domain]=stats;print(domain,{b:r['speedup'] for b,r in stats.items()},flush=True)
Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/production-paired.json').write_text(json.dumps(report,indent=2))
