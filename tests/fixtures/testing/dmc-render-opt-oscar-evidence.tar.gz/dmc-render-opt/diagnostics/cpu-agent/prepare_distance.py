import inspect
from pathlib import Path
from stable_envs.render import raycast3d as r
chunks=[]
markers={'_sphere':'    n = (oc +','_ellipsoid':'    pl = ol +','_capsule':'    pl = ol +','_cylinder':'    pl = ol +','_box':'    pl = ol +'}
returns={'_sphere':'t','_ellipsoid':'t','_capsule':'best','_cylinder':'best','_box':'t'}
for name,marker in markers.items():
 s=inspect.getsource(getattr(r,name));s=s[:s.index(marker)]+'    return '+returns[name]+', None\n';s=s.replace('def '+name+'(', 'def '+name+'_distance(')
 chunks.append(s)
s=inspect.getsource(r.intersect).replace('def intersect(', 'def distance_intersect(')
for name in markers:s=s.replace('return '+name+'(', 'return '+name+'_distance(')
chunks.append(s)
Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/distance_only.py').write_text('\n\n'.join(chunks))
s=Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/probe.py').read_text()
s=s.replace(" scope=dict(c.__dict__);exec(Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/flat_shadow.py').read_text(),scope)"," scope=dict(c.__dict__);scope.update(c.R3.__dict__);exec(Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/distance_only.py').read_text(),scope);exec(Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/flat_shadow.py').read_text().replace('R3.intersect(', 'distance_intersect('),scope)")
s=s.replace('flat-shadow-paired.json','distance-flat-paired.json');Path('/private/tmp/se-dmc-opt-20261007/cpu-agent/distance_probe.py').write_text(s)
