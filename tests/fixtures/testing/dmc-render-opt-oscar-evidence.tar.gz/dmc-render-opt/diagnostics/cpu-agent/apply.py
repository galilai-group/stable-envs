from pathlib import Path
p=Path('stable_envs/render/raycast3d.py');s=p.read_text()
for name,signature,needle,ret in [
 ('_sphere','o, d, pos, r','    n = (oc + t.unsqueeze','t'),
 ('_ellipsoid','o, d, pos, R, size','    pl = ol + t.unsqueeze','t'),
 ('_capsule','o, d, pos, R, r, hh','    pl = ol + best.unsqueeze','best'),
 ('_cylinder','o, d, pos, R, r, hh','    pl = ol + best.unsqueeze','best'),
 ('_box','o, d, pos, R, size','    pl = ol + t.unsqueeze','t'),
]:
 start=s.index(f'def {name}(');end=s.index('\ndef ',start+1);part=s[start:end]
 part=part.replace(f'def {name}({signature}):',f'def {name}({signature}, normal=True):')
 idx=part.index(needle);part=part[:idx]+f'    if not normal:\n        return {ret}, None\n'+part[idx:]
 s=s[:start]+part+s[end:]
start=s.index('def intersect(');end=s.index('\ndef _cast_nearest',start)
part=s[start:end];dispatch=part[part.index('    if kind == SPHERE:'):]
for name in ('_sphere','_ellipsoid','_capsule','_cylinder','_box'):
 lines=dispatch.splitlines()
 for i,line in enumerate(lines):
  if f'return {name}(' in line: lines[i]=line[:-1]+', normal=normal)'
 dispatch='\n'.join(lines)+'\n'
header=part[:part.index('    if kind == SPHERE:')]
s=s[:start]+header+'    return _intersect(kind, size, pos, R, o, d, normal=True)\n\n\ndef _intersect_distance(kind, size, pos, R, o, d):\n    """Return hit distances without constructing normals for occlusion rays."""\n    return _intersect(kind, size, pos, R, o, d, normal=False)[0]\n\n\ndef _intersect(kind, size, pos, R, o, d, *, normal):\n'+dispatch+s[end:]
# Same distance math and caller semantics for the generic Torch occlusion path.
start=s.index('def _any_blocking_torch_unbounded(');end=s.index('# Exact cast parity',start)
part=s[start:end].replace('t, _ = intersect(', 't = _intersect_distance(')
s=s[:start]+part+s[end:];p.write_text(s)
p=Path('stable_envs/render/cpu3d.py');s=p.read_text();start=s.index('    """Test compacted shadow rays',s.index('def _any_blocking_flat('));end=s.index('    B, K = ',start)
s=s[:start]+'''    """Test compacted shadow rays, returning (Q,) boolean occlusion."""
    ray_norm = R3.dot3(d, d)
    if o.device.type == "cpu" and R3._unit_rays(ray_norm):
        blocked = torch.zeros(env.shape, device=o.device, dtype=torch.bool)
        for k, kind in enumerate(scene.kinds):
            active = (~blocked) & (lim > 0)
            if R3._kind_is_bounded(kind):
                radius = R3.bound_radius_tensor(kind, scene.sizes[k])
                active &= R3._rays_near(xpos_rel[env, k], radius, o, d, ray_norm)
            js = active.nonzero(as_tuple=True)[0]
            if not js.numel():
                continue
            distance = R3._intersect_distance(
                kind, scene.sizes[k], xpos_rel[env[js], k], xmat[env[js], k], o[js], d[js]
            )
            blocked[js] = (distance > 0) & (distance < lim[js])
        return blocked
    # Other devices keep the batched dispatcher; nonunit rays bypass geometric bounds.
'''+s[end:];p.write_text(s)
