"""Package validated optimization evidence without modifying historical artifacts."""
import json
import shutil
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/samib/stable-envs')
sys.path.insert(0, str(REPO))
from stable_envs.testing.evidence import EvidenceRun, sha256, verify_seal

ARCHIVE = REPO / 'tests/fixtures/testing/dmc-render-opt-oscar-evidence.tar.gz'
VALIDATION = REPO / 'tests/fixtures/testing/dmc-render-opt-oscar-validation.json'
CSV = REPO / 'tests/fixtures/testing/dmc-render-opt-performance.csv'
SANITIZED_LOGS = []


def copy_tree(source, destination):
    assert source.is_dir(), source
    for path in sorted(source.rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        target = destination / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        assert not target.exists(), target
        if path.name == 'run.log':
            original = path.read_bytes()
            lines = original.splitlines(keepends=True)
            kept = [line for line in lines if not line.startswith(b'EVIDENCE_BASE64 ')]
            target.write_bytes(b''.join(kept))
            SANITIZED_LOGS.append({'source': str(path.relative_to(ROOT)),
                                   'packaged': str(target.relative_to(ROOT / 'sealed')),
                                   'original_sha256': sha256(path),
                                   'packaged_sha256': sha256(target),
                                   'transport_lines_removed': len(lines) - len(kept)})
        else:
            shutil.copy2(path, target)


def main():
    assert not ARCHIVE.exists() and not VALIDATION.exists() and not (ROOT / 'sealed').exists()
    report = json.loads((ROOT / 'summary-draft.json').read_text())
    assert report['status'] == 'PASS'
    assert report['baseline_commit'] == 'd5947b65a1a3491ca982104aa100d6c8f06a9f18'
    assert CSV.is_file() and (ROOT / 'scheduler.txt').is_file()
    for name, digest in report['candidate_files'].items():
        assert sha256(REPO / name) == digest, ('Candidate changed after validation', name)
    for device, gate in report['source_gates'].items():
        original = ROOT / ('gate-v1' if device == 'cpu' else 'gate-v2') / device / 'artifacts'
        verify_seal(original / 'evidence')
        verify_seal(original / 'benchmark')
    supplemental = ROOT / 'gate-v4/cpu/artifacts'
    if (supplemental / 'SHA256SUMS').exists():
        verify_seal(supplemental)
    run = EvidenceRun(ROOT / 'sealed')
    copy_tree(ROOT / 'baseline', run.root / 'baseline')
    for device, gate in (('cpu', 'gate-v1'), ('cuda', 'gate-v2')):
        copy_tree(ROOT / gate / device, run.root / 'accepted' / device)
        snapshot = run.root / 'source-snapshots' / gate
        snapshot.mkdir(parents=True)
        for name in ('manifest.json', 'required.json', 'source.tar.gz', 'bootstrap.py'):
            shutil.copy2(ROOT / gate / name, snapshot / name)
    copy_tree(ROOT / 'gate-v4/cpu', run.root / 'accepted/cpu-regressions')
    snapshot = run.root / 'source-snapshots/gate-v4'
    snapshot.mkdir(parents=True)
    for name in ('manifest.json', 'source.tar.gz', 'bootstrap.py'):
        shutil.copy2(ROOT / 'gate-v4' / name, snapshot / name)
    diagnostics = {
        'candidate-v1': 'Exploratory CPU optimizations and rejected GPU mip cache; not acceptance evidence.',
        'candidate-v2': 'Preliminary simpler GPU batching/sky comparison; not the final gate.',
        'gate-v3': 'Superseded CPU supplement with only the first measurement fixture; gate-v4 includes both.',
        'chunks-v1': 'CPU chunk sweep used to choose bounded measured defaults; not the final gate.',
        'profile-v2': 'Failed profiling stream setup retained for provenance; no valid performance claim.',
        'profile-v3': 'Successful isolated GPU-stage diagnostic; distinct from paired public-render timing.',
        'cpu-agent': 'Local CPU prototypes and diagnostics; do not substitute for Oscar acceptance.',
        'gpu-agent': 'GPU profiler and rejected mip-cache prototype, plus accepted reflection source copy.',
    }
    for directory, description in diagnostics.items():
        source = ROOT / directory
        if source.exists():
            copy_tree(source, run.root / 'diagnostics' / directory)
    if (ROOT / 'gate-v1/cuda').exists():
        copy_tree(ROOT / 'gate-v1/cuda', run.root / 'diagnostics/rejected-gate-v1-cuda')
        diagnostics['rejected-gate-v1-cuda'] = 'Failed GPU test: NumPy style array indexed by CUDA indices; superseded by gate-v2.'
    run.json('diagnostics/index.json', diagnostics)
    for name in ('scheduler.txt', 'prepare.py', 'prepare_gate.py', 'collect.py', 'summarize.py', 'package.py', 'docs-draft.md'):
        shutil.copy2(ROOT / name, run.root / name)
    if (ROOT / 'scheduler.json').exists():
        shutil.copy2(ROOT / 'scheduler.json', run.root / 'scheduler.json')
    shutil.copy2(CSV, run.root / 'performance.csv')
    for name in report['candidate_files']:
        target = run.root / 'candidate' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(REPO / name, target)
    report['performance']['csv_sha256'] = sha256(CSV)
    report['scheduler_evidence'] = 'dmc-render-opt/scheduler.txt'
    report['archive_layout'] = {
        'accepted/cpu': 'CPU gate-v1 source cases and paired benchmark; original unit XML is superseded.',
        'accepted/cpu-regressions': 'Supplemental gate-v4 complete CPU243 regression bundle with committed fixtures restored.',
        'accepted/cuda': 'Only CUDA gate-v2 and its paired benchmark support CUDA acceptance.',
        'diagnostics': 'Exploratory, failed and rejected runs; not acceptance evidence.',
        'source-snapshots': 'Original complete source archives and manifests for each accepted gate.',
    }
    run.json('transport-log-index.json', SANITIZED_LOGS)
    run.json('summary.json', report)
    run.seal()
    verify_seal(run.root)
    with ARCHIVE.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as archive:
            archive.add(run.root, arcname='dmc-render-opt')
    report['artifact_archive'] = {'path': str(ARCHIVE.relative_to(REPO)), 'sha256': sha256(ARCHIVE),
                                  'seal': 'dmc-render-opt/SHA256SUMS'}
    with VALIDATION.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False); stream.write('\n')
    print(ARCHIVE, ARCHIVE.stat().st_size, report['artifact_archive']['sha256'])


if __name__ == '__main__':
    main()
