# DMC renderer optimization: acceptance draft

Status: final CPU/CUDA correctness gates and paired performance measurements are pending. Replace the marked fields with terminal evidence before describing this candidate as accepted.

## Scope and baseline

The comparison starts from accepted pixel-parity commit `d5947b65a1a3491ca982104aa100d6c8f06a9f18`. It covers the default Cheetah, Hopper, Walker, Humanoid and Quadruped renderers. Public APIs, source behavior, reflection/shadow/texture fidelity and the normalized per-frame source-MSE threshold of **0.001** remain unchanged. No fidelity knob is introduced.

Final candidate commit/source manifest: **[PENDING]**. CPU gate: **[PENDING]**. CUDA gate: **[PENDING]**. Archived evidence and checksum manifest: **[PENDING]**.

## Changes

CPU shadow testing keeps each surviving ray's world index instead of sorting rays and padding each world to the largest shadow-ray count. It skips already-occluded rays, applies the existing conservative primitive bounds, and uses the same intersection equations without constructing unused surface normals. Nonunit rays retain the generic fallback. The shared distance-only path preserves primary-ray calculations and normal-returning callers.

CPU chunk sizes change only for measured domain/resolution pairs: Hopper 64px → 64 worlds; Cheetah 64px → 64 and 84px → 32; Humanoid 64px/84px → 16. Other defaults remain. These choices amortize Torch dispatch while avoiding a blanket increase in large-image temporary buffers. The exploratory chunk sweep's peak RSS describes the entire worker sweep, not the memory cost of an individual selected chunk.

GPU contexts use the next power-of-two batch capacity, capped at 256 worlds for images up to 84px and 64 worlds above that. Larger requests are processed in bounded chunks, preserving row-specific States and appearance. The cache still holds at most three contexts; constructing a replacement can temporarily keep a fourth alive. The primary MJWarp sky calculation is disabled because the accepted cached source-sky pass already replaces every background miss. The floor/reflection implementation remains byte-for-byte unchanged from the accepted baseline. A proposed mip-derivative cache was rejected because it changed a few RGB channels without a demonstrated material throughput benefit.

## Measurement method

`scripts/benchmarks/dmc_render.py` runs baseline and candidate in separate subprocesses on the same allocated host/device, alternating their order by environment. It records package/hardware identity and code/corpus hashes, then checks that source files did not change during measurement.

For each domain, the pinned source produces 32 reached full States: two seeds (17, 42), two lanes, eight transitions. The corpus and ground-truth RGB frames are saved before timing. States are loaded, transferred to the target device and indexed into batches before timing. Larger batches repeat this corpus; they do not constitute additional independent source States.

Each case has three warm-up renders and 12 timed public `render` calls. CPU batches are 1 and 64; GPU batches are 1, 64 and 256. Timing includes full-State packing inside `render`, renderer work and output synchronization. It excludes source rollout, disk loading, initial device transfer, batch indexing and initialization. Report mean batch latency ± sample SD (`ddof=1`), with throughput `batch / mean_latency`. Before/after speedup is baseline mean latency divided by candidate mean latency. This experiment measures our renderer before/after; it does **not** measure source throughput or online step-plus-render speedup.

Source MSE is the RGB mean squared difference after division by 255, separately for each saved frame. Report per-frame mean ± sample SD, worst frame, and count ≤0.001. Baseline/candidate saved output images are also compared directly for exact equality, maximum channel change and normalized MSE. Batch-capacity/style tests cover padded/chunked requests separately. A 32-frame optimization probe complements the maintained acceptance gate; it does not replace that gate or establish all possible states/tasks/resolutions.

## Final paired results

Populate these rows from the final same-allocation measurements. Include the individual latency/SD/FPS rows in the associated machine-readable report.

| Domain | CPU B1 / B64 speedup | GPU B1 / B64 / B256 speedup | Worst source MSE CPU / CUDA | Baseline pixels unchanged |
|---|---|---|---|---|
| Cheetah | [PENDING] | [PENDING] | [PENDING] | [PENDING] |
| Hopper | [PENDING] | [PENDING] | [PENDING] | [PENDING] |
| Walker | [PENDING] | [PENDING] | [PENDING] | [PENDING] |
| Humanoid | [PENDING] | [PENDING] | [PENDING] | [PENDING] |
| Quadruped | [PENDING] | [PENDING] | [PENDING] | [PENDING] |

## Diagnostic GPU stage profile

An RTX 3090 diagnostic timed B64 stages using a persistent nondefault CUDA stream, explicit same-stream CUDA events and captured repeated launches. These figures diagnose the work split; they are not the final paired throughput result. Each number below is a mean in milliseconds.

| Domain | Public render | Captured complete GPU frame | Floor/reflection | Primary ray rendering |
|---|---:|---:|---:|---:|
| Cheetah | 1.7214 | 0.2309 | 0.0833 | 0.0710 |
| Hopper | 1.6814 | 0.2172 | 0.0733 | 0.0631 |
| Walker | 1.7802 | 0.3259 | 0.1558 | 0.0964 |
| Humanoid | 2.1541 | 0.5631 | 0.3340 | 0.1365 |
| Quadruped | 2.1683 | 0.5726 | 0.3462 | 0.1366 |

The approximately 1.45–1.60 ms difference between public rendering and the captured GPU frame includes work outside that capture: State packing, uploads, host launches, synchronization and output conversion. This profile does not attribute that difference among those components, and subtracting timings is not a CPU-utilization measurement. Individual stages are timed in isolation, so their sum need not equal complete-frame time. The results support improving batch amortization before spending substantial effort on small shader arithmetic changes. Full raw samples and sample SD are in the profiling JSON.
