from pathlib import Path
import json,hashlib,tarfile,io,base64,shlex
root=Path(__file__).parent;repo=Path('/Users/samib/stable-envs');out=root/'source-gate-v3';out.mkdir()
source=root/'candidate-v2'
with tarfile.open(source/'source.tar.gz') as t:blobs={m.name:t.extractfile(m).read() for m in t if m.isfile()}
name='scripts/benchmarks/renderer_table/common.py';blobs[name]=(repo/name).read_bytes()
manifest=json.loads(blobs['manifest.json']);manifest['files'][name]=hashlib.sha256(blobs[name]).hexdigest();blobs['manifest.json']=json.dumps(manifest,indent=2).encode()
(out/'manifest.json').write_bytes(blobs['manifest.json'])
with tarfile.open(out/'source.tar.gz','w:gz') as t:
 for n,b in blobs.items():
  m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
bootstrap=(source/'bootstrap.py').read_text();a=bootstrap.index(' status=0');b=bootstrap.index(' buffer=io.BytesIO()',a)
bootstrap=bootstrap[:a]+" nodes=json.loads((root/'required.json').read_text())[family]\n status=subprocess.run([python,'-m','pytest','-v','-rs',*nodes,'--contract-profile='+family,'--contract-device='+device,'--contract-source=/oscar/scratch/sboughan/se-semantic-recovery/swm-reference','--contract-candidate-manifest='+str(root/'manifest.json'),'--contract-output='+str(root/'evidence'),'--junitxml=run.xml','--basetemp=pytest-temp','-o','junit_family=legacy']).returncode\n"+bootstrap[b:]
(out/'bootstrap.py').write_text(bootstrap)
cmd=['srun','--partition=3090-gcondo','--qos=cs-3090-gcondo','--cpus-per-task=2','--mem=32G','--time=01:00:00','--job-name=se-cube-source-gate','--gres=gpu:1','--exclude=gpu2504','python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))','ogbench','cuda']
d=out/'cuda';d.mkdir()
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
(d/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(d/'run.log'))+' 2> '+shlex.quote(str(d/'stderr.log'))+'\n')
