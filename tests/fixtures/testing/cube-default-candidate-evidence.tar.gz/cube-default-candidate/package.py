import json,shutil,sys,tarfile
from pathlib import Path
ROOT=Path(__file__).parent;REPO=Path('/Users/samib/stable-envs');sys.path.insert(0,str(REPO))
from stable_envs.testing.evidence import EvidenceRun,sha256,verify_seal
out=REPO/'tests/fixtures/testing/cube-default-oscar-evidence.tar.gz'
validation=out.with_name('cube-default-oscar-validation.json')
assert not out.exists() and not validation.exists()
report=json.loads((ROOT/'summary-draft.json').read_text())
for name,h in report['candidate_files'].items():assert sha256(REPO/name)==h,name
scheduler=(ROOT/'scheduler.txt').read_text()
for job in ('7092266','7092268'):
 row=next(l.split('|') for l in scheduler.splitlines() if l.startswith(job+'|'))
 assert row[3]=='COMPLETED' and row[4]=='0:0',row
report['jobs']={'cuda':'7092266','cpu':'7092268','terminal_evidence':'scheduler.txt'}
run=EvidenceRun(ROOT/'sealed');logs=[]
def copy(source,target):
 if source.is_dir():
  for p in sorted(source.iterdir()):
   if p.name!='__pycache__':copy(p,target/p.name)
 elif source.is_file():
  assert not source.is_symlink();target.parent.mkdir(parents=True,exist_ok=True)
  if source.name=='run.log':
   original=source.read_bytes();kept=b''.join(l for l in original.splitlines(keepends=True) if not l.startswith(b'EVIDENCE_BASE64 '));target.write_bytes(kept)
   logs.append(dict(path=str(target.relative_to(run.root)),original_sha256=sha256(source),packaged_sha256=sha256(target),transport_removed=True))
  else:shutil.copy2(source,target)
copy(ROOT/'candidate-v2',run.root/'candidate-v2')
for name in ('baseline','baseline-v2','baseline-v3','candidate-v1','scene-diagnostic'):
 if (ROOT/name).exists():copy(ROOT/name,run.root/'diagnostics'/name)
for name in ('prepare.py','probe.py','collect.py','summarize.py','package.py','scene_probe_prepare.py','scheduler.txt','local.log','local.xml','wheel-smoke.log','wheel-build-v3.log','dist'):
 copy(ROOT/name,run.root/name)
if (ROOT/'comparison.png').exists():copy(ROOT/'comparison.png',run.root/'comparison.png')
csv=REPO/'tests/fixtures/testing/cube-default-cuda-performance.csv';copy(csv,run.root/'performance.csv')
report['performance']['csv_sha256']=sha256(csv)
report['diagnostics']={'baseline/cuda':'Rejected GPU ECC failure on gpu2504; no render measurement','baseline/cuda-retry':'Rejected benchmark batch mismatch','baseline-v2':'Rejected lossy slash encoding of nested State keys; replaced with JSON tuple encoding','baseline-v3':'Successful initial four-backend probe; paired candidate-v2 results are authoritative','candidate-v1':'Rejected constructor device-type error; canceled after diagnosis','scene-diagnostic':'Experimental Scene fidelity eligibility only in exported snapshot; no production change or acceptance'}
run.json('transport-log-index.json',logs);run.json('summary.json',report);seal=run.seal();verify_seal(run.root)
with out.open('xb') as stream:
 with tarfile.open(fileobj=stream,mode='w:gz') as t:t.add(run.root,arcname='cube-default')
report['artifact_archive']=dict(path=str(out.relative_to(REPO)),sha256=sha256(out),seal='cube-default/SHA256SUMS',seal_files=len(seal))
with validation.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(out,out.stat().st_size,'sealed files',len(seal))
