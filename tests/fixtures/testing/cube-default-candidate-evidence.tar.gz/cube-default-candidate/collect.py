from pathlib import Path
import base64,hashlib,io,tarfile
root=Path(__file__).parent
for p in root.glob('*/*/run.log'):
 lines=[s.split(' ',1)[1] for s in p.read_text().splitlines() if s.startswith('EVIDENCE_BASE64 ')]
 if not lines:continue
 raw=base64.b64decode(lines[-1]);out=p.parent/'artifacts'
 if out.exists():continue
 out.mkdir()
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as a:a.extractall(out,filter='data')
 (p.parent/'artifacts.sha256').write_text(hashlib.sha256(raw).hexdigest()+'\n')
 print(out)
