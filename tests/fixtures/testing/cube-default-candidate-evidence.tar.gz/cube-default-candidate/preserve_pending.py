from pathlib import Path
import hashlib,json,shutil,sys,tarfile,csv,xml.etree.ElementTree as ET
import numpy as np
ROOT=Path(__file__).parent;REPO=Path('/Users/samib/stable-envs');sys.path.insert(0,str(REPO))
from stable_envs.testing.evidence import EvidenceRun,sha256,verify_seal
run=ROOT/'candidate-v2';manifest=json.loads((run/'manifest.json').read_text())
for f,h in manifest['files'].items():
 if f.startswith('stable_envs/'):assert sha256(REPO/f)==h,f
report=dict(status='PENDING_A40_REGRESSIONS_AND_TERMINAL_STATUS',accepted=False,baseline_commit=manifest['commit'],source_commit='176d54532b3c0a251a4f509b74f2fdacc143a63d',candidate_manifest='candidate-v2/manifest.json',source_gates={},remaining=['Run three immutable A40-pinned golden fixtures on A40; 3090 skips are not passes','Collect standalone CUDA gate job 7093278 and terminal scheduler evidence','Only then merge candidate into sami-dev and update accepted backend scope'],scope='Cube candidate default CUDA render at 64px. Scene diagnostics are not a production change or promotion.')
for device in ('cpu','cuda'):
 p=run/device/'artifacts';verify_seal(p/'evidence');r=json.loads((p/'evidence/result.json').read_text())
 assert r['status']=='PASS' and r['required']==r['passed']==72
 entries={}
 for t in ET.parse(p/'run.xml').iter('testcase'):
  props={v.attrib['name']:v.attrib['value'] for v in t.findall('properties/property')}
  if 'mse_max' not in props:continue
  name=t.attrib['name'].split('[')[1].split('-seed')[0]
  e=entries.setdefault(name,dict(cases=0,frames=0,mse_max=0.,backend=props['candidate_backend']))
  e['cases']+=1;e['frames']+=int(props['frames']);e['mse_max']=max(e['mse_max'],float(props['mse_max']))
 report['source_gates'][device]=dict(passed=72,required=72,registrations=entries,hardware=json.loads((p/'hardware.json').read_text()),artifact=str(p.relative_to(ROOT)))
report['source_gates']['cuda']['bundle_failure']='Source tests passed 72/72; later regression collection failed because exported helper was missing; overall job 7092266 exited 4. Standalone rerun 7093278 remains to be collected.'
reg=list(ET.parse(ROOT/'regressions-v1/cuda/artifacts/regressions.xml').iter('testcase'))
report['gpu_regressions']=dict(passed=1,skipped=3,skip_reason='Committed golden GPU is NVIDIA A40; run used RTX 3090',passed_scope='Cube default-resolution batch/chunk/style/nonmutation, including 257 rows',artifact='regressions-v1/cuda/artifacts/regressions.xml')
assert len(reg)==4 and sum(t.find('skipped') is not None for t in reg)==3
p=run/'cuda/artifacts'
for prefix in ('baseline/probe','probe'):verify_seal(p/prefix)
for backend,ss in [('mjwarp',1),('mjwarp_fidelity',1),('mjwarp_fidelity',2)]:
 with np.load(p/f'baseline/probe/{backend}-{ss}.npz') as a,np.load(p/f'probe/{backend}-{ss}.npz') as b:np.testing.assert_array_equal(a['frames'],b['frames'])
with np.load(p/'baseline/probe/states.npz') as a,np.load(p/'probe/states.npz') as b:
 assert set(a.files)==set(b.files)
 for key in a.files:np.testing.assert_array_equal(a[key],b[key])
old=json.loads((p/'baseline/probe/result.json').read_text());new=json.loads((p/'probe/result.json').read_text())
lookup=lambda rs,backend,ss:next(r for r in rs if r['backend']==backend and r['supersample']==ss)
candidate=lookup(new,'auto',None);previous=lookup(old,'auto',None);fid=lookup(old,'mjwarp_fidelity',2);source=lookup(new,'source-opengl',1)
rows=[]
for i,t in enumerate(candidate['timings']):
 b=t['batch'];r=dict(env='swm/OGBCube-v0',status='CANDIDATE_NOT_ACCEPTED',resolution=64,batch=b,independent_states=32,warmups=3,timing_samples=6,mse_mean=candidate['mse_mean'],mse_sd=candidate['mse_sd'],mse_max=candidate['mse_max'])
 for label,data in [('ours_gpu',candidate),('source_gpu',source),('previous_default_gpu',previous),('previous_fidelity_gpu',fid)]:
  samples=np.array(data['timings'][i]['seconds']);assert data['timings'][i]['batch']==b
  r.update({label+'_fps':b/samples.mean(),label+'_fps_sd':float((b/samples).std(ddof=1)),label+'_batch_ms_mean':1000*samples.mean(),label+'_batch_ms_sd':1000*samples.std(ddof=1)})
 for label in ('source_gpu','previous_default_gpu','previous_fidelity_gpu'):r['speedup_vs_'+label]=r['ours_gpu_fps']/r[label+'_fps']
 rows.append(r)
report['performance']=dict(rows=rows,scope='Warmed public render of saved RenderStates, synchronization included. Disk, rollout, projection, initial transfer and indexing excluded. B64/B256 repeat 32 independent reached States. Same RTX3090 allocation. Source public GPU OpenGL renders ready independent source instances serially and returns NumPy RGB including readback; ours returns CUDA RGB. This is not a 1000-independent-frame or online benchmark.',old_default_mse_mean=previous['mse_mean'],old_default_mse_max=previous['mse_max'],explicit_cuda_paths_pixel_identical=True,source_and_state_corpora_identical=True)
report['scene_diagnostic']={}
for name in ('scene-diagnostic','scene-sampling-diagnostic'):
 p=ROOT/name/'cuda/artifacts/probe';verify_seal(p)
 report['scene_diagnostic'][name]=json.loads((p/'result.json').read_text())
report['scene_regions_4x']=json.loads((ROOT/'scene-regions.json').read_text())
report['local_checks']=dict(unit_tests=28,ruff='PASS',diff_check='PASS',mkdocs_strict='PASS',wheel_smoke='PASS outside checkout using preinstalled dependencies, not all-family or fresh dependency-resolution acceptance',wheel_hashes={p.name:sha256(p) for p in (ROOT/'dist').iterdir()})
folder=REPO/'tests/fixtures/testing';csv_path=folder/'cube-default-candidate-performance.csv'
with csv_path.open('x') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
report['performance']['csv_sha256']=sha256(csv_path)
sealed=EvidenceRun(ROOT/'pending-checkpoint');logs=[]
def copy(source,target):
 if source.is_dir():
  for child in sorted(source.iterdir()):
   if child.name!='__pycache__':copy(child,target/child.name)
 elif source.is_file():
  assert not source.is_symlink();target.parent.mkdir(parents=True,exist_ok=True)
  if source.name=='run.log':
   data=source.read_bytes();target.write_bytes(b''.join(l for l in data.splitlines(keepends=True) if not l.startswith(b'EVIDENCE_BASE64 ')))
   logs.append(dict(path=str(target.relative_to(sealed.root)),original_sha256=hashlib.sha256(data).hexdigest(),packaged_sha256=sha256(target)))
  else:shutil.copy2(source,target)
for name in ('candidate-v2','regressions-v1','regressions-a40','scene-diagnostic','scene-sampling-diagnostic','source-gate-v3'):
 copy(ROOT/name,sealed.root/name)
for name in ('baseline','baseline-v2','baseline-v3','candidate-v1'):copy(ROOT/name,sealed.root/'diagnostics'/name)
for name in ('probe.py','prepare.py','collect.py','prepare_regressions.py','prepare_source_gate.py','scene_probe_prepare.py','scene_sampling_prepare.py','summarize.py','package.py','preserve_pending.py','local.log','local.xml','docs.log','wheel-build-v3.log','wheel-smoke.log','dist','comparison.png','scene-comparison.png','scene-4x-comparison.png','scene-regions.json'):copy(ROOT/name,sealed.root/name)
copy(csv_path,sealed.root/'performance.csv');sealed.json('summary.json',report);sealed.json('transport-log-index.json',logs)
seal=sealed.seal();archive=folder/'cube-default-candidate-evidence.tar.gz'
with archive.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as t:t.add(sealed.root,arcname='cube-default-candidate')
report['archive']=dict(path=str(archive.relative_to(REPO)),sha256=sha256(archive),seal_files=len(seal))
with (folder/'cube-default-candidate-validation.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
shutil.copy2(ROOT/'comparison.png',folder/'cube-default-candidate.png')
print(archive,archive.stat().st_size,'sealed files',len(seal))
