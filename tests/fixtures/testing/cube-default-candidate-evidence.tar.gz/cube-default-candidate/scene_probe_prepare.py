from pathlib import Path
import json,hashlib,subprocess,tarfile,io,base64,shlex
root=Path(__file__).parent;out=root/'scene-diagnostic';out.mkdir()
source=root/'candidate-v2'
with tarfile.open(source/'source.tar.gz') as t:blobs={m.name:t.extractfile(m).read() for m in t if m.isfile()}
probe=(root/'probe.py').read_text().split('from contextlib import ExitStack, closing')[0]
probe=probe.replace("c.domain=='Cube'","c.domain=='Scene'").replace("'OGBCube'","'OGBScene'")
probe=probe.replace("[('auto',None),('mjwarp',1),('mjwarp_fidelity',1),('mjwarp_fidelity',2),('opengl',1)]","[('auto',None),('mjwarp_fidelity',1),('mjwarp_fidelity',2)]")
probe+="out.json('result.json',report);out.seal()\n"
blobs['probe.py']=probe.encode()
name='stable_envs/envs/ogbench/manipulation_renderer.py'
s=blobs[name].decode().replace('    if backend == "mjwarp_fidelity" and family != "Cube":\n        raise ValueError("mjwarp_fidelity is currently validated only for Cube")\n','')
blobs[name]=s.encode()
blobs.pop('baseline-code.tar.gz')
manifest=json.loads(blobs['manifest.json']);manifest['experimental']='Scene fidelity eligibility guard removed only in this exported diagnostic; no production promotion'
manifest['files']={n:hashlib.sha256(v).hexdigest() for n,v in blobs.items() if n not in ('manifest.json','required.json')}
blobs['manifest.json']=json.dumps(manifest,indent=2).encode()
(out/'manifest.json').write_bytes(blobs['manifest.json'])
with tarfile.open(out/'source.tar.gz','w:gz') as t:
 for n,b in blobs.items():
  m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
bootstrap=(root/'baseline-v3/bootstrap.py').read_text()
(out/'bootstrap.py').write_text(bootstrap)
cmd=['srun','--partition=3090-gcondo','--qos=cs-3090-gcondo','--cpus-per-task=2','--mem=32G','--time=01:00:00','--job-name=se-scene-fidelity-probe','--gres=gpu:1','--exclude=gpu2504','python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))','ogbench','cuda']
d=out/'cuda';d.mkdir()
ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
(d/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(d/'run.log'))+' 2> '+shlex.quote(str(d/'stderr.log'))+'\n')
