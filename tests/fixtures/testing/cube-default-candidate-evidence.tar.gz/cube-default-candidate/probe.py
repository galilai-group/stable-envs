import json,sys,time
from pathlib import Path
import numpy as np
import torch
from tensordict import TensorDict
import stable_envs as se
from tests.helpers.reference.bridges import load_source
from tests.helpers.reference.ogbench_pixels import ogbench_trace
from tests.helpers.reference.profiles import PROFILES
from stable_envs.testing.evidence import EvidenceRun

torch.set_num_threads(1)
load_source('/oscar/scratch/sboughan/se-semantic-recovery/swm-reference','ogbench')
out=EvidenceRun('probe'); case=next(c for c in PROFILES['ogbench'] if c.domain=='Cube')
traces=[ogbench_trace(case,seed,'float64',8,'cuda')[0] for seed in (17,42)]
states=torch.cat([torch.stack(t.states,1).reshape(-1) for t in traces])
frames=np.concatenate([t.frames.reshape(-1,64,64,3) for t in traces])
out.arrays('states.npz',source_frames=frames,**{'state/'+json.dumps(list(k) if isinstance(k,tuple) else [k]):v.numpy() for k,v in states.items(True,True)})
with np.load(out.root/'states.npz',allow_pickle=False) as a:
 states=TensorDict({tuple(json.loads(k[6:])):torch.from_numpy(a[k]) for k in a.files if k.startswith('state/')},batch_size=[len(frames)]).to('cuda')
report=[]
for backend,ss in [('auto',None),('mjwarp',1),('mjwarp_fidelity',1),('mjwarp_fidelity',2),('opengl',1)]:
 with se.make('OGBCube',device='cuda',num_envs=len(states),size=64,backend=backend,supersample=ss) as env:
  render_states=env.to_render_state(states)
  actual=env.render(render_states).cpu().numpy(); mse=np.mean(((actual.astype(np.float64)-frames)/255)**2,axis=(1,2,3))
  out.arrays(f'{backend}-{ss}.npz',frames=actual)
  row=dict(backend=backend,supersample=ss,mse_mean=float(mse.mean()),mse_sd=float(mse.std(ddof=1)),mse_max=float(mse.max()),mse_per_state=mse.tolist(),timings=[])
  for b in (1,64,256):
   batch=render_states[torch.arange(b,device='cuda')%len(states)]
   for _ in range(3):env.render(batch)
   times=[]
   for _ in range(6):
    torch.cuda.synchronize();t=time.perf_counter();env.render(batch);torch.cuda.synchronize();times.append(time.perf_counter()-t)
   row['timings'].append(dict(batch=b,seconds=times,fps=b/np.mean(times)))
  print(json.dumps(row),flush=True);report.append(row)

from contextlib import ExitStack, closing
from tests.helpers.reference.ogbench_manipulation_semantics import load_oracle
oracle=load_oracle()
with ExitStack() as stack:
 sources=[]
 for seed in (17,42):
  actions=np.random.default_rng(seed+1000).uniform(-.2,.2,(2,8,5)).astype('float64')
  for lane,prefix in enumerate((0,7)):
   for step in range(8):
    src=stack.enter_context(closing(oracle.OwnedCube(entropy_seed=lane,width=64,height=64)))
    src.reset(seed=seed+lane)
    for _ in range(prefix):src.step(np.zeros(5))
    for action in actions[lane,:step+1]:src.step(action.copy())
    frame=src.render().copy()
    assert np.max(np.abs(frame.astype(int)-frames[len(sources)].astype(int)))<=1
    sources.append(src)
 row=dict(backend='source-opengl',supersample=1,timings=[])
 for b in (1,64,256):
  batch=[sources[i%len(sources)] for i in range(b)]
  for _ in range(3):
   for src in batch:src.render()
  times=[]
  for _ in range(6):
   torch.cuda.synchronize();t=time.perf_counter()
   for src in batch:src.render()
   torch.cuda.synchronize();times.append(time.perf_counter()-t)
  row['timings'].append(dict(batch=b,seconds=times,fps=b/np.mean(times)))
 report.append(row);print(json.dumps(row),flush=True)
out.json('result.json',report);out.seal()

