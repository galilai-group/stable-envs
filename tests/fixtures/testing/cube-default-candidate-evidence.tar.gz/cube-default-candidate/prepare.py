import base64,hashlib,io,json,shlex,subprocess,sys,tarfile
from pathlib import Path
repo=Path.cwd();sys.path.insert(0,str(repo))
from tests.contracts.conftest import case_map
from tests.helpers.reference.profiles import PINS
root=Path('/private/tmp/se-cube-default-20261007');family=sys.argv[1];out=root/sys.argv[2];out.mkdir()
files=set(json.loads(Path('/private/tmp/se-dmc-pixels-20261007/gate-v3/manifest.json').read_text())['files'])
files.update(str(p.relative_to(repo)) for folder in ('stable_envs','tests/contracts','tests/helpers/reference','tests/unit','scripts/testing') for p in (repo/folder).rglob('*.py'))
files.update(str(p.relative_to(repo)) for folder in ('tests/gpu','tests/fixtures/ogbench_renderer') for p in (repo/folder).rglob('*') if p.is_file())
blobs={f:(repo/f).read_bytes() for f in sorted(files) if (repo/f).exists()}
blobs['probe.py']=(root/'probe.py').read_bytes()
blobs['baseline-code.tar.gz']=subprocess.check_output(['git','archive','--format=tar.gz','HEAD','stable_envs'])
manifest=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tracked_dirty=True,files={n:hashlib.sha256(v).hexdigest() for n,v in blobs.items()})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');nodes=sorted(case_map(family));(out/'required.json').write_text(json.dumps({family:nodes},indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','w:gz') as tar:
 for f,data in blobs.items():
  info=tarfile.TarInfo(f);info.size=len(data);tar.addfile(info,io.BytesIO(data))
 for f in ('manifest.json','required.json'):tar.add(out/f,arcname=f)
bootstrap=Path('/private/tmp/se-fetch-readback-20261007/gate-v2/bootstrap.py').read_text()
a=bootstrap.index('pins=');b=bootstrap.index('subprocess.run',a)
pins=[f'{k}=={v}' for k,v in PINS[family].items()]+['pyyaml==6.0.3']
if family=='pusht':pins+=['shapely','opencv-python-headless']
bootstrap=bootstrap[:a]+'pins='+repr(pins)+'\n'+bootstrap[b:]
bootstrap=bootstrap.replace("if family in ('dmc','fetch'):","if family in ('dmc','fetch','ogbench'):")
a=bootstrap.index(' integration=subprocess.run');b=bootstrap.index(' buffer=io.BytesIO()',a)
bootstrap=bootstrap[:a]+" status=0\n if device=='cuda':\n  baseline=root/'baseline';baseline.mkdir()\n  with tarfile.open(root/'baseline-code.tar.gz') as archive:archive.extractall(baseline,filter='data')\n  (baseline/'probe.py').write_bytes((root/'probe.py').read_bytes())\n  status=subprocess.run([python,str(baseline/'probe.py')],cwd=baseline).returncode\n  candidate=subprocess.run([python,'probe.py'])\n  status=status or candidate.returncode\n nodes=json.loads((root/'required.json').read_text())[family]\n gate=subprocess.run([python,'-m','pytest','-v','-rs',*nodes,'--contract-profile='+family,'--contract-device='+device,'--contract-source=/oscar/scratch/sboughan/se-semantic-recovery/swm-reference','--contract-candidate-manifest='+str(root/'manifest.json'),'--contract-output='+str(root/'evidence'),'--junitxml=run.xml','--basetemp=pytest-temp','-o','junit_family=legacy'])\n status=status or gate.returncode\n if device=='cuda':\n  os.environ.update(SE_FIDELITY_TEST_DEVICE='cuda',SE_FIDELITY_TEST_FAMILY='OGB')\n  regression=subprocess.run([python,'-m','pytest','-v','-rs','tests/gpu/test_ogbench_golden.py','tests/unit/test_fidelity_backends.py::test_cube_fidelity_batch_and_nonmutation','--junitxml=regressions.xml'])\n  status=status or regression.returncode\n"+bootstrap[b:]
bootstrap=bootstrap.replace("'evidence','run.xml','hardware.json','xvfb.log','pytest-temp','readback-tests.xml','benchmark'", "'probe','baseline/probe','hardware.json','xvfb.log','evidence','run.xml','pytest-temp','regressions.xml'")
(out/'bootstrap.py').write_text(bootstrap)
for device in ('cpu','cuda'):
 d=out/device;d.mkdir();gpu=device=='cuda'
 cmd=['srun','--partition='+('3090-gcondo' if gpu else 'batch'),'--qos='+('cs-3090-gcondo' if gpu else 'normal'),'--cpus-per-task=2','--mem=32G','--time=01:00:00','--job-name=se-pixels-'+family+'-'+device]
 if gpu:cmd+=['--gres=gpu:1','--exclude=gpu2504']
 cmd+=['python3','-c','import base64;exec(base64.b64decode('+repr(base64.b64encode(bootstrap.encode()).decode())+'))',family,device]
 ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-S','/private/tmp/stable-envs-oscar-control','sboughan@sshcampus.ccv.brown.edu',shlex.join(cmd)]
 (d/'run.sh').write_text(shlex.join(ssh)+' < '+shlex.quote(str(out/'source.tar.gz'))+' > '+shlex.quote(str(d/'run.log'))+' 2> '+shlex.quote(str(d/'stderr.log'))+'\n')
print(out,len(nodes),pins)
