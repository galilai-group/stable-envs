"""Offline integrity/interpretation summary; never executes an environment."""

import argparse
import collections
import hashlib
import json
import math
import statistics
from pathlib import Path

STAGES = (
    "construction",
    "first_public_step",
    "reset",
    "restore",
    "public_step_no_pixels",
    "render_saved_state",
    "public_step_with_pixels",
    "raw_physics_two_control_rounds",
)
PAIR_FIELDS = (
    "action_dim",
    "action_dtype",
    "action_repeat",
    "control_substeps",
    "model",
    "output_device",
    "render_backend_request",
    "render_size",
    "render_supersample",
)


def audit(report, root):
    errors = []
    config = report["config"]
    rows = report["records"]
    counts = collections.Counter((r["env"], r["batch"], r["simulation_backend"]) for r in rows)
    if any(v != 1 for v in counts.values()):
        errors.append("duplicate records")
    hashes = {}
    for section in ("candidate_files", "benchmark_files"):
        mismatch = []
        for name, expected in report.get(section, {}).items():
            p = root / name
            if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != expected:
                mismatch.append(name)
        hashes[section] = {"files": len(report.get(section, {})), "mismatches": mismatch}
        errors.extend(f"{section}: {name}" for name in mismatch)
    bykey = {(r["env"], r["batch"], r["simulation_backend"]): r for r in rows}
    snapshots = []
    sample_counts = collections.Counter()
    adapters = collections.Counter()
    for row in rows:
        key = (row["env"], row["batch"], row["simulation_backend"])
        if row["status"] != "ok":
            continue
        meta = row["metadata"]
        adapters[(row["simulation_backend"], meta["simulation_adapter"], meta["execution_mode"])] += 1
        if meta["output_device"] != config["device"]:
            errors.append(f"{key}: device mismatch")
        if row["simulation_backend"] == "mjwarp" and (
            meta["simulation_adapter"] != "DMCWarpAdapter"
            or meta["execution_mode"] != "MUJOCO_WARP"
            or meta["physics_dtype"] != "float32"
        ):
            errors.append(f"{key}: unexpected direct Warp route")
        if row["simulation_backend"] == "native" and (
            meta["execution_mode"] != "DELEGATED_CPU" or meta["physics_dtype"] != "float64"
        ):
            errors.append(f"{key}: unexpected native route")
        for stage in STAGES:
            if stage not in row["metrics"]:
                errors.append(f"{key}: missing {stage}")
                continue
            metric = row["metrics"][stage]
            if stage == "construction":
                if metric.get("samples") != 1 or not math.isfinite(metric["wall_ms"]) or metric["wall_ms"] <= 0:
                    errors.append(f"{key}: construction metric")
                snapshots.extend(metric[p] for p in ("memory_before", "memory_after"))
                continue
            samples = metric["samples_ms"]
            sample_counts[(stage, len(samples))] += 1
            want = 1 if stage == "first_public_step" else config["repeats"]
            if len(samples) != want or any(not math.isfinite(x) or x <= 0 for x in samples):
                errors.append(f"{key}/{stage}: samples")
            for field, expected in [
                ("median_ms", statistics.median(samples)),
                ("min_ms", min(samples)),
                ("max_ms", max(samples)),
            ]:
                if not math.isclose(metric[field], expected, rel_tol=1e-12, abs_tol=1e-12):
                    errors.append(f"{key}/{stage}: {field}")
            if not metric["min_ms"] <= metric["p25_ms"] <= metric["median_ms"] <= metric["p75_ms"] <= metric["max_ms"]:
                errors.append(f"{key}/{stage}: quantile order")
            ordered = sorted(samples)
            for field, fraction in (("p25_ms", 0.25), ("p75_ms", 0.75)):
                position = (len(ordered) - 1) * fraction
                lower = int(position)
                upper = min(lower + 1, len(ordered) - 1)
                expected = ordered[lower] * (1 - position + lower) + ordered[upper] * (position - lower)
                if not math.isclose(metric[field], expected, rel_tol=1e-12, abs_tol=1e-12):
                    errors.append(f"{key}/{stage}: {field}")
            if not math.isfinite(metric["cpu_seconds_per_wall_second"]) or metric["cpu_seconds_per_wall_second"] < 0:
                errors.append(f"{key}/{stage}: parent CPU ratio")
            if "environment_transitions_per_second" in metric and not math.isclose(
                metric["environment_transitions_per_second"], row["batch"] * 1000 / metric["median_ms"], rel_tol=1e-12
            ):
                errors.append(f"{key}/{stage}: throughput")
            if not 0 <= metric["torch_peak_allocated_bytes"] <= metric["torch_peak_reserved_bytes"]:
                errors.append(f"{key}/{stage}: Torch memory")
            memory = metric["memory"]
            if not 0 <= memory["tracemalloc_current_bytes"] <= memory["tracemalloc_peak_bytes"]:
                errors.append(f"{key}/{stage}: tracemalloc")
            snapshots.extend(memory[p] for p in ("before", "after"))
            for field, delta in memory["deltas"].items():
                before, after = (memory[p][field] for p in ("before", "after"))
                if delta != (None if before is None or after is None else after - before):
                    errors.append(f"{key}/{stage}: {field} delta")
        if row["simulation_backend"] == "native":
            raw_setup = row["metrics"].get("raw_native_construction", {})
            if (
                raw_setup.get("samples") != 1
                or not math.isfinite(raw_setup.get("wall_ms", -1))
                or raw_setup.get("wall_ms", -1) <= 0
            ):
                errors.append(f"{key}: missing or invalid raw native setup cost")
    for snapshot in snapshots:
        if snapshot["rss_parent_and_workers_bytes"] != sum(snapshot["rss_bytes_by_pid"].values()):
            errors.append("RSS sum mismatch")
        if any(v < 0 for v in snapshot["rss_bytes_by_pid"].values()):
            errors.append("negative RSS")
        own = snapshot["nvml_parent_and_workers_used_bytes"]
        if own is not None and not 0 <= own <= snapshot["nvml_device_used_bytes"]:
            errors.append("invalid NVML accounting")
    pair_records = {(p["env"], p["batch"]): p for p in report.get("pairs", [])}
    pairs = []
    for env, batch in sorted({(r["env"], r["batch"]) for r in rows}):
        left, right = (bykey.get((env, batch, k)) for k in ("native", "mjwarp"))
        if not left or not right or left["status"] != "ok" or right["status"] != "ok":
            continue
        mismatch = [field for field in PAIR_FIELDS if left["metadata"].get(field) != right["metadata"].get(field)]
        errors.extend(f"{env}/{batch}: pair {field} mismatch" for field in mismatch)
        if pair_records and not pair_records[(env, batch)]["speedup_eligible"]:
            continue
        pairs.append(
            {
                "env": env,
                "batch": batch,
                "speedup_eligible": not mismatch,
                "native_over_mjwarp": {
                    stage: left["metrics"][stage]["wall_ms" if stage == "construction" else "median_ms"]
                    / right["metrics"][stage]["wall_ms" if stage == "construction" else "median_ms"]
                    for stage in STAGES
                },
            }
        )
    ranges = (
        {
            field: {
                "min": min(s[field] for s in snapshots if s[field] is not None),
                "max": max(s[field] for s in snapshots if s[field] is not None),
            }
            for field in (
                "rss_parent_and_workers_bytes",
                "nvml_device_used_bytes",
                "nvml_parent_and_workers_used_bytes",
            )
        }
        if snapshots
        else {}
    )
    return {
        "schema": "stable-envs-dmc-mjwarp-offline-audit/v1",
        "measurement_records": len(rows),
        "status_counts": dict(collections.Counter(r["status"] for r in rows)),
        "original_driver_complete": report.get("complete", False),
        "unique_measurement_keys": len(counts),
        "configured_measurement_count": len(config["envs"])
        * len(config["batches"])
        * len(config["simulation_backends"]),
        "unique_worker_pids": len({r.get("worker_pid") for r in rows if "worker_pid" in r}),
        "environments": dict(collections.Counter(r["env"] for r in rows)),
        "hash_checks": hashes,
        "audit_errors": errors,
        "resolved_routes": [
            {"backend": k[0], "adapter": k[1], "execution_mode": k[2], "records": v}
            for k, v in sorted(adapters.items())
        ],
        "timed_sample_counts": [
            {"stage": k[0], "samples_per_record": k[1], "records": v} for k, v in sorted(sample_counts.items())
        ],
        "memory_observed_ranges_bytes": ranges,
        "eligible_pairs": len(pairs),
        "pairs": pairs,
        "interpretation": [
            "Native physics executes on CPU and returns CUDA tensors; Warp physics executes on CUDA. These are explicitly different simulation routes, not two GPU engines.",
            "Public no-pixels timing uses one public action and still returns its final owned State, reward, observation and info; states=None suppresses history only.",
            "Public with-pixels timing adds the final frame. render_saved_state measures a fixed saved reset State. Rendering records backend=auto, not the resolved renderer implementation.",
            "Raw Warp measures two runtime.advance calls with precomputed controls, including interop and runtime guards. Raw native measures sequential local CPU lanes without public task/IPC/snapshot/render overhead. Raw is not a kernel-only comparison.",
            "Construction and first public step each have one timed sample. Reset and restore are separate stages. First-step memory profiling is an extra untimed second call, not a native/driver peak during cold capture.",
            "Construction measures the environment constructor and model initialization. Imports and initial CUDA context setup precede its timer; it does not measure total process startup.",
            "Each steady stage has five warmups and ten synchronized samples in this configuration. Physics advances during the step samples; this is one seed and zero normalized actions, not a workload distribution or tail-latency study.",
            "Fresh worker processes isolate records, but disk JIT caches can survive. First-step latency is not a guaranteed cold-compilation measurement.",
            "RSS and NVML are before/after samples, not transient peaks. RSS sums may count shared pages in multiple workers. NVML device totals include other processes. Stage allocations can include retained allocations from earlier phases.",
            "Torch allocator peaks exclude non-Torch Warp/driver allocations; tracemalloc excludes native allocations. Parent CPU/wall ratios omit child simulation workers and GPU utilization.",
            "The baseline revision is a caller label; native was measured from this worktree, not a separately checked-out baseline. Source hashes provide implementation provenance.",
            "For continued aggregates, each raw segment retains its own machine, device UUID and versions; ratios are allowed only within eligible same-segment native/Warp pairs.",
            "Performance evidence does not establish numerical correctness; numerical acceptance remains deferred.",
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    raw = args.report.read_bytes()
    result = audit(json.loads(raw), Path.cwd())
    result["input"] = {"path": str(args.report), "sha256": hashlib.sha256(raw).hexdigest()}
    text = json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.output:
        args.output.write_text(text)
    else:
        print(text, end="")
    raise SystemExit(bool(result["audit_errors"]))
