#!/bin/bash
set -u
cd /cs/home/rgao48/codex-dmc-mjwarp
export DMC_PY=/tmp/codex-dmc-mjwarp-124769/venv/bin/python
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=. MUJOCO_GL=egl
export SE_DMC_MJWARP_BASELINE_REVISION=37c7b9edd51ea82d7733277d7ead34579bc225c4
if [ ! -x "$DMC_PY" ]; then
  echo 'Pinned measuring interpreter unavailable; refusing to substitute dependencies.' >&2
  exit 2
fi
"$DMC_PY" -u results/resume_dmc_benchmark.py --run
status=$?
# All measurements and diagnostics live in the persistent results directory.
# Keep the interpreter if orchestration stopped before every matrix slot was attempted.
if python -c 'import json,sys; from pathlib import Path; p=Path("results/dmc-mjwarp-benchmark-16-continued.json"); sys.exit(not (p.exists() and json.loads(p.read_text()).get("complete",False)))'; then
  rm -rf -- /tmp/codex-dmc-mjwarp-124769
  echo "Removed this task's temporary runtime after the completed measurement matrix."
fi
exit "$status"
