from pathlib import Path
import hashlib,json,time,psutil
path=Path('results/dmc-mjwarp-benchmark-16.json')
process=psutil.Process(3089411)
if 'benchmarks/dmc_mjwarp.py' not in ' '.join(process.cmdline()):
 raise RuntimeError('Unexpected process; refusing to stop it')
while process.is_running():
 report=json.loads(path.read_text())
 records=report['records']
 if len(records)>=50 and len(records)%2==0:
  process.suspend()
  # The driver writes atomically before starting its next fresh worker.
  raw=path.read_bytes(); report=json.loads(raw)
  children=process.children(recursive=True)
  for child in children:
   try: child.terminate()
   except psutil.NoSuchProcess: pass
  process.terminate();process.resume()
  _,alive=psutil.wait_procs([process,*children],timeout=10)
  for item in alive:
   try:item.kill()
   except psutil.NoSuchProcess:pass
  record={'reason':'Renew Slurm reservation at a completed pair boundary; continuation retains this raw report.','records':len(report['records']),'report_sha256':hashlib.sha256(raw).hexdigest(),'terminated_driver_pid':3089411,'discarded_inflight_child_pids':[x.pid for x in children]}
  Path('results/dmc-mjwarp-initial-stop.json').write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps(record),flush=True)
  break
 time.sleep(1)
