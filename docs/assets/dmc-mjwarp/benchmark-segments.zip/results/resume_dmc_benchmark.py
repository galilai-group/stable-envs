#!/usr/bin/env python3
"""Plan or explicitly resume the frozen 16-environment benchmark.

Default: print a plan without running anything or writing evidence.
Run only after the original benchmark has stopped:
  DMC_PY=/path/to/python python results/resume_dmc_benchmark.py --run
Rebuild the aggregate without running physics:
  python results/resume_dmc_benchmark.py --aggregate-only
All paths are relative to the current repository working directory. Existing
errors are never replaced or rerun. A lone successful row is preserved in its
raw report, but both backends are rerun together for a matched comparison.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import subprocess
import sys
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

CELLS = (
    "DMCAcrobotBalance",
    "DMCBallInCupCatch",
    "DMCCartpoleBalance",
    "DMCCartpoleSwingup",
    "DMCCheetahRun",
    "DMCFingerSpin",
    "DMCFingerTurnEasy",
    "DMCFingerTurnHard",
    "DMCHopperHop",
    "DMCHumanoidWalk",
    "DMCManipulatorBringBall",
    "DMCPendulumSwingup",
    "DMCPointMassEasy",
    "DMCQuadrupedWalk",
    "DMCSwimmerSwimmer6",
    "DMCWalkerWalk",
)
BATCHES = (1, 16, 64, 256, 1024)
BACKENDS = ("native", "mjwarp")
CONFIG_FIELDS = ("device", "seed", "warmup", "repeats", "threads", "size", "supersample", "backend")
EXPECTED = {(name, batch, backend) for name in CELLS for batch in BATCHES for backend in BACKENDS}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def file_ref(path, root):
    return os.path.relpath(path, root)


def verify_report(report, root, anchor=None):
    if report.get("benchmark") != "dmc-mjwarp":
        raise ValueError("Expected an original dmc-mjwarp benchmark report, not an aggregate")
    for section in ("candidate_files", "benchmark_files"):
        entries = report.get(section)
        if not isinstance(entries, dict) or not entries:
            raise ValueError(f"Missing {section}")
        if section == "benchmark_files" and set(entries) != {"benchmarks/dmc_mjwarp.py", "benchmarks/_common.py"}:
            raise ValueError("Unexpected benchmark hash inventory")
        for name, expected in entries.items():
            path = root / name
            if (
                Path(name).is_absolute()
                or ".." in Path(name).parts
                or not path.is_file()
                or sha(path.read_bytes()) != expected
            ):
                raise ValueError(f"Current source hash mismatch: {name}")
        if anchor is not None and entries != anchor[section]:
            raise ValueError(f"Segment {section} differs from original report")
    config = report["config"]
    if anchor is not None:
        if any(config.get(k) != anchor["config"].get(k) for k in CONFIG_FIELDS):
            raise ValueError("Segment measurement configuration differs from original report")
        if report.get("runtime_environment") != anchor.get("runtime_environment"):
            raise ValueError("Segment thread environment differs from original report")
        if report.get("baseline_revision") != anchor.get("baseline_revision"):
            raise ValueError("Segment baseline label differs from original report")
    if not report.get("machine"):
        raise ValueError("Missing measured machine metadata")
    keys = set()
    for row in report["records"]:
        key = (row["env"], row["batch"], row["simulation_backend"])
        if key not in EXPECTED or key in keys:
            raise ValueError(f"Duplicate or out-of-scope row: {key}")
        if row.get("status") not in ("ok", "error"):
            raise ValueError(f"Unexpected raw result status: {key}")
        keys.add(key)


def read_source(path, root, anchor=None):
    raw = path.read_bytes()
    report = json.loads(raw)
    verify_report(report, root, anchor)
    return {"path": path, "sha256": sha(raw), "report": report}


def select_pairs(sources):
    """Select complete same-segment pairs; every error takes precedence forever."""
    groups = defaultdict(list)
    for source in sources:
        pairs = defaultdict(dict)
        for row in source["report"]["records"]:
            pairs[(row["env"], row["batch"])][row["simulation_backend"]] = row
        for pair, rows in pairs.items():
            groups[pair].append((source, rows))
    selected, requests = {}, defaultdict(list)
    for name in CELLS:
        for batch in BATCHES:
            entries = groups[(name, batch)]
            errors = {
                backend: next(
                    (
                        (source, rows[backend])
                        for source, rows in entries
                        if backend in rows and rows[backend]["status"] == "error"
                    ),
                    None,
                )
                for backend in BACKENDS
            }
            if any(errors.values()):
                choices = {
                    backend: errors[backend]
                    or next(((source, rows[backend]) for source, rows in entries if backend in rows), None)
                    for backend in BACKENDS
                }
                missing = tuple(backend for backend in BACKENDS if choices[backend] is None)
            else:
                complete = next(((source, rows) for source, rows in entries if set(rows) == set(BACKENDS)), None)
                choices = {backend: (complete[0], complete[1][backend]) if complete else None for backend in BACKENDS}
                missing = () if complete else BACKENDS
            selected[(name, batch)] = choices
            if missing:
                requests[(name, missing)].append(batch)
    return selected, [
        {"env": name, "batches": batches, "backends": list(backends)} for (name, backends), batches in requests.items()
    ]


def aggregate(sources, root, attempts):
    selected, requests = select_pairs(sources)
    anchor = sources[0]["report"]
    rows, pairs = [], []
    for (name, batch), choices in selected.items():
        provenance = {}
        for backend, choice in choices.items():
            if choice is None:
                row = {
                    "env": name,
                    "batch": batch,
                    "simulation_backend": backend,
                    "status": "incomplete",
                    "reason": "No selected completed measurement; continuation is required",
                }
            else:
                source, original = choice
                row = copy.deepcopy(original)
                provenance[backend] = {"segment": file_ref(source["path"], root), "segment_sha256": source["sha256"]}
                row["continuation_provenance"] = provenance[backend]
            rows.append(row)
        same_segment = len(provenance) == 2 and provenance["native"] == provenance["mjwarp"]
        pair_rows = rows[-2:]
        pairs.append(
            {
                "env": name,
                "batch": batch,
                "segments": provenance,
                "same_segment": same_segment,
                "speedup_eligible": same_segment and all(row["status"] == "ok" for row in pair_rows),
                "statuses": {row["simulation_backend"]: row["status"] for row in pair_rows},
            }
        )
    assert len(rows) == len({(r["env"], r["batch"], r["simulation_backend"]) for r in rows}) == 160
    segments = []
    for source in sources:
        report = source["report"]
        segments.append(
            {
                "path": file_ref(source["path"], root),
                "sha256": source["sha256"],
                "records": len(report["records"]),
                "driver_complete": report.get("complete", False),
                "metadata": {
                    k: copy.deepcopy(v)
                    for k, v in report.items()
                    if k not in ("records", "candidate_files", "benchmark_files")
                },
                "all_candidate_and_benchmark_hashes_match_current_files": True,
            }
        )
    return {
        "schema": "stable-envs-dmc-mjwarp-continuation/v1",
        "benchmark": "dmc-mjwarp-continuation",
        "config": copy.deepcopy(anchor["config"]),
        "candidate_files": anchor["candidate_files"],
        "benchmark_files": anchor["benchmark_files"],
        "machine": None,
        "machine_scope": "Machine, device UUID, dependency versions and runtime metadata are recorded separately for every segment. Hardware homogeneity is not assumed.",
        "complete": not requests,
        "successful": all(row["status"] == "ok" for row in rows),
        "success_scope": "All 160 selected measurements succeeded; prior failed or interrupted commands remain listed separately.",
        "counts": {status: sum(row["status"] == status for row in rows) for status in ("ok", "error", "incomplete")},
        "records": rows,
        "pairs": pairs,
        "segments": segments,
        "continuation_attempts": attempts,
        "failed_or_interrupted_attempts": [
            attempt["path"] for attempt in attempts if attempt["record"].get("exit_status") != 0
        ],
        "remaining_requests": requests,
        "policy": "Existing errors are retained. Incomplete successful pairs are replaced only as complete same-segment pairs; their original rows remain in raw reports. A lone error is retained while only its missing backend is attempted; split/error pairs are ineligible for speedup.",
        "driver_sha256": sha(Path(__file__).read_bytes()),
    }


def command(request, config, output, interpreter):
    argv = [
        interpreter,
        "benchmarks/dmc_mjwarp.py",
        "--envs",
        request["env"],
        "--batches",
        ",".join(map(str, request["batches"])),
        "--simulation-backends",
        ",".join(request["backends"]),
        "--output",
        str(output),
    ]
    for name in CONFIG_FIELDS:
        if config.get(name) is not None:
            argv.extend(("--" + name, str(config[name])))
    return argv


def load_attempts(directory):
    attempts = []
    for path in sorted(directory.glob("segment-*.attempt.json")):
        raw = path.read_bytes()
        attempts.append({"path": str(path), "sha256": sha(raw), "record": json.loads(raw)})
    return attempts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("results/dmc-mjwarp-benchmark-16.json"))
    parser.add_argument("--segments", type=Path, default=Path("results/dmc-mjwarp-benchmark-continuation"))
    parser.add_argument("--output", type=Path, default=Path("results/dmc-mjwarp-benchmark-16-continued.json"))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--run",
        action="store_true",
        help="Explicitly run only the missing work after the original benchmark has stopped",
    )
    mode.add_argument(
        "--aggregate-only", action="store_true", help="Write aggregate with explicit incomplete rows; run nothing"
    )
    args = parser.parse_args()
    root = Path.cwd()
    if args.output.resolve() == args.input.resolve():
        parser.error("Aggregate output must not overwrite the original report")
    original = read_source(args.input, root)
    config = original["report"]["config"]
    if (
        set(config["envs"]) != set(CELLS)
        or len(config["envs"]) != 16
        or config["batches"] != list(BATCHES)
        or config["simulation_backends"] != list(BACKENDS)
    ):
        parser.error("Original report must describe the full frozen 160-cell matrix")
    interpreter = os.environ.get("DMC_PY")
    if args.run and not interpreter:
        parser.error("--run requires DMC_PY to name the measuring Python interpreter")
    snapshots = list(args.segments.glob("original-*.json"))
    if any(path.name != f"original-{original['sha256']}.json" for path in snapshots):
        parser.error("Continuation directory belongs to a different original report; do not mix runs")
    sources = [original]
    for path in sorted(args.segments.glob("segment-*.json")):
        if not path.name.endswith(".attempt.json"):
            sources.append(read_source(path, root, original["report"]))
    _, requests = select_pairs(sources)
    if not args.run and not args.aggregate_only:
        print(
            json.dumps(
                {
                    "mode": "plan_only",
                    "input_sha256": original["sha256"],
                    "existing_segments": len(sources),
                    "requests": requests,
                    "commands": [
                        command(r, config, "SEGMENT_OUTPUT.json", interpreter or "$DMC_PY") for r in requests
                    ],
                },
                indent=2,
            )
        )
        return 0
    args.segments.mkdir(parents=True, exist_ok=True)
    snapshot = args.segments / f"original-{original['sha256']}.json"
    if snapshot.exists() and sha(snapshot.read_bytes()) != original["sha256"]:
        raise ValueError("Original snapshot hash mismatch")
    if not snapshot.exists():
        snapshot.write_bytes(args.input.read_bytes())
    if sha(snapshot.read_bytes()) != original["sha256"]:
        raise ValueError("Original input changed during snapshot; stop the initial benchmark before resuming")
    original["path"] = snapshot
    environment = os.environ.copy()
    for name, value in original["report"].get("runtime_environment", {}).items():
        if value is None:
            environment.pop(name, None)
        else:
            environment[name] = value
    label = original["report"].get("baseline_revision")
    if label is None:
        environment.pop("SE_DMC_MJWARP_BASELINE_REVISION", None)
    else:
        environment["SE_DMC_MJWARP_BASELINE_REVISION"] = label
    result = aggregate(sources, root, load_attempts(args.segments))
    atomic_json(args.output, result)
    if args.run:
        for request in requests:
            if sha(args.input.read_bytes()) != original["sha256"]:
                raise ValueError(
                    "Original input changed; do not run continuation concurrently with the original benchmark"
                )
            verify_report(original["report"], root)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
            output = args.segments / f"segment-{stamp}-{request['env']}-{uuid.uuid4().hex[:8]}.json"
            argv = command(request, config, output, interpreter)
            attempt_path = output.with_suffix(".attempt.json")
            stdout_path = output.with_suffix(".stdout.log")
            stderr_path = output.with_suffix(".stderr.log")
            attempt = {
                "request": request,
                "argv": argv,
                "started_utc": datetime.now(timezone.utc).isoformat(),
                "exit_status": None,
                "report": str(output),
                "stdout": str(stdout_path),
                "stderr": str(stderr_path),
            }
            atomic_json(attempt_path, attempt)
            with stdout_path.open("w") as stdout, stderr_path.open("w") as stderr:
                completed = subprocess.run(argv, cwd=root, env=environment, stdout=stdout, stderr=stderr, check=False)
            attempt.update(
                exit_status=completed.returncode,
                finished_utc=datetime.now(timezone.utc).isoformat(),
                report_written=output.is_file(),
            )
            atomic_json(attempt_path, attempt)
            if output.is_file():
                sources.append(read_source(output, root, original["report"]))
            result = aggregate(sources, root, load_attempts(args.segments))
            atomic_json(args.output, result)
            print(
                f"{request['env']} batches={request['batches']} backends={request['backends']} exit={completed.returncode}; counts={result['counts']}",
                flush=True,
            )
    # Report hashes are also carried in each selected row and segment entry.
    paths = [source["path"] for source in sources] + [args.output]
    (args.segments / "SHA256SUMS").write_text(
        "".join(f"{sha(path.read_bytes())}  {file_ref(path, args.segments)}\n" for path in paths)
    )
    print(
        json.dumps(
            {
                "output": str(args.output),
                "complete": result["complete"],
                "successful": result["successful"],
                "counts": result["counts"],
            },
            indent=2,
        )
    )
    return 0 if result["successful"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError) as error:
        print(f"Continuation stopped: {error}", file=sys.stderr)
        raise SystemExit(2) from error
