"""Index every slower registration, separating profiles from hypotheses."""
import csv
from collections import defaultdict
from pathlib import Path
OUT=Path('/Users/samib/stable-envs/docs/presentation-20261008')
byenv=defaultdict(list)
for r in csv.DictReader((OUT/'render-only.csv').open()):
 if r['status']=='COMPLETE' and r['candidate_device']==r['output_device'] and float(r['speedup_source_over_ours'])<1:byenv[r['env']].append(r)
rows=[]
for env,cells in sorted(byenv.items()):
 cpu=[r for r in cells if r['candidate_device']=='cpu'];gpu=[r for r in cells if r['candidate_device']=='cuda' and r['source_render_device']=='cuda'];fallback=[r for r in cells if r['candidate_device']=='cuda' and r['source_render_device']=='cpu']
 reason='Small-batch dispatch and setup overhead is a hypothesis; no B1 component profile in this campaign.';plan='Profile B1 Python, validation, tensor allocation and kernel launches; optimize only measured dominant work. Preserve pixel/State gates.';scope='hypothesis for B1'
 if 'Fetch' in env:reason='CPU OpenGL resolve/blit and rasterization dominate measured Reach profiles; GPU B1 likely dispatch overhead.';plan='A/B the software-GL readback/resize path at identical 480px sampling; profile GPU B1 launch/synchronization separately.';scope='CPU measured on Reach representatives; B1 GPU hypothesis'
 elif 'PushT' in env:reason='CPU drawing path, even with CUDA output. Corpus cycles rebuild drawing scenes at B64/B256; rebuilds disappear after warming B1024.';plan='Separate immutable geometry from dynamic pose/reset/goal data; avoid construction/reset on cache misses. Retain exact rasterization.';scope='measured continuous representative; discrete shares projection'
 elif 'OGBScene' in env:reason='91% of measured B256 GPU-route wall time is CPU supersample averaging.';plan='Exact box reduction, then equivalent GPU reduction if beneficial. Verify rounding and full pixel corpus.';scope='measured GPU route'
 elif 'OGBCube' in env:reason='GPU fidelity megakernels dominate, 181 registers/thread; CPU near 1x is a tie rather than a material regression.';plan='Reduce live register state and duplicated fidelity work; measure occupancy/spills and every retained visual feature.';scope='measured GPU B256'
 elif any(x in env for x in ['FingerDM','ReacherDM','HumanoidDM','QuadrupedDM']):reason='CPU ray intersections, shading, reflections and texture filtering dominate B256 profiles.';plan='Share fused CPU kernels or evaluate a source-compatible Mesa route. Profile B1 GPU separately.';scope='measured CPU B256; B1 GPU hypothesis'
 def batches(rs):return ','.join(str(x) for x in sorted({int(r['batch']) for r in rs}))
 rows.append(dict(env=env,cpu_slower_batches=batches(cpu),gpu_vs_gpu_slower_batches=batches(gpu),cpu_source_upload_fallback_slower_batches=batches(fallback),evidence_scope=scope,diagnosis=reason,next_step=plan))
with (OUT/'slower-registration-plan.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
