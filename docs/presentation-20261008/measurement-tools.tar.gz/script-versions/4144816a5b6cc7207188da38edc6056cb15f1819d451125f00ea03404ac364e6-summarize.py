"""Build a compact presentation index without pooling unlike workloads."""
import csv,statistics
from pathlib import Path
OUT=Path('/Users/samib/stable-envs/docs/presentation-20261008')
lines=['# Presentation results','', 'Live collection: blank or pending cells are not zero performance. Craftax is excluded.', '', 'Speedup is ours FPS divided by source FPS. Medians include only complete, accepted pairs. GPU comparisons below require a real source GPU renderer; CPU-source upload fallbacks are counted separately.', '']
for op,title in [('render-only','Saved-state rendering'),('online','Online stepping and rendering'),('step','Stepping without rendering')]:
 rows=list(csv.DictReader((OUT/(op+'.csv')).open()))
 lines += ['## '+title,'','| Batch | Horizon | CPU complete / 38 | CPU faster | Median CPU speedup | GPU complete / 38 | GPU faster / eligible | Median GPU speedup | CPU fallback pairs | Pending cells |','| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |']
 for b in [1,64,256,1024,2048]:
  for h in ([1] if op=='render-only' else [1,8]):
   group=[r for r in rows if int(r['batch'])==b and int(r.get('horizon',1))==h and (op!='render-only' or r['candidate_device']==r['output_device'])]
   complete=[r for r in group if r['status']=='COMPLETE']
   cpu=[r for r in complete if r['candidate_device']=='cpu'];gpu=[r for r in complete if r['candidate_device']=='cuda']
   eligible=[r for r in gpu if r.get('source_render_device')=='cuda'] if op!='step' else []
   fallback=[r for r in gpu if r.get('source_render_device')=='cpu'] if op!='step' else gpu
   def median(rs):return f"{statistics.median(float(r['speedup_source_over_ours']) for r in rs):.2f}×" if rs else '—'
   def faster(rs):return sum(float(r['speedup_source_over_ours'])>1 for r in rs)
   lines.append(f'| {b} | {h} | {len(cpu)} | {faster(cpu)} | {median(cpu)} | {len(gpu)} | {faster(eligible)}/{len(eligible)} | {median(eligible)} | {len(fallback)} | {sum(r["status"]=="PENDING" for r in group)} |')
 lines+=['']
 if op=='step':lines+=['All pinned source simulation here is CPU-based. The GPU configuration includes GPU result delivery; it is not source GPU physics. See the detailed table for those rates.','']
lines+=['See [measurement definitions](README.md), [the slowdown diagnosis and fix plan](bottlenecks.md), and the detailed CSVs for MSE, standard deviations, resource usage, failed gates and device labels.','']
(OUT/'summary.md').write_text('\n'.join(lines))
