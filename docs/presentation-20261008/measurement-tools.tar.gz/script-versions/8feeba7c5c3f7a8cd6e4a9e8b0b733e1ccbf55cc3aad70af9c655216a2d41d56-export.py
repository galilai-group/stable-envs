"""Export measured cells, retaining explicit gaps and device/output distinctions."""
import csv,datetime,hashlib,io,json,statistics,tarfile
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results'
OUT=Path('/Users/samib/stable-envs/docs/presentation-20261008')
OUT.mkdir(exist_ok=True)
BATCHES=[1,64,256,1024,2048]
for archive in RESULTS.glob('*.tar.gz'):
 if not (RESULTS/archive.name[:-7]).exists():
  with tarfile.open(archive) as t:t.extractall(RESULTS,filter='data')
def write(name,rows):
 fields=list(dict.fromkeys(k for r in rows for k in r))
 with (OUT/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def resource(path,windows=(),offset=None):
 rows=[];timed=[]
 if path.exists():
  for r in csv.reader(path.open()):
   try:
    memory,busy,bandwidth,power=(float(x.strip()) for x in r[2:6]);rows.append((memory,busy,bandwidth,power))
    if offset is not None:
     stamp=datetime.datetime.strptime(r[0].strip(),'%Y/%m/%d %H:%M:%S.%f').replace(tzinfo=datetime.timezone(datetime.timedelta(seconds=offset))).timestamp()
     if any(lo<=stamp<=hi for lo,hi in windows):timed.append(rows[-1])
   except (ValueError,IndexError):continue
 if not rows:return dict(resource_status='NOT_MEASURED')
 out=dict(resource_status='SAMPLED',sampled_peak_vram_mib=max(r[0] for r in rows),whole_run_gpu_busy_mean_pct=statistics.mean(r[1] for r in rows),whole_run_gpu_busy_sd_pct=statistics.stdev(r[1] for r in rows) if len(rows)>1 else 0.,whole_run_gpu_busy_peak_pct=max(r[1] for r in rows),resource_samples=len(rows),resource_scope='whole process including setup, checks and warmup; 200ms sampling may miss peaks',timed_gpu_samples=len(timed))
 if timed:out['timed_gpu_busy_mean_pct']=statistics.mean(r[1] for r in timed)
 return out
base=list(csv.DictReader(open('/Users/samib/stable-envs/docs/adapter-cleanup/paired_rendering_all_batches.csv')))
render={}
for r in base:
 if int(r['batch']) not in BATCHES:continue
 raw=Path('/private/tmp/adapter-campaign/advisor-table')/r['evidence']
 if raw.exists():
  previous=json.loads(raw.read_text())
  for m in previous.get('measurements',[]):
   if m['batch']==int(r['batch']) and m['output_device']==r['output_device']:
    for arm in ['ours','source']:
     samples=m[arm].get('samples_ms',[]);frames=m.get('frames_per_repeat',m['batch'])
     if len(samples)>1:r[arm+'_fps_sd']=statistics.stdev(1000*frames/x for x in samples)
 r.update(measurement_generation='previous October 8 advisor campaign',mfu_percent='',mfu_status='UNDEFINED_USEFUL_FLOPS',resource_status='NOT_MEASURED',resource_scope='')
 r['evidence']='adapter-cleanup/advisor-provenance.json:'+r['evidence']
 render[r['env'],r['candidate_device'],int(r['batch']),r['output_device']]=r
for path in RESULTS.glob('advisor-*/measurement/result.json'):
 d=json.loads(path.read_text());task=json.loads((path.parent.parent/'task.json').read_text())
 for m in d.get('measurements',[]):
  b=m['batch'];dest=m['output_device'];q=m.get('paired_mse',d.get('paired_mse',{}))
  r=dict(env=d['registration'],candidate_device=d['device'],candidate_render_device=d.get('candidate_render_device',d['device']),source_render_device=d.get('source_render_device',''),output_device=dest,batch=b,status=d['status'],backend=d['backend'],cpu=d.get('profile',{}).get('cpu'),gpu=d.get('profile',{}).get('gpu'),host=d.get('profile',{}).get('host'),independent_states=d.get('independent_states'),source_batch_method=d.get('source_batch_method'),speedup_source_over_ours=m['speedup'],paired_mse_mean=q.get('mean'),paired_mse_sd=q.get('sd'),paired_mse_max=q.get('maximum',q.get('max')),evidence=str(path.relative_to(ROOT)),measurement_generation='current batch expansion at 65ec1f38',mfu_percent='',mfu_status='UNDEFINED_USEFUL_FLOPS')
  for arm in ['ours','source']:
   for key in ['mean_ms_per_frame','sd_ms_per_frame','frames_per_second','count']:r[f'{arm}_{key}']=m[arm][key]
   samples=m[arm].get('samples_ms',[]);frames=m.get('frames_per_repeat',b)
   if len(samples)>1:r[f'{arm}_fps_sd']=statistics.stdev(1000*frames/x for x in samples)
  r.update(resource(path.parent.parent/'gpu-usage.csv'));render[r['env'],r['candidate_device'],b,dest]=r
plan=json.loads((ROOT/'plan.json').read_text())['tasks']
for t in plan:
 for dest in (['cpu','cuda'] if t['device']=='cuda' else ['cpu']):
  key=t['registration'],t['device'],t['batch'],dest
  if key not in render:
   matches=list(RESULTS.glob(f'advisor-{t["index"]}-*/measurement/result.json'))
   d=json.loads(matches[-1].read_text()) if matches else {}
   render[key]=dict(env=key[0],candidate_device=key[1],batch=key[2],output_device=key[3],status=d.get('status','PENDING'),error=d.get('error',''),mfu_percent='',mfu_status='UNDEFINED_USEFUL_FLOPS')
# Include failed old small-batch registrations explicitly, rather than dropping them.
registrations=sorted({t['registration'] for t in plan})
old_summary=list(csv.DictReader(open('/Users/samib/stable-envs/docs/adapter-cleanup/paired_rendering_summary.csv')))
for name in registrations:
 for b in BATCHES[:3]:
  for dev in ['cpu','cuda']:
   for dest in (['cpu','cuda'] if dev=='cuda' else ['cpu']):
    key=name,dev,b,dest
    if key not in render:render[key]=dict(env=name,candidate_device=dev,batch=b,output_device=dest,status='ERROR_PRIOR_CAMPAIGN',mfu_status='UNDEFINED_USEFUL_FLOPS')
write('render-only.csv',[render[k] for k in sorted(render)])
online={}
for p in sorted(RESULTS.glob('online-*'),key=lambda p:int(p.name.split('-')[-1]) if p.is_dir() else 0):
 if not p.is_dir() or not (p/'task.json').exists():continue
 t=json.loads((p/'task.json').read_text())
 for h in [1,8]:
  for op in ['step','online']:
   arms={}
   for arm in ['source','ours']:
    f=p/f'{op}-h{h}-{arm}'/'result.json'
    if f.exists():arms[arm]=json.loads(f.read_text())
   if not arms:continue
   source,ours=arms.get('source',{}),arms.get('ours',{})
   if ours.get('frame_mse') and 'mse_mean' not in ours:
    ours['mse_mean']=statistics.mean(ours['frame_mse']);ours['mse_max']=max(ours['frame_mse']);ours['mse_sd']=statistics.stdev(ours['frame_mse']) if len(ours['frame_mse'])>1 else 0.
   ours['mse_scope']='all checked frames' if ours.get('status') in ('COMPLETE','MEASURED_PIXEL_GATE_FAILED') else 'partial, through first failing frame'
   good=source.get('status')=='COMPLETE' and ours.get('status') in ('COMPLETE','MEASURED_PIXEL_GATE_FAILED')
   r=dict(env=t['registration'],candidate_device=t['device'],batch=t['batch'],horizon=h,operation=op,output_device=t['device'],status=ours['status'] if good else source['status'] if source.get('status','').startswith('SKIPPED_') else ours.get('status',source.get('status','PENDING')),paired_mse_mean=ours.get('mse_mean',''),paired_mse_sd=ours.get('mse_sd',''),paired_mse_max=ours.get('mse_max',''),paired_mse_scope=ours.get('mse_scope'),paired_mse_sample_count=len(ours.get('frame_mse',[])),image_shape=str(ours.get('image_shape',source.get('image_shape',''))),task_equality=ours.get('task_checks',''),mfu_percent='',mfu_status='UNDEFINED_USEFUL_FLOPS',evidence=str(p.relative_to(ROOT)),protocol='8 CPU cores; per-sample resets excluded; all H frames; five repeats; forward source traces')
   for arm,d in arms.items():
    r[arm+'_status']=d.get('status');r[arm+'_workers']=d.get('workers');r[arm+'_render_device']=d.get('render_device');r[arm+'_error']=d.get('error',d.get('reason',''))
    for k in ['rate','rate_sd','valid_steps_per_second','seconds_mean','seconds_sd','torch_peak_allocated_bytes','torch_peak_reserved_bytes']:
     if k in d:r[arm+'_'+k]=d[k]
    if op=='step' and 'valid_steps_per_second' in d:
     r[arm+'_nominal_rate']=d.get('rate');r[arm+'_rate']=d['valid_steps_per_second']
     if len(d.get('samples',[]))>1:r[arm+'_rate_sd']=statistics.stdev(n/t for n,t in zip(d['valid_transitions'],d['samples'],strict=True))
    r.update({arm+'_'+k:v for k,v in resource(p/f'{op}-h{h}-{arm}-gpu.csv',d.get('timing_windows',[]),d.get('utc_offset_seconds')).items()})
   if good:r['speedup_source_over_ours']=r['ours_rate']/r['source_rate']
   online[t['registration'],t['device'],t['batch'],h,op]=r
for t in json.loads((ROOT/'online-plan.json').read_text())['tasks']:
 for h in [1,8]:
  for op in ['step','online']:
   key=t['registration'],t['device'],t['batch'],h,op
   online.setdefault(key,dict(env=key[0],candidate_device=key[1],batch=key[2],horizon=h,operation=op,output_device=key[1],status='PENDING',mfu_percent='',mfu_status='UNDEFINED_USEFUL_FLOPS'))
scheduler={}
if (ROOT/'scheduler.tsv').exists():
 for line in (ROOT/'scheduler.tsv').read_text().splitlines():
  parts=line.split('|')
  if len(parts)>=7 and '.' not in parts[1]:scheduler[parts[1]]=parts[2]
for r in online.values():
 if r['status']=='COMPLETE':continue
 job=r.get('evidence','').split('-')[-1]
 if scheduler.get(job)=='OUT_OF_MEMORY' and (r.get('source_status')=='PROCESS_EXIT' or r.get('ours_status')=='PROCESS_EXIT'):
  r['previous_status']=r['status'];r['status']='SKIPPED_HOST_MEMORY_LIMIT';r['skip_reason']='Slurm confirmed OUT_OF_MEMORY at the fixed 64 GiB host-memory limit; not CUDA VRAM exhaustion'
 elif 'OutOfMemoryError' in r.get('ours_error',''):
  r['previous_status']=r['status'];r['status']='SKIPPED_GPU_OOM'
for op in ['step','online']:write(op+'.csv',[online[k] for k in sorted(online) if k[-1]==op])
# Compact slides table: destination follows device. CPU-only source fallback stays explicit.
for op,data in [('render-only',render),('step',online),('online',online)]:
 rows=[]
 for name in registrations:
  for b in BATCHES:
   for h in ([1] if op=='render-only' else [1,8]):
    r=dict(env=name,batch=b,horizon=h)
    for dev,label in [('cpu','cpu'),('cuda','gpu')]:
     d=data.get((name,dev,b,dev) if op=='render-only' else (name,dev,b,h,op),{})
     r[label+'_status']=d.get('status','PENDING')
     for k in ['paired_mse_mean','paired_mse_sd','paired_mse_max']:r[label+'_'+k]=d.get(k,'')
     source_device=d.get('source_render_device') if op=='render-only' else d.get('source_render_device')
     ours_device=d.get('candidate_render_device') if op=='render-only' else d.get('ours_render_device')
     r[label+'_source_render_device']=source_device;r[label+'_ours_render_device']=ours_device
     ratekey='frames_per_second' if op=='render-only' else 'rate'
     for arm in ['ours','source']:r[f'{arm}_{label}_rate']=d.get(arm+'_'+ratekey,'')
     if dev=='cuda':
      if source_device=='cpu' or op=='step':r['source_cpu_with_gpu_delivery_rate']=r.pop('source_gpu_rate');r['source_gpu_rate']=''
      if ours_device=='cpu' and op!='step':r['ours_cpu_with_gpu_delivery_rate']=r.pop('ours_gpu_rate');r['ours_gpu_rate']=''
     r[label+'_speedup']=d.get('speedup_source_over_ours','')
     r[label+'_comparison']=('CPU source physics + GPU result delivery' if op=='step' else 'CPU-only source + upload fallback' if source_device=='cpu' else 'same device') if dev=='cuda' else 'same device'
     if dev=='cuda':
      if op=='render-only':
       r['paired_process_sampled_peak_vram_mib']=d.get('sampled_peak_vram_mib','');r['gpu_resource_scope']=d.get('resource_scope','NOT_MEASURED')
      else:
       for arm in ['ours','source']:
        for key in ['sampled_peak_vram_mib','timed_gpu_busy_mean_pct','timed_gpu_samples','whole_run_gpu_busy_mean_pct','whole_run_gpu_busy_sd_pct']:
         r[arm+'_'+key]=d.get(arm+'_'+key,'')
       r['gpu_resource_scope']='separate arms; sampled whole-arm peak includes setup/warmup; timed GPU busy samples are separate'
     r[label+'_mfu_percent']='';r[label+'_mfu_status']='UNDEFINED_USEFUL_FLOPS'
    rows.append(r)
 write(op+'-cpu-gpu.csv',rows)
slow=[]
for r in render.values():
 if r.get('status')=='COMPLETE' and float(r.get('speedup_source_over_ours',0))<1:
  slow.append({k:r.get(k,'') for k in ['env','candidate_device','candidate_render_device','source_render_device','output_device','batch','speedup_source_over_ours','ours_frames_per_second','source_frames_per_second','paired_mse_mean','evidence']})
write('slower-render-cells.csv',sorted(slow,key=lambda r:(r['env'],int(r['batch']),r['candidate_device'],r['output_device'])))
profiles=[]
for path in RESULTS.glob('diagnostic-*/ncu.csv'):
 lines=path.read_text().splitlines();start=next((i for i,l in enumerate(lines) if l.startswith('"ID"')),None)
 if start is None:continue
 rows=list(csv.DictReader(io.StringIO('\n'.join(lines[start:]))))[1:]
 rows=[r for r in rows if r.get('ID','').isdigit()]
 if not rows:continue
 task=json.loads((path.parent/'task.json').read_text())
 def value(r,k):return float(r[k].replace(',',''))
 duration=sum(value(r,'gpu__time_duration.sum') for r in rows)
 profile=dict(env=task['registration'],batch=256,output_device='cpu',arm='ours',status='CUDA_KERNEL_COUNTERS',kernel_count=len(rows),profiled_kernel_ms=duration/1e6,mfu_percent='',mfu_status='UNDEFINED_USEFUL_FLOPS',scope='Duration-weighted kernel metrics; excludes CPU gaps, transfers and OpenGL shaders; separate profiled replay, not FPS run',evidence=str(path.relative_to(ROOT)))
 for metric,column in [('sm__throughput.avg.pct_of_peak_sustained_elapsed','cuda_compute_throughput_pct'),('gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed','cuda_dram_throughput_pct')]:
  profile[column]=sum(value(r,metric)*value(r,'gpu__time_duration.sum') for r in rows)/duration
 profiles.append(profile)
write('hardware-utilization.csv',profiles)
manifest=dict(generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_sha='65ec1f38',source_sha='176d54532b3c0a251a4f509b74f2fdacc143a63d',render_status_counts=dict(Counter(r['status'] for r in render.values())),online_status_counts=dict(Counter(r['status'] for r in online.values())),artifacts={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in ROOT.glob('*.py')},results={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in RESULTS.glob('*.tar.gz')})
(OUT/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(manifest['render_status_counts'],manifest['online_status_counts'])
