"""Run isolated source/candidate pairs on a fixed Slurm allocation."""
import hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parent
V=Path('/oscar/scratch/sboughan/venvs')
def main():
 task=json.loads((BASE/'online-plan.json').read_text())['tasks'][int(sys.argv[1])]
 profile=task['family'];device=task['device'];index=task['index']
 run=BASE/f'online-{index}-{os.environ["SLURM_JOB_ID"]}';run.mkdir()
 (run/'task.json').write_text(json.dumps(task,indent=2))
 subprocess.run(['lscpu'],stdout=(run/'lscpu.txt').open('w'),check=True)
 subprocess.run(['nvidia-smi','-q'],stdout=(run/'nvidia-smi.txt').open('w'),check=True)
 py=V/('se6-verify-fetch311' if profile=='fetch' else 'se6-verify-vis311')/'bin/python'
 deps=[V/f'{v}/lib/python3.12/site-packages' for v in ['se-step6','se-vis311','se-step4-swm','se7-rocket','se7-ogb']]
 pins=json.loads((BASE/'pins.json').read_text())[profile]
 if device=='cuda':pins.update({'mujoco-warp':'3.12.0','warp-lang':'1.17.0'})
 env=os.environ.copy();env.update(UV_CACHE_DIR=str(BASE/'uv-cache'))
 with (run/'install.log').open('w') as log:
  subprocess.run(['/users/sboughan/.local/bin/uv','pip','install','--python',str(py),'--target',str(run/'pins'),'--no-deps',*[f'{k}=={v}' for k,v in pins.items()]],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',LP_NUM_THREADS='1',SDL_VIDEODRIVER='dummy',MPLBACKEND='Agg',PYTHONDONTWRITEBYTECODE='1',XDG_CACHE_HOME=str(run/'cache'),MPLCONFIGDIR=str(run/'mpl'),TORCH_EXTENSIONS_DIR=str(run/'torch'),WARP_CACHE_PATH=str(run/'warp'),MUJOCO_GL='egl',PYOPENGL_PLATFORM='egl')
 xvfb=None
 if device=='cpu':
  env.update(MUJOCO_GL='glfw',PYOPENGL_PLATFORM='glx',LIBGL_ALWAYS_SOFTWARE='1',GALLIUM_DRIVER='llvmpipe',CUDA_VISIBLE_DEVICES='',DISPLAY=':'+str(100+int(os.environ['SLURM_JOB_ID'])%10000))
  xvfb=subprocess.Popen(['Xvfb',env['DISPLAY'],'-screen','0','1024x768x24','-nolisten','tcp'],stdout=(run/'xvfb.log').open('w'),stderr=subprocess.STDOUT)
  time.sleep(2);assert xvfb.poll() is None
 code=BASE/'candidate';env['PYTHONPATH']=':'.join(map(str,[code,run/'pins',*deps,BASE/'oracle']))
 versions=subprocess.run([str(py),'-c','import importlib.metadata as m,json;print(json.dumps({n:m.version(n) for n in '+repr(list(pins)+['torch','tensordict'])+'}))'],env=env,text=True,capture_output=True,check=True).stdout
 (run/'versions.json').write_text(versions)
 (run/'harness-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [BASE/'online_run.py',BASE/'online_measure.py']},indent=2))
 terminal=[]
 try:
  for horizon in [1,8]:
   for operation in ['step','online']:
    previous=None
    for arm in ['source','ours']:
     name=f'{operation}-h{horizon}-{arm}';output=run/name
     cmd=[str(py),str(BASE/'online_measure.py'),'--registration',task['registration'],'--batch',str(task['batch']),'--horizon',str(horizon),'--operation',operation,'--device',device,'--arm',arm,'--source-root',str(BASE/'oracle'),'--output',str(output)]
     if arm=='ours':
      if previous!='COMPLETE':
       output.mkdir();(output/'result.json').write_text(json.dumps(dict(status='BLOCKED_SOURCE',reason=previous,**task,horizon=horizon,operation=operation,arm=arm)));continue
      cmd+=['--reference',str(run/f'{operation}-h{horizon}-source')]
     monitor=None
     if device=='cuda':
      gpu=os.environ.get('CUDA_VISIBLE_DEVICES','0').split(',')[0]
      monitor=subprocess.Popen(['nvidia-smi','-i',gpu,'--query-gpu=timestamp,uuid,memory.used,utilization.gpu,utilization.memory,power.draw','--format=csv,noheader,nounits','--loop-ms=200'],stdout=(run/f'{name}-gpu.csv').open('w'),stderr=(run/f'{name}-gpu-errors.txt').open('w'))
     started=time.time()
     try:
      with (run/f'{name}.log').open('w') as log:
       process=subprocess.Popen(cmd,cwd=code,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
       try:rc=process.wait(timeout=1500)
       except subprocess.TimeoutExpired:
        os.killpg(process.pid,signal.SIGTERM)
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
        raise
      result=json.loads((output/'result.json').read_text()) if (output/'result.json').exists() else dict(status='PROCESS_EXIT',exit_code=rc)
      if result['status']=='RUNNING':result.update(status='PROCESS_EXIT',exit_code=rc)
     except subprocess.TimeoutExpired:result=dict(status='TIMEOUT',limit_seconds=1500)
     finally:
      if monitor:monitor.terminate();monitor.wait()
     output.mkdir(exist_ok=True);result.update(job=os.environ['SLURM_JOB_ID'],wall_seconds=time.time()-started,candidate_sha='65ec1f38',source_sha='176d54532b3c0a251a4f509b74f2fdacc143a63d')
     (output/'result.json').write_text(json.dumps(result,indent=2));previous=result['status'];terminal.append(dict(case=name,status=previous))
     (run/'terminal.json').write_text(json.dumps(terminal,indent=2))
    # Source traces served their equality checks; retain task/MSE summaries, not GBs of repeated pixels.
    for f in (run/f'{operation}-h{horizon}-source').glob('sample-*.npz'):f.unlink()
 finally:
  if xvfb:xvfb.terminate();xvfb.wait()
if __name__=='__main__':main()
