import os
"""Check report completeness, provenance, ratios, and acceptance labels."""
import csv,json,math
from pathlib import Path
OUT=Path(os.environ.get('PRESENTATION_OUTPUT','/Users/samib/stable-envs/docs/presentation-20261008'))
ROOT=Path(__file__).resolve().parent
for name,n in [('render-only',570),('online',760),('step',760)]:
 rows=list(csv.DictReader((OUT/(name+'.csv')).open()))
 assert len(rows)==n,(name,len(rows));assert len({r['env'] for r in rows})==38
 assert {int(r['batch']) for r in rows}=={1,64,256,1024,2048}
 keys=[(r['env'],r['candidate_device'],r['batch'],r.get('horizon'),r['output_device']) for r in rows];assert len(keys)==len(set(keys))
 for r in rows:
  assert not r['mfu_percent']
  if r['status'] in ('COMPLETE','MEASURED_PIXEL_GATE_FAILED'):
   rate='frames_per_second' if name=='render-only' else 'rate'
   ours=float(r['ours_'+rate]);source=float(r['source_'+rate])
   assert ours>0 and source>0 and math.isclose(float(r['speedup_source_over_ours']),ours/source,rel_tol=1e-9)
   if name!='step':
    assert r['paired_mse_max'],(name,r['env'],r['batch'])
    assert (float(r['paired_mse_max'])<=.001)==(r['status']=='COMPLETE'),r
 print(name,'validated',n)
versions=Path('/Users/samib/stable-envs/branch-backups/presentation-20261008/script-versions')
missing=set()
for p in (ROOT/'results').glob('online-*/harness-sha256.json'):
 for name,digest in json.loads(p.read_text()).items():
  if not (versions/(digest+'-'+name)).exists():missing.add((name,digest))
assert not missing,missing
print('Every collected online harness version is preserved.')
