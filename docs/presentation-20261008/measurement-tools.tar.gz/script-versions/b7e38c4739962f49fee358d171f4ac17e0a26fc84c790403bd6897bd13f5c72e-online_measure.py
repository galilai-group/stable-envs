"""Paired forward online workloads; native source calls never export State in timers."""
from __future__ import annotations
import argparse,contextlib,cProfile,functools,hashlib,io,json,os,pstats,statistics,time,traceback
from pathlib import Path
import gymnasium as gym
import numpy as np
import torch
from tests.helpers.reference.profiles import PROFILES
from tests.helpers.reference.bridges import load_source

CASES={c.registration:c for group in PROFILES.values() for c in group}


def kwargs(case,device=None):
    if case.family=='fetch':return {'size':64,'backend':'opengl' if device=='cpu' else 'auto'}
    if case.family in ('dmc','ogbench','pusht'):return {'size':64}
    if case.family=='rocket':return {'size':96,'simulator_config':{'render_mode':'rgb_array','render_resolution':(96,96)}}
    return {}


class Source:
    def __init__(self,case,root,batch,start=0):
        load_source(root,case.family)
        self.case,self.batch,self.start=case,batch,start
        self.owner=None;self.envs=[]
        f=case.family
        if f=='native':
            from tests.helpers.reference.native_classic_semantics import NativeClassicReference
            self.owner=NativeClassicReference(case.domain,batch,render_mode='rgb_array')
        elif f=='dmc':
            from tests.helpers.reference.dmc_semantics import DMCReference
            self.owner=DMCReference(case.domain,batch)
        elif f=='navigation':
            from tests.helpers.reference.native_navigation_semantics import NativeNavigationReference
            self.owner=NativeNavigationReference(case.domain,batch)
        elif f=='ogbench' and case.domain=='Maze':
            from tests.helpers.reference.ogbench_maze_semantics import OGBMazeReference
            self.owner=OGBMazeReference(batch,width=64,height=64)
        if self.owner:
            self.owner.reset(17+start);self.envs=self.owner.envs
        else:
            if f=='fetch':
                factory=lambda i:gym.make(case.registration,render_mode='rgb_array',resolution=64)
            elif f=='ogbench':
                from tests.helpers.reference.ogbench_manipulation_semantics import load_oracle
                factory=lambda i:getattr(load_oracle(),'Owned'+case.domain)(entropy_seed=start+i,width=64,height=64)
            elif f=='pusht':
                import importlib
                module=importlib.import_module('stable_worldmodel.envs.pusht.'+('env_discrete' if case.domain=='discrete' else 'env'))
                factory=lambda i:getattr(module,case.name)(resolution=64)
            elif f=='rocket':
                from tests.helpers.reference.rocket_semantics import RocketLandingEnv
                factory=lambda i:RocketLandingEnv(render_mode='rgb_array',render_resolution=(96,96))
            else:raise ValueError(case)
            try:
                for i in range(batch):
                    env=factory(i);self.envs.append(env)
                    env.reset(seed=17+start+i,options={'variation':[]} if f=='fetch' else {})
            except BaseException:self.close();raise

    def image(self,i):
        env=self.envs[i];f=self.case.family
        if f=='dmc':return env.render(width=64,height=64)
        if f=='ogbench' and self.case.domain!='Maze':return env.render()
        if f=='fetch':
            viewer=env.unwrapped.mujoco_renderer._viewers.get('rgb_array')
            if viewer is not None:viewer.make_context_current()
        if f=='ogbench':return self.owner._in_legacy_rng(i,env.render)
        return env.render()

    def reset(self):
        if self.owner:self.owner.reset(17+self.start)
        else:
            for i,env in enumerate(self.envs):env.reset(seed=17+self.start+i,options={'variation':[]} if self.case.family=='fetch' else {})

    def identity(self,device):
        if self.case.family not in ('fetch','dmc','ogbench'):return {'render_device':'cpu'}
        from OpenGL import GL
        env=self.envs[0]
        self.image(0)
        if self.case.family=='fetch':
            env.unwrapped.mujoco_renderer._viewers['rgb_array'].make_context_current()
            vendor,name=GL.glGetString(GL.GL_VENDOR).decode(),GL.glGetString(GL.GL_RENDERER).decode()
            result={'vendor':vendor,'renderer':name,'software':any(x in name.lower() for x in ('llvmpipe','softpipe','swrast'))}
        elif self.case.family=='dmc':
            with env.env.physics.contexts.gl.make_current() as context:
                vendor=context.call(GL.glGetString,GL.GL_VENDOR).decode();name=context.call(GL.glGetString,GL.GL_RENDERER).decode()
            result={'vendor':vendor,'renderer':name,'software':any(x in name.lower() for x in ('llvmpipe','softpipe','swrast'))}
        else:
            from tests.helpers.reference.ogbench_pixels import _identity
            raw=env.env if self.case.domain=='Maze' else env
            renderer=raw.custom_renderer if self.case.domain=='Maze' else raw._renderer
            result=_identity(renderer,device,self.case.domain,raw.model.light_cutoff)
        assert result['software'] if device=='cpu' else 'nvidia' in result['vendor'].lower() and not result['software'],result
        return result

    def columns(self,rows):
        f=self.case.family;d=self.case.domain
        values={k:np.asarray([r[i] for r in rows],dtype=dt) for k,i,dt in [('reward',1,np.float64),('terminated',2,bool),('truncated',3,bool)]}
        if f in ('native','dmc','navigation') or f=='ogbench' and d=='Maze':values['observation']=np.stack([r[0] for r in rows])
        if f=='native':values['info_state']=np.stack([r[4]['state'] for r in rows])
        elif f=='dmc':
            values['score']=np.asarray([r[4]['score'] for r in rows],np.float64)
            if d not in ('acrobot','pendulum','cartpole','reacher'):
                values['success']=np.asarray([r[4]['success'] for r in rows],np.float64)
                for k in rows[0][4]:
                    if k not in ('env_name','score','success'):values['info.'+k]=np.stack([r[4][k] for r in rows])
        elif f=='navigation':
            keys=('goal',) if d=='simple_point_maze' else ('proprio','state','goal_state','distance_to_target')
            for k in keys:values['info.'+k]=np.stack([r[4][k] for r in rows])
        elif f=='fetch':values['success']=np.asarray([r[4]['is_success'] for r in rows])
        elif f=='ogbench':
            values['success']=np.asarray([r[4]['success'] for r in rows],np.float64 if d=='Maze' else bool)
            if d=='Maze':
                for k in ('xy','prev_qpos','prev_qvel','qpos','qvel'):values['info.'+k]=np.stack([r[4][k] for r in rows])
        elif f=='pusht':values['success']=values['terminated'].copy()
        elif f=='rocket':values['success']=np.asarray([r[4]['env_complete'] for r in rows],bool)
        return values

    def step(self,actions,frames):
        active=np.ones(self.batch,bool);previous=[None]*self.batch;tasks=[];images=[];valid=[]
        discrete=self.case.dtypes==('int64',) and self.case.family=='native'
        for t in range(actions.shape[1]):
            valid.append(active.copy());rows=[]
            for i,env in enumerate(self.envs):
                if active[i]:
                    action=actions[i,t,0].item() if discrete else actions[i,t].copy()
                    row=self.owner._in_legacy_rng(i,env.step,action) if self.case.family=='ogbench' and self.case.domain=='Maze' else env.step(action)
                    previous[i]=row
                rows.append(previous[i])
            cols=self.columns(rows);done=cols['terminated']|cols['truncated']
            for v in cols.values():v[~active]=0
            tasks.append(cols)
            if frames:images.append(np.stack([self.image(i).copy()[...,:3] for i in range(self.batch)]))
            active &= ~done
        output={k:np.stack([v[k] for v in tasks],axis=1) for k in tasks[0]}
        output['valid']=np.stack(valid,axis=1)
        if frames:output['frames']=np.stack(images,axis=1);output['frame_valid']=output['valid'].copy()
        return output

    def close(self):
        for env in self.envs:
            env.close()
        self.envs=[]


from array_space import ArraySpace


class Shard(gym.Env):
    metadata={}
    def __init__(self,case,root,batch,start,horizon,frames,layout):
        self.case,self.root,self.batch,self.start,self.horizon,self.frames=case,root,batch,start,horizon,frames
        self.source=None
        self.observation_space=gym.spaces.Dict({k:ArraySpace((batch,*shape),np.dtype(dt)) for k,(shape,dt) in layout.items()})
        self.action_space=gym.spaces.Box(-np.inf,np.inf,shape=(batch,horizon,case.width),dtype=np.float64)
    def reset(self,*,seed=None,options=None):
        super().reset(seed=seed);torch.set_num_threads(1)
        if self.source:self.source.reset()
        else:self.source=Source(self.case,self.root,self.batch,self.start)
        return {k:np.zeros(s.shape,s.dtype) for k,s in self.observation_space.items()},{}
    def identity(self,device):return self.source.identity(device)
    def step(self,actions):return self.source.step(actions,self.frames),0.,False,False,{}
    def close(self):
        if self.source:self.source.close();self.source=None


def actions_for(case,batch,horizon):
    rng=np.random.default_rng(31)
    if case.dtypes==('int64',):
        n=16 if case.family=='pusht' else (2 if case.domain=='cartpole' else 3)
        return rng.integers(0,n,(batch,horizon,case.width),dtype=np.int64)
    if case.family=='rocket':return np.broadcast_to(np.asarray([.15,-.1,.2,1.,.5,.1,-.1],np.float64),(batch,horizon,7)).copy()
    scale=.01 if case.family=='navigation' else .2
    return rng.uniform(-scale,scale,(batch,horizon,case.width)).astype(np.float64 if 'float64' in case.dtypes else np.float32)


def normalized(result,horizon):
    values={}
    for key,value in result.exclude('state','states','state_valid').items(True,True):
        k='.'.join(key) if isinstance(key,tuple) else key
        values[k]=value if horizon!=1 or k in ('valid','frames','frame_valid') else value.unsqueeze(1)
    return values


def main():
    p=argparse.ArgumentParser();p.add_argument('--registration',required=True);p.add_argument('--batch',type=int,required=True);p.add_argument('--horizon',type=int,choices=[1,8],required=True);p.add_argument('--operation',choices=['step','online'],required=True);p.add_argument('--device',choices=['cpu','cuda'],required=True);p.add_argument('--arm',choices=['source','ours'],required=True);p.add_argument('--source-root',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--reference',type=Path);p.add_argument('--repeats',type=int,default=5);a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False);case=CASES[a.registration];frames=a.operation=='online'
    report=dict(status='RUNNING',**{k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()},samples=[],source_physics_device='cpu',output_device=a.device,scope='Forward trajectories; no reset/restore/export or pixel checks in source timers; ours includes mandatory final State. Each sample resets to the same seed outside the timer; reset time is excluded on both sides.',size=kwargs(case,a.device).get('size','native'),backend=kwargs(case,a.device).get('backend','auto'),gpu_usage_scope='separate whole-arm sampling including construction/warmup',task_checks='not yet run',full_state_acceptance='Not established by this benchmark; maintained contracts remain separate.')
    save=lambda:(a.output/'result.json').write_text(json.dumps(report,indent=2))
    save();owner=None;vector=None;env=None
    try:
        if frames and case.family=='fetch' and 'PickAndPlace' in a.registration:
            report.update(status='SKIPPED_UNSUPPORTED_PROTOCOL',reason='Source PickAndPlace render mutates continuation; no accepted rendered-online comparison.');return
        batch,horizon=a.batch,a.horizon;actions=actions_for(case,batch,horizon);device=torch.device(a.device)
        workers=min(8,batch,len(os.sched_getaffinity(0))) if hasattr(os,'sched_getaffinity') else min(8,batch)
        torch.set_num_threads(1 if a.arm=='source' else min(8,os.cpu_count() or 1))
        if a.arm=='source':
            if workers==1:
                owner=Source(case,a.source_root,batch);call=lambda:{k:torch.as_tensor(v,device=device) for k,v in owner.step(actions,frames).items()}
            else:
                proto=Source(case,a.source_root,1)
                try:sample=proto.step(actions[:1],frames);layout={k:(v.shape[1:],v.dtype.str) for k,v in sample.items()}
                finally:proto.close()
                factories=[functools.partial(Shard,case,a.source_root,batch//workers,i*(batch//workers),horizon,frames,layout) for i in range(workers)]
                vector=gym.vector.AsyncVectorEnv(factories,shared_memory=True,copy=True,context='spawn',autoreset_mode=gym.vector.AutoresetMode.DISABLED)
                vector.reset()
                def call():
                    obs,*_=vector.step(actions.reshape(workers,batch//workers,horizon,case.width))
                    return {k:torch.as_tensor(v.reshape(batch,*v.shape[2:]),device=device) for k,v in obs.items()}
            report['workers']=workers
            report['render_device']=a.device if case.family in ('dmc','fetch','ogbench') else 'cpu'
        else:
            import stable_envs as se
            env=se.make(case.name,num_envs=batch,device=device,seed=0,**kwargs(case,a.device));env.reset(seed=17)
            simulator=getattr(env,'_simulator',None)
            report['workers']=len(getattr(simulator,'worker_info',[])) or 1
            report['render_device']='cpu' if case.family=='pusht' else a.device
            def call():return normalized(env.step(actions[:,0] if horizon==1 else actions,states=None,frames=slice(None) if frames else None),horizon)
        if a.arm=='source' and frames:report['source_gl_identity']=vector.call('identity',a.device) if vector else owner.identity(a.device)
        report['pixel_gate_failures']=0;report['frame_mse']=[];report['valid_transitions']=[];report['timing_windows']=[];report['sample_hashes']=[];report['utc_offset_seconds']=-(time.altzone if time.localtime().tm_isdst else time.timezone)
        for sample_index in range(-1,a.repeats):
            if vector:vector.reset()
            elif owner:owner.reset()
            else:env.reset(seed=17)
            if device.type=='cuda':torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats()
            wall_start=time.time();start=time.perf_counter();out=call()
            if device.type=='cuda':torch.cuda.synchronize()
            elapsed=time.perf_counter()-start
            if sample_index>=0:
                report['timing_windows'].append([wall_start,time.time()]);report['samples'].append(elapsed);report['valid_transitions'].append(int(out['valid'].sum().item()))
                if device.type=='cuda':
                    report['torch_peak_allocated_bytes']=max(report.get('torch_peak_allocated_bytes',0),torch.cuda.max_memory_allocated())
                    report['torch_peak_reserved_bytes']=max(report.get('torch_peak_reserved_bytes',0),torch.cuda.max_memory_reserved())
            arrays={k:v.detach().cpu().numpy() for k,v in out.items()}
            if frames:report['image_shape']=list(arrays['frames'].shape[-3:])
            report['sample_hashes'].append({k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in arrays.items()})
            if a.arm=='source':np.savez_compressed(a.output/f'sample-{sample_index}.npz',**arrays)
            else:
                with np.load(a.reference/f'sample-{sample_index}.npz',allow_pickle=False) as expected:
                    assert set(expected.files)==set(arrays),(set(expected.files)-arrays.keys(),arrays.keys()-set(expected.files))
                    for key in expected.files:
                        x,y=arrays[key],expected[key]
                        assert x.shape==y.shape,(key,x.shape,y.shape)
                        if key=='frames':
                            assert x.dtype==y.dtype==np.uint8
                            for frame_index,(i,j) in enumerate(zip(x.reshape(-1,*x.shape[-3:]),y.reshape(-1,*y.shape[-3:]),strict=True)):
                                mse=float(np.mean(((i.astype(np.float64)-j)/255)**2));report['frame_mse'].append(mse)
                                if mse>.001:
                                    report['pixel_gate_failures']+=1
                                    if 'failed_frame' not in report:
                                        from PIL import Image
                                        Image.fromarray(i).save(a.output/'failure-ours.png');Image.fromarray(j).save(a.output/'failure-source.png')
                                        report['failed_frame']=dict(sample=sample_index,lane=frame_index//horizon,step=frame_index%horizon,mse=mse)
                        else:np.testing.assert_allclose(x,y,rtol=0,atol=0,equal_nan=True,err_msg=key)
            del out,arrays
            save()
        report.update(status='MEASURED_PIXEL_GATE_FAILED' if report['pixel_gate_failures'] else 'COMPLETE',task_checks='source trace recorded' if a.arm=='source' else 'exact task/validity equality',seconds_mean=statistics.mean(report['samples']),seconds_sd=statistics.stdev(report['samples']),frames_per_call=batch*horizon if frames else 0,transitions_per_call=batch*horizon,rate= batch*horizon/statistics.mean(report['samples']),rate_sd=statistics.stdev(batch*horizon/x for x in report['samples']))
        report['valid_steps_per_second']=sum(report['valid_transitions'])/sum(report['samples'])
        report['mfu_percent']=None;report['mfu_status']='Undefined useful FLOP count for renderer; GPU busy percentage is separate.'
        if report['frame_mse']:report['mse_sd']=statistics.stdev(report['frame_mse']) if len(report['frame_mse'])>1 else 0.;report['mse_mean']=statistics.mean(report['frame_mse']);report['mse_max']=max(report['frame_mse'])
    except torch.OutOfMemoryError as e:report.update(status='SKIPPED_GPU_OOM',error=str(e))
    except MemoryError as e:report.update(status='SKIPPED_HOST_OOM',error=str(e))
    except BaseException:report.update(status='ERROR',error=traceback.format_exc());raise
    finally:
        if report.get('frame_mse'):
            report['mse_mean']=statistics.mean(report['frame_mse']);report['mse_max']=max(report['frame_mse'])
            report['mse_sd']=statistics.stdev(report['frame_mse']) if len(report['frame_mse'])>1 else 0.
            report['mse_scope']='all checked frames' if report['status'] in ('COMPLETE','MEASURED_PIXEL_GATE_FAILED') else 'partial, through first failing frame'
        save()
        if env:env.close()
        if vector:vector.close()
        if owner:owner.close()

if __name__=='__main__':main()
