"""Fresh paired rendering and adapter checks on an allocated RTX 3090 node."""
import argparse, json, os, subprocess, sys, time
from pathlib import Path

BASE=Path(__file__).resolve().parent
V=Path('/oscar/scratch/sboughan/venvs')
ORACLE=BASE/'oracle'
ROOT=Path('/oscar/scratch/sboughan/se-semantic-recovery')
PROFILES=['native','fetch','dmc','navigation','ogbench','pusht','rocket']

def family(name):
    if 'Fetch' in name:return 'fetch'
    if 'DMControl' in name:return 'dmc'
    if 'OGB' in name or 'PointMaze' in name and 'Simple' not in name:return 'ogbench'
    if 'PushT' in name:return 'pusht'
    if 'Rocket' in name:return 'rocket'
    if 'TwoRoom' in name or 'Piecewise' in name or 'SimplePointMaze' in name:return 'navigation'
    return 'native'

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['advisor','gate','online']);p.add_argument('index',type=int);a=p.parse_args()
    assert os.environ.get('SLURM_JOB_ID'), 'Use a compute allocation'
    plan=json.loads((BASE/'plan.json').read_text())
    task=plan['tasks'][a.index] if a.mode=='advisor' else None
    profile=family(task['registration']) if task else PROFILES[a.index]
    device=task['device'] if task else os.environ.get('CONTRACT_DEVICE','cuda')
    run=BASE/f'diagnostic-{a.index}-{os.environ["SLURM_JOB_ID"]}';run.mkdir(exist_ok=False)
    (run/'task.json').write_text(json.dumps(task or dict(profile=profile),indent=2))
    subprocess.run(['lscpu'],stdout=(run/'lscpu.txt').open('w'),check=True)
    if device=='cuda':subprocess.run(['nvidia-smi','-q'],stdout=(run/'nvidia-smi.txt').open('w'),check=True)
    py=V/('se6-verify-fetch311' if profile=='fetch' else 'se6-verify-vis311')/'bin/python'
    deps=[V/f'{v}/lib/python3.12/site-packages' for v in ['se-step6','se-vis311','se-step4-swm','se7-rocket','se7-ogb']]
    pins=json.loads((BASE/'pins.json').read_text())[profile]
    if a.mode=='advisor' and profile=='pusht':
        # Match the archived corpus dependency-resolution.json, distinct from live contract pins.
        pins={'pymunk':'7.2.0'}
        deps=[V/f'{v}/lib/python3.12/site-packages' for v in ['se-vis311','se-step6','se-step4-swm','se7-rocket','se7-ogb']]
    if device=='cuda': pins.update({'mujoco-warp':'3.12.0','warp-lang':'1.17.0'})
    env=os.environ.copy();env.update(UV_CACHE_DIR=str(BASE/'uv-cache'))
    with (run/'install.log').open('w') as log:
        subprocess.run(['/users/sboughan/.local/bin/uv','pip','install','--python',str(py),'--target',str(run/'pins'),'--no-deps',*[f'{k}=={v}' for k,v in pins.items()]],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',LP_NUM_THREADS='1',SDL_VIDEODRIVER='dummy',MPLBACKEND='Agg',PYTHONDONTWRITEBYTECODE='1',XDG_CACHE_HOME=str(run/'cache'),MPLCONFIGDIR=str(run/'mpl'),TORCH_EXTENSIONS_DIR=str(run/'torch'),WARP_CACHE_PATH=str(run/'warp'))
    env.update(MUJOCO_GL='egl',PYOPENGL_PLATFORM='egl',SE_DIAGNOSTIC='1')
    xvfb=None
    if device=='cpu':
        env.update(MUJOCO_GL='glfw',PYOPENGL_PLATFORM='glx',LIBGL_ALWAYS_SOFTWARE='1',GALLIUM_DRIVER='llvmpipe',CUDA_VISIBLE_DEVICES='')
        env['DISPLAY']=':'+str(100+int(os.environ['SLURM_JOB_ID'])%10000)
        xvfb=subprocess.Popen(['Xvfb',env['DISPLAY'],'-screen','0','1024x768x24','-nolisten','tcp'],stdout=(run/'xvfb.log').open('w'),stderr=subprocess.STDOUT)
        time.sleep(2);assert xvfb.poll() is None
    code=BASE/'candidate'
    env['PYTHONPATH']=':'.join(map(str,[code,run/'pins',*deps,ORACLE]))
    commands=[]
    if a.mode=='advisor':
        module='scripts.benchmarks.renderer_table.paired_saved'
        argv=[task['registration'],device,str(run/'measurement'),'--corpus',task['corpus'],'--batches','256','--poses','16','--backend',task['backend']]
        if profile=='pusht':
            module='scripts.benchmarks.renderer_table.pusht_saved'
            i=1 if 'Discrete' in task['registration'] else 0
            argv=['benchmark',task['registration'],str(run/'measurement'),'--oracle',str(ORACLE),'--corpus',str(ROOT/f'pusht-saved-rendering-v2-20260930/run-{i}/corpus'),'--device',device,'--batches','256']
        # Namespace loader avoids importing unrelated source training dependencies.
        bootstrap='import sys,runpy;from tests.helpers.reference.bridges import load_source;load_source(sys.argv[1],sys.argv[2]);m=sys.argv[3];sys.argv=sys.argv[3:];runpy.run_module(m,run_name="__main__")'
        commands.append([str(py),'-c',bootstrap,str(ORACLE),profile,module,*argv])
    elif a.mode=='gate':
        commands.append([str(py),'-m','pytest','tests/contracts','--contract-profile',profile,'--contract-source',str(ORACLE),'--contract-device',device,'--contract-candidate-manifest',str(BASE/'candidate-manifest.json'),'--contract-output',str(run/'contracts'),'-q','-rs','--tb=short'])
        files={'native':['test_acrobot_process.py','test_step_masking.py'], 'fetch':['test_fetch_process_adapter.py','test_fetch_execution.py'], 'dmc':['test_dmc_process_adapter.py','test_dmcontrol_execution.py'], 'ogbench':['test_ogbench_maze_process.py','test_ogbench_manipulation_process.py','test_ogbench_execution.py'], 'pusht':['test_pusht_public_semantics.py','test_pusht_replay.py'],'rocket':['test_rocket_replay_semantics.py','test_rocket_render_validation.py'],'navigation':[]}[profile]
        if files:commands.append([str(py),'-m','pytest',*[f'tests/unit/{f}' for f in files],'-q','-rs','--tb=short'])
    elif a.mode=='online':
        assert profile in ['fetch','dmc','ogbench','native']
        for version in (['candidate','baseline'] if os.environ.get('ONLINE_ORDER')=='candidate' else ['baseline','candidate']):
            work=BASE/version
            if profile=='fetch':
                cmd=[str(py),'scripts/benchmarks/online_stepping/fetch_pipeline.py','--task','Push','--production','--batches','64','256','--horizons','1','8','--suffixes','plain','--output',str(run/f'{version}.json')]
            elif profile=='dmc':
                cmd=[str(py),'scripts/benchmarks/online_stepping/dmc_pipeline.py','--domain','cheetah','--devices','cuda','--batches','64','256','--output',str(run/f'{version}.json')]
            elif profile=='ogbench':
                cmd=[str(py),'scripts/benchmarks/online_stepping/ogbench_online_memory.py','--family','Cube','--batch','64','--output',str(run/f'{version}.json')]
            else:continue
            e=env.copy();e['PYTHONPATH']=':'.join(map(str,[work,run/'pins',*deps,ORACLE]))
            with (run/f'{version}.log').open('w') as log:subprocess.run(cmd,cwd=work,env=e,stdout=log,stderr=subprocess.STDOUT,check=True)
    if device=='cuda':
        commands=[['/usr/local/cuda-12.9/bin/ncu','--profile-from-start','off','--section','SpeedOfLight','--section','SpeedOfLight_RooflineChart','--csv','--page','raw','--log-file',str(run/'ncu.csv'),*cmd] for cmd in commands]
    codes=[]
    monitor=None
    if device=='cuda':
        gpu=os.environ.get('CUDA_VISIBLE_DEVICES','0').split(',')[0]
        monitor=subprocess.Popen(['nvidia-smi','-i',gpu,'--query-gpu=timestamp,uuid,memory.used,utilization.gpu,utilization.memory,power.draw','--format=csv,noheader,nounits','--loop-ms=200'],stdout=(run/'gpu-usage.csv').open('w'),stderr=(run/'gpu-usage-error.txt').open('w'))
    try:
        for i,cmd in enumerate(commands):
            (run/f'command-{i}.json').write_text(json.dumps(cmd))
            with (run/f'command-{i}.log').open('w') as log:codes.append(subprocess.run(cmd,cwd=code,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=9600).returncode)
    finally:
        if monitor:monitor.terminate();monitor.wait()
        if xvfb:xvfb.terminate();xvfb.wait()
    (run/'terminal.json').write_text(json.dumps(dict(exit_codes=codes,job=os.environ['SLURM_JOB_ID'])))
    if any(codes):sys.exit(1)

if __name__=='__main__':main()
