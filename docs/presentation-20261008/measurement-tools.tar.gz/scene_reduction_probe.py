"""Diagnostic only: exact uint8 2x box reduction versus NumPy's generic mean."""
import json,time,statistics
from pathlib import Path
import numpy as np
rng=np.random.default_rng(31)
images=rng.integers(0,256,(64,448,448,3),dtype=np.uint8)
def old(x):return np.rint(x.reshape(224,2,224,2,3).mean((1,3))).astype(np.uint8)
def proposed(x):
 total=x[0::2,0::2].astype(np.uint16)
 total+=x[0::2,1::2];total+=x[1::2,0::2];total+=x[1::2,1::2]
 return np.rint(total*.25).astype(np.uint8)
for x in images:np.testing.assert_array_equal(old(x),proposed(x))
# All possible sums cover rounding ties and extremes independently of image content.
sums=np.arange(1021);np.testing.assert_array_equal(np.rint(sums/4),np.rint(sums*.25))
out={'scope':'Mac CPU microbenchmark; not a GPU or end-to-end speedup claim','input':'64 random 448x448 uint8 RGB frames','pixel_equality':True,'timings':{}}
for name,fn in [('generic_mean',old),('four_strided_sums',proposed)]:
 samples=[]
 for _ in range(7):
  t=time.perf_counter()
  for x in images:fn(x)
  samples.append((time.perf_counter()-t)/len(images))
 out['timings'][name]={'seconds_per_frame_mean':statistics.mean(samples),'seconds_per_frame_sd':statistics.stdev(samples)}
Path('/private/tmp/se-presentation-20261008/scene-reduction-probe.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
