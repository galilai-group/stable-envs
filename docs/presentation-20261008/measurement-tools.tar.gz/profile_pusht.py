import argparse,cProfile,io,json,pstats,statistics,time
from pathlib import Path
import numpy as np
import torch
import stable_envs as se

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--device',default='cpu');a=p.parse_args()
torch.set_num_threads(1)
report=[]
for batch in (1,64,256):
 with se.PushT(num_envs=batch,device=a.device) as env:
  state=env.reset(seed=17);projected=env.to_render_state(state);env.render(projected)
  def validation_copy(): return env.to_render_state(projected).cpu()
  def rows_for(s):
   fields={'/'.join(k):v.numpy() for k,v in s.items(True,True)}
   return [{k:v[i] for k,v in fields.items()} for i in range(batch)]
  cpu=projected.cpu();rows=rows_for(cpu)
  funcs={'public_render':lambda:env.render(projected),'validate_clone_to_cpu':validation_copy,'assemble_rows':lambda:rows_for(cpu),'projection_install_and_draw':lambda:env._projection.render(rows,env.size),'cached_scenes_draw_only':lambda:np.stack([entry[1].render() for entry in env._projection.scenes])}
  cell={'batch':batch,'device':a.device,'projected_fields':len(projected.keys(True,True)),'projected_bytes':sum(v.numel()*v.element_size() for v in projected.values(True,True)),'timings':{}}
  for name,fn in funcs.items():
   fn();samples=[]
   for _ in range(5):
    if a.device=='cuda':torch.cuda.synchronize()
    start=time.perf_counter();result=fn()
    if a.device=='cuda':torch.cuda.synchronize()
    samples.append(time.perf_counter()-start);del result
   cell['timings'][name]={'seconds_mean':statistics.mean(samples),'seconds_sd':statistics.stdev(samples),'samples':samples}
  pr=cProfile.Profile();pr.enable();env.render(projected);pr.disable();out=io.StringIO();pstats.Stats(pr,stream=out).sort_stats('cumulative').print_stats(35);cell['profile']=out.getvalue();report.append(cell)
  a.output.write_text(json.dumps(report,indent=2));print(batch,{k:round(v['seconds_mean']*1000,3) for k,v in cell['timings'].items()},flush=True)
