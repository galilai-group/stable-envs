"""Collect this campaign; leave tracked report files untouched."""
import datetime,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BACKUP=Path('/Users/samib/stable-envs/branch-backups/presentation-20261008')
DEST=BACKUP/'latest-tables';DEST.mkdir(exist_ok=True)
ARCHIVES=BACKUP/'results';ARCHIVES.mkdir(exist_ok=True)
HOST='sboughan@sshcampus.ccv.brown.edu';REMOTE='/users/sboughan/se-presentation-20261008/'
JOBS='7122480,7122737,7122917,7123113,7123155,7123308,7123233,7123441,7124020,7124430,7125600,7124828,7125430'
env=os.environ.copy();env['PRESENTATION_OUTPUT']=str(DEST)
def run(cmd,**kwargs):return subprocess.run(cmd,check=True,timeout=900,**kwargs)
for attempt in range(720):
 stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  filters=[f'--include={pattern}' for pattern in ['advisor-*.tar.gz','online-*.tar.gz','diagnostic-*.tar.gz','usage-*.tar.gz','nsys-*.tar.gz','*.exit']]
  run(['rsync','-rt','--omit-dir-times','--ignore-existing',*filters,'--exclude=*',HOST+':'+REMOTE,str(ROOT/'results')+'/'])
  with (ROOT/'scheduler.tsv').open('w') as f:run(['ssh','-o','BatchMode=yes',HOST,'sacct -j '+JOBS+' --parsable2 --noheader --format=JobID,JobIDRaw,State,ExitCode,Elapsed,MaxRSS,NodeList'],stdout=f)
  for path in (ROOT/'results').glob('*.tar.gz'):
   if not (ARCHIVES/path.name).exists():shutil.copy2(path,ARCHIVES/path.name)
  for script in ['export.py','export_usage.py','summarize.py','slow_plan.py','validate_tables.py']:run([sys.executable,str(ROOT/script)],env=env)
  queue=run(['ssh','-o','BatchMode=yes',HOST,'squeue -u sboughan -h -o "%j"'],text=True,capture_output=True).stdout
  active=any(line.startswith('se-presentation-') for line in queue.splitlines())
  (BACKUP/'collector-status.json').write_text(json.dumps(dict(updated_utc=stamp,active_jobs=active,output=str(DEST),pid=os.getpid()),indent=2)+'\n')
  print(stamp,'collected; active jobs:',active,flush=True)
  if not active:break
 except Exception as exc:print(stamp,repr(exc),flush=True)
 time.sleep(120)
