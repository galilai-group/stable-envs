import os
"""Summarize device counters only inside labelled render-call intervals."""
import bisect,csv,json,sqlite3,statistics
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=Path(os.environ.get('PRESENTATION_OUTPUT','/Users/samib/stable-envs/docs/presentation-20261008'))
METRICS={
 'GPU Active [Throughput %]':'gpu_active_pct',
 'SMs Active [Throughput %]':'sm_active_pct',
 'SM Issue [Throughput %]':'sm_issue_pct',
 'Tensor Active [Throughput %]':'tensor_active_pct',
 'Compute Warps in Flight [Throughput %]':'compute_warps_pct',
 'Pixel Warps in Flight [Throughput %]':'pixel_warps_pct',
 'DRAM Read Bandwidth [Throughput %]':'dram_read_pct',
 'DRAM Write Bandwidth [Throughput %]':'dram_write_pct',
}
rows=[]
for path in sorted((ROOT/'results').glob('usage-*/usage.sqlite')):
 task=json.loads((path.parent/'task.json').read_text())
 c=sqlite3.connect(f'file:{path}?mode=ro',uri=True)
 tables={r[0] for r in c.execute("select name from sqlite_master where type='table'")}
 if not {'GPU_METRICS','NVTX_EVENTS','TARGET_INFO_GPU_METRICS'}<=tables:continue
 metrics={(t,m):name for t,m,name in c.execute('select typeId,metricId,metricName from TARGET_INFO_GPU_METRICS') if name in METRICS}
 ranges=[(start,end,label) for start,end,label in c.execute('select start,end,text from NVTX_EVENTS order by start') if label and label.startswith(('ours:B','source:B')) and end]
 if not ranges:continue
 assert all(a[1]<=b[0] for a,b in zip(ranges,ranges[1:])), 'render ranges overlap'
 starts=[r[0] for r in ranges]; values=defaultdict(list)
 # Stream once; binary search prevents an expensive SQL interval cross join.
 for ts,t,m,value in c.execute('select timestamp,typeId,metricId,value from GPU_METRICS where timestamp>=? and timestamp<=?',(starts[0],ranges[-1][1])):
  name=metrics.get((t,m))
  if name is None or value is None:continue
  index=bisect.bisect_right(starts,ts)-1
  if index>=0 and ts<ranges[index][1]:values[ranges[index][2],name].append(value)
 for label in sorted({r[2] for r in ranges}):
  arm,batch,dest=label.split(':'); own=[r for r in ranges if r[2]==label]
  result=dict(env=task['registration'],batch=int(batch[1:]),output_device=dest,arm=arm,status='MEASURED',mfu_percent='',mfu_status='UNDEFINED_USEFUL_FLOPS',profiled_render_calls=len(own),profiled_range_ms=sum(end-start for start,end,_ in own)/1e6,sampling_hz=1000,scope='device-wide samples inside synchronous render-call NVTX ranges; separate diagnostic, not FPS run',evidence=str(path.relative_to(ROOT)))
  for name,column in METRICS.items():
   data=values[label,name]; result[column+'_samples']=len(data)
   result[column+'_mean']=statistics.mean(data) if data else ''
   result[column+'_sd']=statistics.stdev(data) if len(data)>1 else ''
  if not values[label,'SMs Active [Throughput %]']:result['status']='NO_IN_RANGE_SAMPLES'
  rows.append(result)
 c.close()
fields=list(dict.fromkeys(k for row in rows for k in row))
if rows:
 with (OUT/'gpu-utilization-source-vs-ours.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 lookup={(r['env'],r['batch'],r['output_device'],r['arm']):r for r in rows}
 for filename in ['render-only.csv','render-only-cpu-gpu.csv']:
  with (OUT/filename).open() as f:table=list(csv.DictReader(f))
  for row in table:
   if filename=='render-only.csv' and row['candidate_device']!='cuda':continue
   dest=row['output_device'] if filename=='render-only.csv' else 'cuda'
   for arm in ['ours','source']:
    usage=lookup.get((row['env'],int(row['batch']),dest,arm),{})
    row[f'{arm}_gpu_counter_status']=usage.get('status','PENDING')
    for column in METRICS.values():
     for stat in ['mean','sd','samples']:row[f'{arm}_{column}_{stat}']=usage.get(column+'_'+stat,'')
  with (OUT/filename).open('w') as f:
   w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in table for k in row)));w.writeheader();w.writerows(table)
print(f'{len(rows)} source/ours GPU-utilization cells exported')
