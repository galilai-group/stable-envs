import gymnasium as gym


class ArraySpace(gym.Space):
    """Shape/dtype transport descriptor without image-sized low/high arrays."""
    def __init__(self,shape,dtype):super().__init__(shape=shape,dtype=dtype)
    def __eq__(self,other):return isinstance(other,ArraySpace) and self.shape==other.shape and self.dtype==other.dtype


from gymnasium.vector import utils as vector_utils
for transport in (vector_utils.create_shared_memory,vector_utils.read_from_shared_memory,
                  vector_utils.write_to_shared_memory,vector_utils.create_empty_array,
                  vector_utils.iterate,vector_utils.concatenate):
    transport.register(ArraySpace)(transport.dispatch(gym.spaces.Box))
@vector_utils.batch_space.register(ArraySpace)
def batch_array_space(space,n=1):return ArraySpace((n,*space.shape),space.dtype)


