import cProfile,io,json,pstats,time,statistics
from pathlib import Path
import numpy as np,torch
from tensordict import TensorDict
import stable_envs as se
from stable_envs.envs._pusht_projection import PushTProjection
root=Path('/private/tmp/se-presentation-20261008')
path=Path('/private/tmp/adapter-campaign/results/advisor-36-7120712/measurement/render-states.npz')
torch.set_num_threads(1)
with np.load(path,allow_pickle=False) as data:state=TensorDict({tuple(json.loads(k)):torch.from_numpy(data[k].copy()) for k in data.files},[1024])
report=[]
original=PushTProjection._scene
for batch in [64,256,1024]:
 with se.PushT(size=224) as env:
  chunks=[state[i:i+batch] for i in range(0,1024,batch)]
  run=lambda:[env.render(s) for s in chunks]
  run();samples=[]
  for _ in range(3):
   start=time.perf_counter();run();samples.append(time.perf_counter()-start)
  counts={'calls':0,'rebuilds':0}
  def counted(self,lane,row):
   old=self.scenes[lane][1] if lane<len(self.scenes) and self.scenes[lane] else None
   new=original(self,lane,row);counts['calls']+=1;counts['rebuilds']+=new is not old;return new
  PushTProjection._scene=counted
  profile=cProfile.Profile();profile.enable();run();profile.disable();PushTProjection._scene=original
  out=io.StringIO();pstats.Stats(profile,stream=out).sort_stats('cumulative').print_stats(35)
  report.append(dict(batch=batch,frames=1024,seconds_mean=statistics.mean(samples),seconds_sd=statistics.stdev(samples),**counts,profile=out.getvalue()))
  (root/'pusht-corpus-profile.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report[-1].items() if k!='profile'},flush=True)
