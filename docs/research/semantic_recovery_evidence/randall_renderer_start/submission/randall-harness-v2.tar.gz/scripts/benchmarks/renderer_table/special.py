"""Accepted oracle witnesses for explicit-JAX and controlled-entropy families."""

import hashlib
import importlib.util
import pickle

import numpy as np

from .common import ROOT, state_hash


class CraftaxBridge:
    def __init__(self, row, seed, options):
        from tests.helpers.reference.craftax_source import oracle

        self.name, self.options = row["name"], options
        self.source = oracle(self.name)
        self.camera = "registered pixel observation (no camera control)"
        self.helper = "tests/helpers/reference/craftax_source.py:assert_engine"

    def reset(self, seed):
        return self.source.reset(seed=seed, options=self.options)

    def step(self, action):
        return self.source.step(int(action[0, 0]))

    def proof(self, env):
        from tests.helpers.reference.craftax_source import assert_engine

        assert_engine(self.source, env, env.get_state())
        return dict(
            kind="ACCEPTED_SEMANTIC_WITNESS",
            equal=True,
            helper=self.helper,
            candidate_state_hash=state_hash(env.get_state()),
            oracle_state_hash=self.snapshot(),
            compared="all numeric upstream engine pytree leaves and wrapper PRNG key; source output cache retained in render nonmutation hash",
        )

    def snapshot(self):
        from stable_envs._adapters.craftax import numeric_leaves

        return state_hash(
            {
                **{"engine/" + "/".join(k): v for k, v in numeric_leaves(self.source._state)},
                "key": np.asarray(self.source._key),
                "last_obs": self.source._last_obs,
            }
        )

    def render(self):
        return self.source.render()

    def close(self):
        self.source.close()


class ManipulationBridge:
    def __init__(self, row, seed, options):
        self.name, self.options = row["name"], options
        path = ROOT / "docs/research/semantic_recovery_evidence/ogb_rng_feasibility/ownership.py"
        spec = importlib.util.spec_from_file_location("randall_ogb_oracle", path)
        self.module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.module)
        self.source = getattr(self.module, "Owned" + self.name[3:])(entropy_seed=seed)
        self.camera = "front"
        self.helper = "tests/unit/test_ogbench_manipulation_cpu.py:assert_oracle"

    def reset(self, seed):
        return self.source.reset(seed=seed, options=self.options)

    def step(self, action):
        return self.source.step(action[0])

    def proof(self, env):
        from tests.unit.test_ogbench_manipulation_cpu import assert_oracle

        assert_oracle(env._simulator.envs[0], self.source, self.module)
        return dict(
            kind="ACCEPTED_SEMANTIC_WITNESS",
            equal=True,
            helper=self.helper,
            candidate_state_hash=state_hash(env.get_state()),
            oracle_state_hash=self.snapshot(),
            compared="engine, observation, reset/step info, model arrays, PCG64, task MT19937, action-space and Variation entropy ownership",
        )

    def snapshot(self):
        return hashlib.sha256(pickle.dumps(self.module.result(self.source, None))).hexdigest()

    def render(self):
        return self.source.render(camera="front")

    def close(self):
        self.source.close()


def bridge_for(row, seed, options):
    from .bridges import Bridge

    if row["name"].startswith("Craftax"):
        return CraftaxBridge(row, seed, options)
    if row["name"] in {"OGBCube", "OGBScene"}:
        return ManipulationBridge(row, seed, options)
    return Bridge(row, seed, options)
