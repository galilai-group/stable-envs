"""Isolate CPU/software-GL and native-GPU measurements on one allocated node."""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

from .bridges import CLASSIC, DMC, NAV
from .common import catalog, write


def main():
    p = argparse.ArgumentParser()
    p.add_argument("cohort", choices=["native", "dmc", "fetch"])
    p.add_argument("output", type=Path)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    chosen = []
    for row in catalog().values():
        name = row["name"]
        if (
            (args.cohort == "native" and name in {*CLASSIC, *NAV})
            or (args.cohort == "dmc" and name in {*DMC, "PointMazeLargeNavigate"})
            or (args.cohort == "fetch" and name.startswith("Fetch"))
        ):
            chosen.append(row)
    results = []
    for row in chosen:
        directory = args.output / row["name"]
        directory.mkdir()
        status = dict(registration=row["registration"], phases={})
        for phase in ["cpu", "gpu"]:
            env = os.environ.copy()
            if phase == "cpu":
                env.update(
                    MUJOCO_GL="glfw", PYOPENGL_PLATFORM="glx", LIBGL_ALWAYS_SOFTWARE="1", GALLIUM_DRIVER="llvmpipe"
                )
            else:
                env.update(MUJOCO_GL="egl", PYOPENGL_PLATFORM="egl")
                for key in ["LIBGL_ALWAYS_SOFTWARE", "GALLIUM_DRIVER"]:
                    env.pop(key, None)
            command = [
                sys.executable,
                "-m",
                "scripts.benchmarks.renderer_table.collect",
                row["registration"],
                phase,
                str(directory / phase),
            ]
            if phase == "gpu":
                command += ["--corpus", str(directory / "cpu")]
            with (directory / (phase + ".log")).open("w") as log:
                code = subprocess.call(command, env=env, stdout=log, stderr=subprocess.STDOUT)
            status["phases"][phase] = dict(returncode=code, command=command)
            write(directory / "status.json", status)
            print(json.dumps(status), flush=True)
            if code and phase == "cpu":
                break
        results.append(status)
        write(args.output / "status.json", results)


if __name__ == "__main__":
    main()
