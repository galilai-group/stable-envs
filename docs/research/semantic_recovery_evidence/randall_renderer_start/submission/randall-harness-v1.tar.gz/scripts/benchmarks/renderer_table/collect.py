"""Generate matched CPU trajectories, then time public GPU rendering of that corpus.

Every invocation owns a fresh output directory. Failures are retained as ERROR;
they are never converted into unsupported measurements by the collector.
"""

import argparse
import hashlib
import inspect
import json
import math
import sys
import traceback
from pathlib import Path

import numpy as np
import torch

from .bridges import DMC, Bridge, action_sequence, checkpoints
from .common import (
    PIN,
    array_hash,
    catalog,
    load_state,
    profile,
    public_render,
    quality,
    rgb,
    save_state,
    state_hash,
    timed,
    unavailable,
    write,
)


def appearance_options(source):
    """One combined registered color/light case, explicitly recorded in the recipe."""
    from tests.helpers.reference.variation import swm_variation_space

    values = {}
    try:
        space = swm_variation_space(source)
    except AttributeError:
        return {}
    for path in space.names():
        leaf = space
        for part in path.split("."):
            leaf = leaf[part]
        if ("color" in path or path.startswith("visuals.")) and np.asarray(leaf.value).size == 3:
            values[path] = np.asarray(leaf.low + (leaf.high - leaf.low) * 0.35, dtype=leaf.dtype)
    return {"variation": [], "variation_values": values} if values else {}


def candidate(row, device, seed):
    import stable_envs as se

    return se.make(row["name"], num_envs=1, device=device, seed=seed)


def render_kwargs(env, bridge):
    from tests.helpers.reference.variation import style_from_swm_env, variation_map

    if variation_map(env) is None:
        return {}
    return {"style": torch.as_tensor(style_from_swm_env(env, bridge.source))[None].to(env.device)}


def kwargs_json(kwargs):
    return {k: v.cpu().numpy().tolist() if torch.is_tensor(v) else v for k, v in kwargs.items()}


def cpu(row, output):
    result = dict(row, phase="cpu", oracle_commit=PIN, profile=profile(), frames=[], recipes=[], status="RUNNING")
    write(output / "result.json", result)
    name = row["name"]
    probe = Bridge(row, 17, {})
    varied = appearance_options(probe.source)
    probe.close()
    dtypes = ["float64"] if name in DMC else ["float32", "float64"]
    if name in {"CartPole", "Acrobot", "MountainCar"}:
        dtypes = ["int64"]
    plans = [(s, d, {}) for s in [0, 17, 42] for d in dtypes]
    if varied:
        plans.append((17, dtypes[0], varied))
    frame_count = len(plans) * 6
    samples = max(1, math.ceil(100 / frame_count))
    for case, (seed, dtype, options) in enumerate(plans):
        bridge = Bridge(row, seed, options)
        env = candidate(row, "cpu", seed)
        try:
            reset_kw = {"options": options} if "options" in inspect.signature(env.reset).parameters else {}
            # DMC reset has no options API; apply only mapped appearance values.
            if options and not reset_kw:
                from tests.helpers.reference.variation import style_from_swm_env

                bridge.reset(seed)
                env.set_variation(style_from_swm_env(env, bridge.source))
                env.reset(seed)
            else:
                bridge.reset(seed)
                env.reset(seed, **reset_kw)
            marks = checkpoints(name)
            actions = action_sequence(bridge.source, name, seed, dtype, max(marks))
            np.save(output / f"actions-{case}.npy", actions, allow_pickle=False)
            recipe = dict(
                case=case,
                seed=seed,
                action_dtype=str(actions.dtype),
                reset_options=options,
                action_generator="numpy.default_rng(90000+seed).uniform(action_space.low, high) or integers(0,n)",
                actions_file=f"actions-{case}.npy",
                actions_hash=array_hash(actions),
                camera=bridge.camera,
                checkpoints=marks,
                constructor={"num_envs": 1, "seed": seed},
            )
            result["recipes"].append(recipe)
            for step in range(max(marks) + 1):
                done = False
                if step:
                    action = actions[step - 1]
                    bridge.step(action)
                    out = env.step(action)
                    if name in CLASSIC or name.startswith("Fetch"):
                        done = bool(out["terminated"].any() or out["truncated"].any())
                if step not in marks and not done:
                    continue
                proof = bridge.proof(env)
                state = env.get_state()
                state_before, oracle_before = state_hash(state), bridge.snapshot()
                kw = render_kwargs(env, bridge)
                timing, original = timed(bridge.render, samples=samples)
                original = rgb(original)
                assert bridge.snapshot() == oracle_before, "oracle render mutated continuation State"
                index = len(result["frames"])
                key = f"frame-{index:04d}"
                np.save(output / (key + "-oracle.npy"), original, allow_pickle=False)
                save_state(output / (key + "-state.npz"), state)
                record = dict(
                    index=index,
                    case=case,
                    step=step,
                    seed=seed,
                    action_dtype=str(actions.dtype),
                    prefix_hash=array_hash(actions[:step]),
                    proof=proof,
                    state_file=key + "-state.npz",
                    state_hash=state_before,
                    oracle_file=key + "-oracle.npy",
                    camera=bridge.camera,
                    shape=list(original.shape),
                    oracle_sha256=hashlib.sha256(original.tobytes()).hexdigest(),
                    render_kwargs=kwargs_json(kw),
                    original_timing=timing,
                    original_backend="Mesa llvmpipe software OpenGL"
                    if name in DMC or name == "PointMazeLargeNavigate"
                    else "CPU software raster",
                    oracle_render_nonmutation=True,
                )
                try:
                    timing, image = timed(lambda: public_render(env, state, **kw), samples=samples)
                    image = rgb(image)
                    record.update(cpu_timing=timing, cpu_quality=quality(image, original))
                    np.save(output / (key + "-cpu.npy"), image, allow_pickle=False)
                except NotImplementedError as e:
                    record["cpu_timing"] = unavailable(str(e))
                assert state_hash(env.get_state()) == state_before, "candidate renderer mutated live State"
                assert state_hash(state) == state_before, "candidate renderer mutated supplied State"
                bridge.proof(env)
                record["candidate_render_nonmutation"] = True
                result["frames"].append(record)
                write(output / "result.json", result)
                print(name, case, step, "matched", flush=True)
                if done:
                    break
        finally:
            env.close()
            bridge.close()
    result["status"] = "COMPLETE"
    write(output / "result.json", result)
    return result


def gpu(row, corpus, output):
    source = json.loads((corpus / "result.json").read_text())
    assert source["status"] == "COMPLETE"
    result = dict(
        row,
        phase="gpu",
        profile=profile(),
        frames=[],
        status="RUNNING",
        corpus_result_sha256=hashlib.sha256((corpus / "result.json").read_bytes()).hexdigest(),
    )
    write(output / "result.json", result)
    env = candidate(row, "cuda", 0)
    try:
        before = state_hash(env.get_state())
        for f in source["frames"]:
            state = load_state(corpus / f["state_file"], "cuda")
            assert state_hash(state) == f["state_hash"]
            kwargs = {
                k: torch.tensor(v, dtype=torch.float32, device="cuda") if k == "style" else v
                for k, v in f["render_kwargs"].items()
            }
            timing, image = timed(
                lambda: public_render(env, state, **kwargs),
                gpu=True,
                samples=max(1, math.ceil(100 / len(source["frames"]))),
            )
            assert torch.is_tensor(image) and image.device.type == "cuda", "public GPU output was not native CUDA"
            host_timing, host_image = timed(
                lambda: public_render(env, state, **kwargs),
                gpu=True,
                to_host=True,
                samples=max(1, math.ceil(100 / len(source["frames"]))),
            )
            image = rgb(image)
            assert np.array_equal(image, rgb(host_image))
            original = np.load(corpus / f["oracle_file"], allow_pickle=False)
            assert hashlib.sha256(original.tobytes()).hexdigest() == f["oracle_sha256"]
            assert state_hash(state) == f["state_hash"] and state_hash(env.get_state()) == before
            record = dict(
                index=f["index"],
                state_hash=f["state_hash"],
                camera=f["camera"],
                shape=list(image.shape),
                gpu_timing=timing,
                gpu_to_cpu_timing=host_timing,
                gpu_quality=quality(image, original),
                supplied_and_live_state_nonmutation=True,
            )
            np.save(output / f"frame-{f['index']:04d}-gpu.npy", image, allow_pickle=False)
            result["frames"].append(record)
            write(output / "result.json", result)
            print(row["name"], f["index"], "GPU measured", flush=True)
    finally:
        env.close()
    result["status"] = "COMPLETE"
    write(output / "result.json", result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("registration")
    parser.add_argument("phase", choices=["cpu", "gpu"])
    parser.add_argument("output", type=Path)
    parser.add_argument("--corpus", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    row = catalog()[args.registration]
    try:
        if args.phase == "cpu":
            cpu(row, args.output)
        else:
            gpu(row, args.corpus, args.output)
    except Exception:
        write(args.output / "error.json", dict(status="ERROR", traceback=traceback.format_exc(), command=sys.argv))
        raise


if __name__ == "__main__":
    main()
