"""Independently recompute retained Rocket pixel diagnostics and script hashes."""

import argparse
import hashlib
import json
import tarfile
from pathlib import Path

import numpy as np


def verify(root):
    reports = []
    sequence = root / "rocket-sequence-v1-20261004/results/6995655/probe/witness.npz"
    source = np.load(sequence, allow_pickle=False)["source"]
    for path in sorted(root.rglob("result.json")):
        data = json.loads(path.read_text())
        if "trials" not in data:
            continue
        run = path.parent.parent.parent.parent
        manifest = json.loads((run / "patch_manifest.json").read_text())
        with tarfile.open(run / "patch.tar.gz") as archive:
            for name, digest in manifest["files"].items():
                assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == digest
        assert data["script_sha256"] in manifest["files"].values()
        assert data["input_sha256"] == hashlib.sha256(sequence.read_bytes()).hexdigest()
        with np.load(path.parent / "witness.npz", allow_pickle=False) as raw:
            np.testing.assert_array_equal(source, raw["source"])
            for trial in data["trials"]:
                frames = raw[trial["kind"]]
                assert frames.shape == source.shape and frames.dtype == np.uint8
                mse = np.sum((frames.astype(np.int64) - source) ** 2, axis=(-3, -2, -1)) / (
                    255**2 * np.prod(source.shape[-3:])
                )
                np.testing.assert_allclose(mse, trial["mse"], rtol=1e-14, atol=0)
                reports.append(
                    dict(job=data["job"], kind=trial["kind"], frames=int(mse.size), max_mse=float(mse.max()))
                )
    assert len(reports) == 10
    with np.load(sequence, allow_pickle=False) as raw:
        np.testing.assert_array_equal(raw["source"], raw["cpu"])
        for name in ("render_restored", "render_chunk1", "single", "reversed"):
            np.testing.assert_array_equal(raw["online"], raw[name])
    a = np.load(root / "rocket-exhaustive-v1-20261004/results/6995863/probe/witness.npz", allow_pickle=False)
    b = np.load(root / "rocket-triangle-v1-20261004/results/6995878/probe/witness.npz", allow_pickle=False)
    np.testing.assert_array_equal(a["exhaustive_coverage"], b["triangle_coverage"])
    return dict(
        status="VERIFIED_DIAGNOSTICS_NOT_ACCEPTANCE",
        recomputed_frame_comparisons=sum(r["frames"] for r in reports),
        reports=reports,
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("root", type=Path)
    args = p.parse_args()
    print(json.dumps(verify(args.root), indent=2))
