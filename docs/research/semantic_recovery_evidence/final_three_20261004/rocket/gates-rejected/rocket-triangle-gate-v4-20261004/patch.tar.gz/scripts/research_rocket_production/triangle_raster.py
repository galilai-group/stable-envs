"""Research-only GPU implementation of the exhaustive TinyRenderer coverage proof."""

import torch
import triton as tr
import triton.language as tl


@tr.jit
def vertex(Pos, Faces, world, face, corner, V: tl.constexpr, R: tl.constexpr):
    idx = tl.load(Faces + face * 3 + corner)
    offset = (world * V + idx) * 4
    x, y = tl.load(Pos + offset), tl.load(Pos + offset + 1)
    z, w = tl.load(Pos + offset + 2), tl.load(Pos + offset + 3)
    # Preserve source float32 viewport arithmetic, then double barycentrics.
    x = ((x * (R / 2)) + (w * (R / 2))) / w
    y = ((y * (R / 2)) + (w * (R / 2))) / w
    return x.to(tl.float64), y.to(tl.float64), z.to(tl.float64), w.to(tl.float64)


@tr.jit
def weights(x, y, x0, y0, z0, w0, x1, y1, z1, w1, x2, y2, z2, w2):
    det = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
    a = ((y1 - y2) * (x - x2) + (x2 - x1) * (y - y2)) / det
    b = ((y2 - y0) * (x - x2) + (x0 - x2) * (y - y2)) / det
    c = 1 - a - b
    p, q, r = a / w0, b / w1, c / w2
    total = p + q + r
    p, q, r = p / total, q / total, r / total
    depth = p * z0 + q * z1 + r * z2
    ndc = a * (z0 / w0) + b * (z1 / w1) + c * (z2 / w2)
    valid = (
        (tl.abs(det) > 1e-12)
        & (a >= 0)
        & (b >= 0)
        & (c >= 0)
        & (w0 > 0)
        & (w1 > 0)
        & (w2 > 0)
        & (ndc >= -1)
        & (ndc <= 1)
    )
    return p, q, ndc, depth, valid


@tr.jit
def triangles(Pos, Faces, Depth, Ids, V: tl.constexpr, R: tl.constexpr, IDS: tl.constexpr, BLOCK: tl.constexpr):
    face, world = tl.program_id(0), tl.program_id(1)
    x0, y0, z0, w0 = vertex(Pos, Faces, world, face, 0, V, R)
    x1, y1, z1, w1 = vertex(Pos, Faces, world, face, 1, V, R)
    x2, y2, z2, w2 = vertex(Pos, Faces, world, face, 2, V, R)
    lo_x = tl.maximum(0, tl.ceil(tl.minimum(x0, tl.minimum(x1, x2)))).to(tl.int32)
    hi_x = tl.minimum(R - 1, tl.floor(tl.maximum(x0, tl.maximum(x1, x2)))).to(tl.int32)
    lo_y = tl.maximum(0, tl.ceil(tl.minimum(y0, tl.minimum(y1, y2)))).to(tl.int32)
    hi_y = tl.minimum(R - 1, tl.floor(tl.maximum(y0, tl.maximum(y1, y2)))).to(tl.int32)
    width = tl.maximum(0, hi_x - lo_x + 1)
    count = width * tl.maximum(0, hi_y - lo_y + 1)
    if (w0 > 0) & (w1 > 0) & (w2 > 0):
        for start in range(tl.program_id(2) * BLOCK, count, 4 * BLOCK):
            i = start + tl.arange(0, BLOCK)
            x, y = lo_x + i % width, lo_y + i // width
            p, q, ndc, depth, valid = weights(
                x.to(tl.float64), y.to(tl.float64), x0, y0, z0, w0, x1, y1, z1, w1, x2, y2, z2, w2
            )
            mask = (i < count) & valid
            bits = depth.to(tl.int64, bitcast=True)
            key = tl.where(bits < 0, (~bits) ^ (-9223372036854775807 - 1), bits)
            offset = (world * R + y) * R + x
            if IDS:
                winning = tl.load(Depth + offset, mask=mask, other=9223372036854775807)
                tl.atomic_max(Ids + offset, face + 1, mask=mask & (key == winning), sem="relaxed")
            else:
                tl.atomic_min(Depth + offset, key, mask=mask, sem="relaxed")


@tr.jit
def resolve(Pos, Faces, Ids, Out, V: tl.constexpr, R: tl.constexpr, BLOCK: tl.constexpr):
    world = tl.program_id(1)
    pixel = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    hit = tl.load(Ids + world * R * R + pixel, mask=pixel < R * R, other=0)
    face = tl.maximum(hit - 1, 0)
    x0, y0, z0, w0 = vertex(Pos, Faces, world, face, 0, V, R)
    x1, y1, z1, w1 = vertex(Pos, Faces, world, face, 1, V, R)
    x2, y2, z2, w2 = vertex(Pos, Faces, world, face, 2, V, R)
    p, q, ndc, depth, valid = weights(
        (pixel % R).to(tl.float64), (pixel // R).to(tl.float64), x0, y0, z0, w0, x1, y1, z1, w1, x2, y2, z2, w2
    )
    base = (world * R * R + pixel) * 4
    tl.store(Out + base, tl.where(hit > 0, p, 0), mask=pixel < R * R)
    tl.store(Out + base + 1, tl.where(hit > 0, q, 0), mask=pixel < R * R)
    tl.store(Out + base + 2, tl.where(hit > 0, ndc, 0), mask=pixel < R * R)
    tl.store(Out + base + 3, hit, mask=pixel < R * R)


def rasterize(pos, faces, resolution):
    b, v, _ = pos.shape
    r = resolution
    depth = torch.full((b, r, r), torch.iinfo(torch.int64).max, device=pos.device, dtype=torch.int64)
    ids = torch.zeros((b, r, r), device=pos.device, dtype=torch.int32)
    out = torch.empty((b, r, r, 4), device=pos.device, dtype=torch.float32)
    for index in (False, True):
        triangles[(len(faces), b, 4)](pos, faces, depth, ids, v, r, index, 128, enable_fp_fusion=False)
    resolve[(tr.cdiv(r * r, 128), b)](pos, faces, ids, out, v, r, 128, enable_fp_fusion=False)
    return out
