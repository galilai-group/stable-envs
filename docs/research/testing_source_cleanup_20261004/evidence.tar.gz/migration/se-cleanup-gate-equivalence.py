import importlib.util,importlib.metadata,json,sys,tomllib
from pathlib import Path
from tests.helpers.reference.bridges import load_source
from tests.helpers.reference import native_acceptance as new
load_source('/Users/samib/stable-worldmodel','native')
sys.modules['stable_worldmodel'].__file__='/Users/samib/stable-worldmodel/stable_worldmodel/__init__.py'
base=Path('/private/tmp/se-cleanup-f49a6816-baseline')
def load(name):
 p=base/(name+'.py');spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old_remaining=load('native_classic_remaining_semantics')
sys.modules['tests.helpers.reference.native_classic_remaining_semantics']=old_remaining
old_native=load('native_classic_semantics')
version=importlib.metadata.version
source_version=tomllib.loads(Path("/Users/samib/stable-worldmodel/pyproject.toml").read_text())["project"]["version"]
importlib.metadata.version=lambda name: source_version if name=="stable-worldmodel" else version(name)
records=[]
for name,cls in [('native_classic_gate',old_native.NativeClassicReference),('native_classic_remaining_gate',old_remaining.NativeClassicRemainingReference)]:
 m=load(name)
 setattr(m,'NativeClassicReference' if name=='native_classic_gate' else 'NativeClassicRemainingReference',cls)
 try:m.run_gate('cpu')
 except AssertionError as exc:
  assert 'State keys differ' in str(exc),str(exc)
  obsolete=str(exc)
 else:raise AssertionError('Expected baseline scalar API mismatch')
 # Adapt only the obsolete scalar response comparison, without changing source values.
 original=m.compare_state
 def scalar_compare(a,b):
  if 'valid' in a.keys() and 'valid' not in b.keys():
   assert a['valid'].all()
   assert a['state_valid'].all()
   for k in a['state'].keys(True,True):
    assert (a['states'][k].squeeze(1)==a['state'][k]).all(),k
   a=a.exclude('valid','states','state_valid')
  return original(a,b)
 m.compare_state=scalar_compare
 old=m.run_gate('cpu');got=new.run_gate(tuple(m.CASES),'cpu')
 assert old['cases']==got['cases'],(old['cases'],got['cases'])
 assert old['physical_variation']==got['physical_variation']
 if name=='native_classic_remaining_gate':assert old['continuous_dtype_flag_necessity']==got['dtype_control']
 records.append(dict(gate=name,status='EXACT',cases=len(old['cases']),variation_cases=len(old['physical_variation']),baseline_interface_failure=obsolete,adjustment='Check captured State and validity, exclude only scalar capture metadata before legacy comparison'))
Path('/private/tmp/se-cleanup-gate-equivalence.json').write_text(json.dumps(records,indent=2)+'\n')
print('EXACT',sum(x['cases'] for x in records),'case records')
