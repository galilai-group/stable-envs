from stable_envs.testing.provenance import pinned_source_identity
from tests.helpers.reference.saved import SWM_PIN
from tests.helpers.reference.profiles import PINS
from tests.helpers.reference.bridges import load_source
import pytest
pinned_source_identity('/Users/samib/stable-worldmodel', SWM_PIN, PINS['ogbench'])
load_source('/Users/samib/stable-worldmodel','ogbench')
raise SystemExit(pytest.main(['-q','tests/unit/test_ogbench_manipulation_cpu.py','-k','controlled_oracle_reset_and_action_parity or reward_routes_delegate_without_task_draw']))
