import ast,subprocess
from pathlib import Path
base=Path('/private/tmp/se-cleanup-f49a6816-baseline')
def original(name):
 s=subprocess.check_output(['git','show','f49a6816:scripts/recovery/'+name+'.py'],text=True);(base/(name+'.py')).write_text(s);return s
first=original('native_classic_gate');remaining=original('native_classic_remaining_gate')
def func(source,name,new=None):
 n=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name==name)
 out='\n'.join(source.splitlines()[n.lineno-1:n.end_lineno])+'\n\n'
 return out.replace('def '+name+'(', 'def '+(new or name)+'(')
header='''"""Specialized native-control acceptance witnesses shared by pytest and CLIs.

Case bodies preserve the historical seeds, batches, horizons, task/action edges,
Variation values and rejected controls. Source fields never use candidate export.
"""

import numpy as np
import torch
import stable_envs as se
from tests.helpers.reference.native_classic_semantics import NativeClassicReference
from tests.helpers.reference.profiles import PROFILES
from tests.helpers.reference.semantics import (
    check_reset_matches_reference, check_state_roundtrip, check_step_matches_reference,
    check_two_histories_same_state, compare_state as _compare_state,
)

CASES = {case.domain: dict(historical_id=case.registration, stable_env=case.name,
         limit=limit) for case, limit in zip(PROFILES["native"], (500, 200, 500, 200, 999), strict=True)}
EARLY = {"cartpole", "pendulum"}


def compare_state(actual, expected):
    # Historical scalar gates predate chunk validity; the native profile checks
    # validity separately. Preserve exact comparisons of every source output.
    if "valid" in actual.keys() and "valid" not in expected.keys():
        assert bool(actual["valid"].all())
        actual = actual.exclude("valid")
    return _compare_state(actual, expected)


def _actions(domain, seed, steps, batch):
    rng = np.random.default_rng(seed)
    shape = (steps, batch, 1)
    if domain in {"cartpole", "acrobot", "mountain_car"}:
        return rng.integers(0, 2 if domain == "cartpole" else 3, shape, dtype=np.int64)
    scale = 2 if domain == "pendulum" else 1
    return rng.uniform(-scale, scale, shape).astype(np.float32)


def _zero(domain, batch):
    if domain in {"acrobot", "mountain_car"}:
        return np.ones((batch, 1), np.int64)
    return np.zeros((batch, 1), np.int64 if domain == "cartpole" else np.float32)

'''
s=header
for name in ['_assert_independent_snapshot','_assert_lossy_rejected','_candidate_restore_against_uninterrupted_reference','_lifecycle_boundary','_terminal_and_reward','_assert_default_float32_writes','_continuous_dtype_flag_necessity']:
 s+=func(remaining,name)
for name in ['_cartpole_terminal','_pendulum_rewards']:s+=func(first,name)
s+=func(first,'_action_semantics','_early_action_semantics')+func(remaining,'_action_semantics','_remaining_action_semantics')
s+=func(remaining,'_variation_values')
a=s.index('    if domain == "acrobot":',s.index('def _variation_values'))
s=s[:a]+'''    if domain == "cartpole":
        return dict(gravity=12.25, masscart=1.25, masspole=0.25, length=0.625, force_mag=12.5, tau=0.03)
    if domain == "pendulum":
        return dict(g=12.5, m=1.25, l=0.75, max_torque=3.0, max_speed=10.0, dt=0.075)
'''+s[a:]
s+=func(remaining,'_physical_variation')
s=s.replace('NativeClassicRemainingReference','NativeClassicReference')
s+='''def run_case(domain, batch, device):
    case = CASES[domain]
    ref = NativeClassicReference(domain, batch)
    records = []
    with se.make(case["stable_env"], num_envs=batch, device=device) as env, \\
         se.make(case["stable_env"], num_envs=batch, device=device) as other:
        try:
            assert env.execution_mode == "DELEGATED_CPU"
            if domain not in EARLY:
                _assert_default_float32_writes(domain, env)
            for seed in (0, 17, 42):
                check_reset_matches_reference(env, ref, seed=seed)
                _assert_independent_snapshot(env, env.get_state())
                actions = _actions(domain, seed + 200, 32, batch)
                check_state_roundtrip(env, actions=actions[:4])
                compare_state(env.get_state(), ref.get_state())
                steps = (check_step_matches_reference(env, ref, actions) if domain in EARLY else
                         _candidate_restore_against_uninterrupted_reference(domain, env, ref, actions))
                other.reset(seed=seed + 991)
                for action in _actions(domain, seed + 991, 9, batch):
                    other.step(action, frames=None)
                resume = env.get_state()
                history = check_two_histories_same_state(env, other, resume, actions[:8])
                frame = env.render(resume)
                assert torch.equal(frame, env._render(env._pack_render_state(resume)))
                before = env.get_state()
                env.render(resume)
                compare_state(env.get_state(), before)
                _assert_lossy_rejected(env, resume)
                check_reset_matches_reference(env, ref, seed=None)
                if domain not in EARLY:
                    custom_ref = NativeClassicReference(domain, batch, options={"low": -.02, "high": .03})
                    try:
                        compare_state(env.reset(seed=seed, options={"low": -.02, "high": .03}),
                                      custom_ref.reset(seed=seed))
                    finally:
                        custom_ref.close()
                records.append(dict(domain=domain, **case, batch=batch, seed=seed,
                    reset=True, unseeded_reset=True, independent_snapshot=True, roundtrip=True,
                    steps=len(steps), two_history_steps=len(history), full_state_render=True, max_error=0.0,
                    **({} if domain in EARLY else dict(custom_reset_bounds=True, candidate_only_restore=True))))
            lifecycle, near_limit = _lifecycle_boundary(domain, env, ref, batch)
            other.reset(seed=701)
            replay = check_two_histories_same_state(env, other, near_limit, _actions(domain, 702, 4, batch))
            terminal = (_cartpole_terminal(env, ref, batch) if domain == "cartpole" else
                        _pendulum_rewards(env, ref, batch) if domain == "pendulum" else
                        _terminal_and_reward(domain, env, ref, batch))
            actions = (_early_action_semantics if domain in EARLY else _remaining_action_semantics)(
                domain, env, ref, batch)
            records.append(dict(domain=domain, batch=batch, **lifecycle, **terminal,
                                boundary_replay_steps=len(replay), action_validation=actions))
        finally:
            ref.close()
    return records


def run_gate(domains, device="cpu"):
    from pathlib import Path
    import stable_worldmodel
    from stable_envs.testing.provenance import pinned_source_identity
    from tests.helpers.reference.profiles import PINS
    from tests.helpers.reference.saved import SWM_PIN

    identity = pinned_source_identity(Path(stable_worldmodel.__file__).resolve().parents[1], SWM_PIN, PINS["native"])
    return dict(source=identity, device=device, execution_mode="DELEGATED_CPU",
                cases=[case for domain in domains for batch in (1, 3) for case in run_case(domain, batch, device)],
                physical_variation={domain: _physical_variation(domain, device) for domain in domains},
                dtype_control=_continuous_dtype_flag_necessity(device) if "mountain_car_continuous" in domains else None)


def main(domains):
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cpu", choices=("cpu", "cuda"))
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    report = run_gate(domains, args.device)
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2)
'''
Path('tests/helpers/reference/native_acceptance.py').write_text(s)
for name,domains in [('native_classic_gate',('cartpole','pendulum')),('native_classic_remaining_gate',('acrobot','mountain_car','mountain_car_continuous'))]:
 Path('scripts/recovery/'+name+'.py').write_text('"""Compatibility CLI for the shared native acceptance witnesses."""\n\nfrom tests.helpers.reference.native_acceptance import main\n\nif __name__ == "__main__":\n    main('+repr(domains)+')\n')
# Existing integration entry points keep their assertions but no longer import scripts.
for name,domains in [('test_native_classic_gate',('cartpole','pendulum')),('test_native_classic_remaining_gate',('acrobot','mountain_car','mountain_car_continuous'))]:
 p=Path('tests/integration/'+name+'.py');s=p.read_text();s=s.replace('from scripts.recovery.'+name.removeprefix('test_')+' import CASES, run_gate','from tests.helpers.reference.native_acceptance import CASES, run_gate');s=s.replace('result = run_gate(os.environ.get(', 'result = run_gate('+repr(domains)+', os.environ.get(');p.write_text(s)
