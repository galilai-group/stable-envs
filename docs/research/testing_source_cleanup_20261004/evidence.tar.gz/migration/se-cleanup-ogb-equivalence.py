import importlib.util,json,copy
from pathlib import Path
import numpy as np
from tests.helpers.reference.bridges import load_source
load_source('/Users/samib/stable-worldmodel','ogbench')
from tests.helpers.reference import ogbench_manipulation_source as new
p=Path('docs/research/semantic_recovery_evidence/ogb_rng_feasibility/ownership.py')
spec=importlib.util.spec_from_file_location('old_ownership',p);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
records=[]
for family in ['Cube','Scene']:
 for seed in [0,17,42]:
  a,b=getattr(old,'Owned'+family)(entropy_seed=seed),getattr(new,'Owned'+family)(entropy_seed=seed)
  try:
   for task in [None,1,2,3,4,5,'custom']:
    options={} if task is None else {'task_id':task}
    if task=='custom':options={'task_info':copy.deepcopy(a.task_infos[2])}
    if task==3:options['variation']=['cube.size','agent.ee_start_position']
    if task==4:options.update(variation=[],variation_values={'cube.size':[.025],'cube.color':[[.1,.8,.4]],'agent.ee_start_position':np.array([.42,.03,.29])})
    if task==5:options['variation']=['floor.color','agent.color','camera.angle_delta','light.intensity']
    x,y=a.reset(seed=seed,options=copy.deepcopy(options)),b.reset(seed=seed,options=copy.deepcopy(options))
    assert not new.differences(old.result(a,x),new.result(b,y))
    actions=np.concatenate([np.eye(5),-np.eye(5),np.array([[2.,-3.,.6,4.,-2.],[.3,-.7,-.8,.9,1.]])])
    for i,action in enumerate(actions):
     action=action.astype(np.float32 if i%2 else np.float64)
     x,y=a.step(action),b.step(action)
     assert not new.differences(old.result(a,x),new.result(b,y))
    records.append(dict(family=family,seed=seed,task=task,status='EXACT',steps=len(actions)))
  finally:a.close();b.close()
Path('/private/tmp/se-cleanup-ogb-equivalence.json').write_text(json.dumps(records,indent=2)+'\n')
print('EXACT',len(records))
