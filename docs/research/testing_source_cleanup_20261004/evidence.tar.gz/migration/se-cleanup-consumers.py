from pathlib import Path
import re
p=Path('scripts/benchmarks/renderer_table/special.py');s=p.read_text();start=s.index('        path = ROOT / "docs/research/semantic_recovery_evidence/ogb_rng_feasibility/ownership.py"');end=s.index('        self.source =',start);s=s[:start]+'        from tests.helpers.reference.ogbench_manipulation_semantics import load_oracle\n\n        self.module = load_oracle()\n'+s[end:];s=s.replace('import importlib.util\n','').replace('from .common import ROOT, state_hash','from .common import state_hash').replace('tests.unit.test_ogbench_manipulation_cpu','tests.helpers.reference.ogbench_manipulation_semantics').replace('tests/unit/test_ogbench_manipulation_cpu.py:assert_oracle','tests/helpers/reference/ogbench_manipulation_semantics.py:assert_oracle').replace('scripts.recovery.rocket_feasibility','tests.helpers.reference.rocket_semantics').replace('scripts/recovery/rocket_feasibility.py:capture/differences','tests/helpers/reference/rocket_semantics.py:capture/differences');p.write_text(s)
p=Path('scripts/recovery/ogbench_renderer_gate.py');s=p.read_text();start=s.index('def owned_oracle():');end=s.index('\n\ndef baseline_frame',start);s=s[:start]+'def owned_oracle():\n    from tests.helpers.reference.ogbench_manipulation_semantics import load_oracle\n\n    return load_oracle()\n'+s[end:];s=s.replace('import importlib.util\n','');p.write_text(s)
for p in Path('scripts/benchmarks/online_stepping').glob('ogbench_source_*.py'):
 s=p.read_text().replace('docs/research/semantic_recovery_evidence/ogb_rng_feasibility/ownership.py','tests/helpers/reference/ogbench_manipulation_source.py').replace('docs/research/semantic_recovery_evidence/ogb_manipulation_preflight/probe.py','tests/helpers/reference/ogbench_manipulation_semantics.py').replace('tests/unit/test_ogbench_manipulation_cpu.py','tests/helpers/reference/ogbench_manipulation_semantics.py')
 # Deduplicate the identical helper after replacing its former unit-test home.
 lines=s.splitlines(True); seen=set();out=[]
 for line in lines:
  if 'Path(' in line and 'tests/helpers/reference/ogbench_manipulation_semantics.py' in line:
   if line.strip() in seen:continue
   seen.add(line.strip())
  out.append(line)
 p.write_text(''.join(out))
p=Path('scripts/benchmarks/online_stepping/classic_source_pipeline.py');s=p.read_text().replace('from tests.helpers.reference.native_classic_semantics import NativeClassicReference as NativeClassicRemainingReference\n','').replace('    cls = NativeClassicReference if domain in ("cartpole", "pendulum") else NativeClassicRemainingReference\n    ref = cls(domain, num_envs=batch)','    ref = NativeClassicReference(domain, num_envs=batch)').replace('             Path("tests/helpers/reference/native_classic_semantics.py"),\n','');p.write_text(s)
# Preserve legacy command entry points, but direct live oracle imports to helpers.
for p in Path('scripts/research_rocket_production').glob('*.py'):
 s=p.read_text();new=s.replace('from rocket_feasibility import', 'from tests.helpers.reference.rocket_semantics import')
 if new!=s:
  # All gates hash the driver; add the extracted oracle wherever a candidate path list exists.
  new=new.replace('    paths = [\n','    paths = [\n        ROOT / "tests/helpers/reference/rocket_semantics.py",\n')
  new=new.replace('    files = list(ROOT.glob(', '    files = [ROOT / "tests/helpers/reference/rocket_semantics.py"] + list(ROOT.glob(')
  p.write_text(new)
for p in [Path('scripts/recovery/rocket_feasibility.py'),Path('scripts/research_replay/pusht_replay_gate.py'),Path('scripts/benchmarks/online_stepping/fetch_source_pipeline.py'),Path('scripts/benchmarks/online_stepping/fetch_source_render_lifecycle.py')]:
 s=re.sub(r'\n{4,}','\n\n\n',p.read_text());p.write_text(s)
# Seal the newly extracted Fetch oracle in active source benchmark reports.
for name in ['fetch_source_pipeline','fetch_source_transport_gate','fetch_source_cpu_prerequisite','fetch_source_frame_gate']:
 p=Path(f'scripts/benchmarks/online_stepping/{name}.py');s=p.read_text();s=s.replace("Path('scripts/recovery/fetch_public_gate.py')", "Path('tests/helpers/reference/fetch_semantics.py'), Path('scripts/recovery/fetch_public_gate.py')");p.write_text(s)
p=Path('scripts/benchmarks/online_stepping/fetch_source_render_lifecycle.py');s=p.read_text().replace('        generator_sha256=',"        helper_sha256=hashlib.sha256(Path('tests/helpers/reference/fetch_semantics.py').read_bytes()).hexdigest(),\n        generator_sha256=");p.write_text(s)
for name in ['pusht_adapter_gate','pusht_reset_anchor_gate']:
 p=Path(f'scripts/research_replay/{name}.py');s=p.read_text();s=s.replace('        helper_sha256=', '        source_helper_sha256=hashlib.sha256((ROOT / "tests/helpers/reference/pusht_semantics.py").read_bytes()).hexdigest(),\n        helper_sha256=');p.write_text(s)
