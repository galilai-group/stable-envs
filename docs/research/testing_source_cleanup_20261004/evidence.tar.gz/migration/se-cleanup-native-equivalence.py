import importlib.util,json
from pathlib import Path
import numpy as np
from tests.helpers.reference.bridges import load_source
from tests.helpers.reference.native_classic_semantics import NativeClassicReference
from tests.helpers.reference.profiles import PROFILES
from tests.helpers.reference.semantics import compare_state
load_source('/Users/samib/stable-worldmodel','native')
modules=[]
for name in ['native_classic_semantics','native_classic_remaining_semantics']:
 path=Path('/private/tmp/se-cleanup-f49a6816-baseline')/(name+'.py')
 spec=importlib.util.spec_from_file_location('old_'+name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules.append(m)
results=[]
for case in PROFILES['native']:
 cls=modules[0].NativeClassicReference if case.domain in ['cartpole','pendulum'] else modules[1].NativeClassicRemainingReference
 for seed in [0,17,42]:
  a,b=cls(case.domain,3),NativeClassicReference(case.domain,3)
  try:
   compare_state(a.reset(seed),b.reset(seed))
   rng=np.random.default_rng(seed)
   actions=rng.integers(0,2 if case.domain=='cartpole' else 3,(32,3,1)) if case.dtypes==('int64',) else rng.uniform(-.2,.2,(32,3,1))
   for action in actions:compare_state(a.step(action),b.step(action))
   state=a.get_state();a.reset(seed+100);b.reset(seed+200);a.set_state(state);b.set_state(state)
   compare_state(a.get_state(),b.get_state())
   for action in actions[:8]:compare_state(a.step(action),b.step(action))
   compare_state(a.reset(None),b.reset(None))
   results.append(dict(domain=case.domain,seed=seed,status='EXACT'))
  finally:a.close();b.close()
Path('/private/tmp/se-cleanup-native-equivalence.json').write_text(json.dumps(results,indent=2)+'\n')
print('EXACT',len(results))
