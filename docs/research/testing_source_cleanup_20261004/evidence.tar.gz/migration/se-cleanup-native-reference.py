from pathlib import Path
import ast,shutil,subprocess
base=Path('/private/tmp/se-cleanup-f49a6816-baseline')
a=Path('tests/helpers/reference/native_classic_semantics.py');b=Path('tests/helpers/reference/native_classic_remaining_semantics.py')
for p in [a,b]:shutil.copyfile(p,base/p.name)
s=a.read_text();other=b.read_text();ns={};exec(compile(other,str(b),'exec'),ns)
# Use the old source-derived field dictionaries, never a candidate schema.
start=s.index('WRAPPERS =');end=s.index('\n\ndef _limbs',start)
header='''WRAPPERS = {
    "cartpole": ("cartpole", "CartPoleWrapper"),
    "pendulum": ("pendulum", "PendulumWrapper"),
    "acrobot": ("acrobot", "AcrobotWrapper"),
    "mountain_car": ("mountain_car", "MountainCarWrapper"),
    "mountain_car_continuous": ("mountain_car", "MountainCarContinuousWrapper"),
}
PHYSICAL = {
    "cartpole": ("x", "x_dot", "theta", "theta_dot"),
    "pendulum": ("theta", "theta_dot"),
    "acrobot": ("theta1", "theta2", "dtheta1", "dtheta2"),
    "mountain_car": ("position", "velocity"),
    "mountain_car_continuous": ("position", "velocity"),
}
COMMON = {
    ("lifecycle", "elapsed_steps"): (1, torch.int64),
    ("rng", "state"): (4, torch.int64),
    ("rng", "increment"): (4, torch.int64),
    ("rng", "has_uint32"): (1, torch.int64),
    ("rng", "uinteger"): (1, torch.int64),
}
FIELDS = {domain: {**{key: (1, torch.float64) for key in fields}, **COMMON}
          for domain, fields in PHYSICAL.items()}
FIELDS["cartpole"].update({("task", "steps_beyond_terminated"): (1, torch.int64),
                          ("task", "has_steps_beyond_terminated"): (1, torch.bool)})
FIELDS["pendulum"].update({"torque": (1, torch.float64), ("task", "has_last_u"): (1, torch.bool)})
FIELDS["mountain_car_continuous"][("task", "state_is_float32")] = (1, torch.bool)
'''
s=s[:start]+header+s[end:]
start=s.index('            if self.domain == "cartpole":',s.index('    def get_state'))
end=s.index('            row = TensorDict',start)
s=s[:start]+'''            physical = np.asarray(base.state)
            values.update(dict(zip(PHYSICAL[self.domain], physical, strict=True)))
            if self.domain == "cartpole":
                beyond = base.steps_beyond_terminated
                values[("task", "steps_beyond_terminated")] = [0 if beyond is None else beyond]
                values[("task", "has_steps_beyond_terminated")] = [beyond is not None]
            elif self.domain == "pendulum":
                last_u = getattr(base, "last_u", None)
                values["torque"] = [0.0 if last_u is None else last_u]
                values[("task", "has_last_u")] = [last_u is not None]
            elif self.domain == "mountain_car_continuous":
                values[("task", "state_is_float32")] = [physical.dtype == np.float32]
'''+s[end:]
start=s.index('            if self.domain == "cartpole":',s.index('    def set_state'));end=s.index('            env._elapsed_steps',start)
s=s[:start]+'''            dtype = (np.float32 if self.domain == "mountain_car_continuous"
                     and row["task", "state_is_float32"].item() else np.float64)
            base.state = np.asarray([row[name].item() for name in PHYSICAL[self.domain]], dtype=dtype)
            if self.domain == "cartpole":
                base.steps_beyond_terminated = (row["task", "steps_beyond_terminated"].item()
                    if row["task", "has_steps_beyond_terminated"].item() else None)
            elif self.domain == "pendulum":
                base.last_u = np.float64(row["torque"].item()) if row["task", "has_last_u"].item() else None
'''+s[end:]
s=s.replace('if self.domain == "cartpole":\n            return [actions','if self.domain in {"cartpole", "acrobot", "mountain_car"}:\n            return [actions');a.write_text(s)
# Existing public helper users keep their local spelling while sharing one implementation.
for name in subprocess.check_output(['git','ls-files','tests','scripts'],text=True).splitlines():
 p=Path(name)
 if p.suffix!='.py' or p==b:continue
 s=p.read_text().replace('from tests.helpers.reference.native_classic_remaining_semantics import NativeClassicRemainingReference','from tests.helpers.reference.native_classic_semantics import NativeClassicReference as NativeClassicRemainingReference')
 s=s.replace('             Path("tests/helpers/reference/native_classic_remaining_semantics.py"),\n','').replace('Path("tests/helpers/reference/native_classic_remaining_semantics.py")','Path("tests/helpers/reference/native_classic_semantics.py")')
 p.write_text(s)
b.unlink()
p=Path('tests/helpers/reference/bridges.py');s=p.read_text();start=s.index('        from tests.helpers.reference.native_classic_semantics');end=s.index('\n    def reset',start);s=s[:start]+'''        from tests.helpers.reference.native_classic_semantics import NativeClassicReference

        self.source = NativeClassicReference(case.domain, batch)
'''+s[end:];p.write_text(s)
p=Path('scripts/benchmarks/renderer_table/bridges.py');s=p.read_text();start=s.index('            early =');end=s.index('        elif name in NAV:',start);s=s[:start]+'            module, cls, args = "native_classic_semantics", "NativeClassicReference", [CLASSIC[name]]\n'+s[end:];p.write_text(s)
