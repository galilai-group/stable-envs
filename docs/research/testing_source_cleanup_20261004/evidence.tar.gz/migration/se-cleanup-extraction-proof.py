import ast,hashlib,json
from pathlib import Path
base=Path('/private/tmp/se-cleanup-f49a6816-baseline');dest=Path('tests/helpers/reference');records=[]
class UnqualifyPrevious(ast.NodeTransformer):
 def visit_Attribute(self,node):
  if isinstance(node.value,ast.Name) and node.value.id=='previous':return ast.copy_location(ast.Name(id=node.attr,ctx=node.ctx),node)
  return self.generic_visit(node)
def definitions(path):
 result={}
 for node in ast.parse(path.read_text()).body:
  if isinstance(node,(ast.FunctionDef,ast.ClassDef)):result[node.name]=node
  elif isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name):result[node.targets[0].id]=node
 return result
for new,old,names in [
 ('fetch_semantics','fetch_source_render_lifecycle',['snapshot','differences']),
 ('fetch_semantics','fetch_source_pipeline',['source_state']),
 ('rocket_semantics','rocket_feasibility',['ENV_FIELDS','AVIARY_FIELDS','DRONE_FIELDS','objects','capture','differences']),
 ('pusht_semantics','pusht_replay_gate',['equal','diagnostics']),
 ('ogbench_manipulation_source','probe',['PARTS','PYTHON_FIELDS','CACHE_FIELDS','MODEL_FIELDS','encode','engine','differences']),
 ('ogbench_manipulation_source','ownership',['GETTER','BOX_SAMPLE','spaces','space_state','OwnedVariation','Ownership','OwnedCube','OwnedScene','capture','result']),
]:
 a,b=definitions(base/(old+'.py')),definitions(dest/(new+'.py'))
 for name in names:
  left=ast.dump(UnqualifyPrevious().visit(a[name]),include_attributes=False);right=ast.dump(b[name],include_attributes=False)
  assert left==right,(old,new,name)
  records.append(dict(original=old,replacement=new,symbol=name,status='IDENTICAL_AST',ast_sha256=hashlib.sha256(left.encode()).hexdigest()))
Path('/private/tmp/se-cleanup-extraction-proof.json').write_text(json.dumps(records,indent=2)+'\n')
print('IDENTICAL_AST',len(records))
