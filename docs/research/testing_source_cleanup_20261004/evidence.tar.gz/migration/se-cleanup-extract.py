import ast,shutil
from pathlib import Path
base=Path('/private/tmp/se-cleanup-f49a6816-baseline')
def extract(path,names):
    p=Path(path);s=p.read_text();lines=s.splitlines(keepends=True);nodes=[]
    for n in ast.parse(s).body:
        name=getattr(n,'name',None)
        if isinstance(n,ast.Assign):name=getattr(n.targets[0],'id',None)
        if name in names:nodes.append(n)
    assert len(nodes)==len(names),(path,names)
    return ''.join(''.join(lines[n.lineno-1:n.end_lineno])+'\n\n' for n in nodes),nodes
def move(path,names,header,dest):
    p=Path(path);shutil.copyfile(p,base/p.name)
    code,nodes=extract(path,names);lines=p.read_text().splitlines(keepends=True)
    for n in reversed(nodes):del lines[n.lineno-1:n.end_lineno]
    p.write_text(''.join(lines))
    Path(dest).write_text(header+'\n\n'+code)
    return p
p=move('scripts/recovery/rocket_feasibility.py',['ENV_FIELDS','AVIARY_FIELDS','DRONE_FIELDS','objects','capture','differences'], '"""Independent pinned-source Rocket engine, actuator, lifecycle and RNG capture."""\n\nimport numpy as np\nfrom stable_worldmodel.envs.rocket_landing.pyflyt_rocketlanding import RocketLandingEnv  # noqa: F401', 'tests/helpers/reference/rocket_semantics.py')
s=p.read_text().replace('from stable_worldmodel.envs.rocket_landing.pyflyt_rocketlanding import RocketLandingEnv','from tests.helpers.reference.rocket_semantics import RocketLandingEnv, capture, differences, objects');p.write_text(s)
p=move('scripts/research_replay/pusht_replay_gate.py',['equal','diagnostics'],'"""Independent source PushT native-engine and entropy witnesses."""\n\nimport copy\nimport numpy as np','tests/helpers/reference/pusht_semantics.py')
s=p.read_text().replace('import numpy as np','import numpy as np\n\nfrom tests.helpers.reference.pusht_semantics import diagnostics, equal');p.write_text(s)
p=move('scripts/benchmarks/online_stepping/fetch_source_render_lifecycle.py',['snapshot','differences'],'"""Independent pinned Fetch snapshots and public-State field extraction."""\n\nimport copy\nimport gymnasium as gym\nimport numpy as np\nimport torch\nfrom tensordict import TensorDict','tests/helpers/reference/fetch_semantics.py')
s=p.read_text().replace('import copy\n','').replace('from gymnasium.envs.mujoco.mujoco_rendering import MujocoRenderer','from gymnasium.envs.mujoco.mujoco_rendering import MujocoRenderer\nfrom tests.helpers.reference.fetch_semantics import snapshot, differences');p.write_text(s)
p=Path('scripts/benchmarks/online_stepping/fetch_source_pipeline.py');shutil.copyfile(p,base/p.name);code,nodes=extract(p,['source_state']);dest=Path('tests/helpers/reference/fetch_semantics.py');dest.write_text(dest.read_text()+code);lines=p.read_text().splitlines(keepends=True)
for n in reversed(nodes):del lines[n.lineno-1:n.end_lineno]
p.write_text(''.join(lines).replace('from tensordict import TensorDict','from tensordict import TensorDict\nfrom tests.helpers.reference.fetch_semantics import source_state'))
p=Path('tests/helpers/reference/bridges.py');s=p.read_text().replace('scripts.research_replay.pusht_replay_gate','tests.helpers.reference.pusht_semantics').replace('scripts.recovery.rocket_feasibility','tests.helpers.reference.rocket_semantics').replace('        from scripts.benchmarks.online_stepping.fetch_source_pipeline import source_state\n        from scripts.benchmarks.online_stepping.fetch_source_render_lifecycle import snapshot','        from tests.helpers.reference.fetch_semantics import snapshot, source_state');p.write_text(s)
# Extract only the authoritative ownership/capture code used by active gates.
ownership='docs/research/semantic_recovery_evidence/ogb_rng_feasibility/ownership.py'
probe='docs/research/semantic_recovery_evidence/ogb_manipulation_preflight/probe.py'
for name in [ownership,probe]:shutil.copyfile(name,base/Path(name).name)
code,_=extract(probe,['PARTS','PYTHON_FIELDS','CACHE_FIELDS','MODEL_FIELDS','encode','engine','differences'])
owned,_=extract(ownership,['GETTER','BOX_SAMPLE','spaces','space_state','OwnedVariation','Ownership','OwnedCube','OwnedScene','capture','result'])
header='''"""Independent source-owned entropy and engine capture for Cube/Scene.

Extracted from the accepted source-only ownership experiment; source reset, task,
physics and rendering still delegate to the pinned SWM/OGBench implementations.
Archived experiment scripts are evidence, never runtime imports.
"""

import copy
import gymnasium as gym
import mujoco
import numpy as np
from ogbench.manipspace.envs.manipspace_env import ManipSpaceEnv
from stable_worldmodel import spaces as swm_spaces
from stable_worldmodel.envs.ogbench.cube_env import CubeEnv
from stable_worldmodel.envs.ogbench.scene_env import SceneEnv

'''
Path('tests/helpers/reference/ogbench_manipulation_source.py').write_text(header+code+owned.replace('previous.',''))
p=Path('tests/helpers/reference/ogbench_manipulation_semantics.py');s=p.read_text();a=s.index('import importlib.util');b=s.index('\ndef numpy_equal',a);s=s[:a]+'import numpy as np\n\n'+s[b:];a=s.index('    path = ROOT',s.index('def load_oracle'));b=s.index('\n\ndef assert_oracle',a);s=s[:a]+'    from tests.helpers.reference import ogbench_manipulation_source\n\n    return ogbench_manipulation_source\n'+s[b:];p.write_text(s.replace('oracle.previous.','oracle.'))
for name in ['tests/unit/test_ogbench_manipulation_cpu.py','scripts/benchmarks/online_stepping/ogbench_source_prerequisite.py']:
 p=Path(name);s=p.read_text().replace('oracle.previous.','oracle.').replace('module.previous.','module.');p.write_text(s)
p=Path('tests/contracts/conftest.py');s=p.read_text();a=s.index('            paths += [\n                root / name');b=s.index('            manifest_path =',a);p.write_text(s[:a]+s[b:])
