import hashlib,json,os,platform,subprocess,sys
from pathlib import Path
base,run=map(Path,sys.argv[1:3]);profile=sys.argv[3]
manifest=json.loads((base/'manifest.json').read_text())
for name,digest in manifest['files'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
import torch
from stable_envs.testing.evidence import verify_seal
assert torch.cuda.is_available()
(run/'identity.json').write_text(json.dumps(dict(commit=manifest['commit'],profile=profile,host=platform.node(),gpu=torch.cuda.get_device_name(),cuda=torch.version.cuda,job=os.environ['SLURM_JOB_ID'],verified_files=len(manifest['files'])),indent=2)+'\n')
processes=[]
statuses=[]
for device in ('cpu','cuda'):
    command=[sys.executable,'-m','pytest','-q','-rs',*[f'tests/contracts/test_{axis}.py' for axis in (('state','simulation','task','online','native_acceptance') if profile=='native' else ('state','simulation','task','online'))],'--contract-profile',profile,'--contract-device',device,'--contract-source','/oscar/scratch/sboughan/se-semantic-recovery/swm-reference','--contract-candidate-manifest',str(base/'manifest.json'),'--contract-output',str(run/device),'--junitxml='+str(run/(device+'.xml'))]
    log=(run/(device+'.log')).open('w')
    processes.append((device,subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT),log))
for device,process,log in processes:
    status=process.wait();log.close();statuses.append(status)
    (run/(device+'-exit.txt')).write_text(str(status)+'\n')
    if (run/device/'SHA256SUMS').exists():verify_seal(run/device)
    print(profile,device,'exit',status,flush=True)
assert statuses==[0,0],statuses
if profile == 'native':
    import xml.etree.ElementTree as ET
    command=[sys.executable,'-m','pytest','-q','-rs','tests/unit/test_classic_state_export.py','--junitxml='+str(run/'classic-export.xml')]
    with (run/'classic-export.log').open('w') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    suites=ET.parse(run/'classic-export.xml').getroot()
    assert sum(int(s.attrib['tests']) for s in suites)==10
    assert all(int(s.attrib[k])==0 for s in suites for k in ('failures','errors','skipped'))
print('SHARED_PROFILE_CPU_CUDA_PASS',profile,flush=True)
