#!/bin/bash
#SBATCH --job-name=se-source-cleanup
#SBATCH --partition=gpu
#SBATCH --qos=norm-gpu
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=24G
#SBATCH --time=00:30:00
#SBATCH --exclude=gpu3001
#SBATCH --no-requeue
#SBATCH --array=0-6%2
#SBATCH --output=/oscar/scratch/sboughan/se-semantic-recovery/source-cleanup-d13741c4/job-%A_%a.log
set -euo pipefail
BASE=/oscar/scratch/sboughan/se-semantic-recovery/source-cleanup-d13741c4
PROFILES=(native fetch dmc navigation ogbench pusht rocket)
PROFILE=${PROFILES[$SLURM_ARRAY_TASK_ID]}
RUN="$BASE/results/${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}"
mkdir -p "$RUN/code" "$RUN/cache"
tar -xzf "$BASE/code.tar.gz" -C "$RUN/code"
cd "$RUN/code"
V=/oscar/scratch/sboughan/venvs
PY="$V/se6-verify-vis311/bin/python"
DEPS="$V/se-vis311/lib/python3.12/site-packages:$V/se-step6/lib/python3.12/site-packages:$V/se-step4-swm/lib/python3.12/site-packages:$V/se7-rocket/lib/python3.12/site-packages:$V/se7-ogb/lib/python3.12/site-packages"
if [[ "$PROFILE" == dmc || "$PROFILE" == ogbench ]]; then
  DEPS="$V/se-step6/lib/python3.12/site-packages:$DEPS"
fi
if [[ "$PROFILE" == ogbench || "$PROFILE" == pusht ]]; then
  /users/sboughan/.local/bin/uv pip install --python "$PY" --target "$RUN/pins" 'numpy==2.2.6' 'gymnasium==1.2.3' 'pymunk==7.2.0' > "$RUN/install.log" 2>&1
  DEPS="$RUN/pins:$DEPS"
fi
export PYTHONPATH="$PWD:$DEPS"
export XDG_CACHE_HOME="$RUN/cache" CUDA_CACHE_PATH="$RUN/cache/cuda" MPLCONFIGDIR="$RUN/cache/matplotlib"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export SDL_VIDEODRIVER=dummy MUJOCO_GL=egl MPLBACKEND=Agg
nvidia-smi > "$RUN/nvidia-smi.txt"
lscpu > "$RUN/lscpu.txt"
"$PY" "$BASE/validate.py" "$BASE" "$RUN" "$PROFILE"
