import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/Users/samib/stable-envs');base=Path(__file__).parent
commit='d13741c4'
commit=subprocess.check_output(['git','rev-parse',commit],cwd=root,text=True).strip()
names=subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'--','stable_envs','tests','scripts','pyproject.toml'],cwd=root,text=True).splitlines()
files={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
# Verify the source archive itself is exactly the committed tree, not working edits.
with (base/'code.tar').open('wb') as stream:subprocess.run(['git','archive',commit,'--','stable_envs','tests','scripts','pyproject.toml'],cwd=root,stdout=stream,check=True)
with tarfile.open(base/'code.tar') as archive:
 for member in archive:
  if member.isfile():assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==files[member.name],member.name
import gzip,shutil
with (base/'code.tar').open('rb') as source,gzip.open(base/'code.tar.gz','wb') as target:shutil.copyfileobj(source,target)
(base/'code.tar').unlink()
(base/'manifest.json').write_text(json.dumps(dict(commit=commit,tracked_dirty=False,files=files),indent=2)+'\n')
print(commit,len(files),(base/'code.tar.gz').stat().st_size)
