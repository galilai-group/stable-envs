import json,os,subprocess,sys
from pathlib import Path
base=Path(__file__).parent
manifest=base/'submission/manifest.json'
python='/private/tmp/se-completion-312/bin/python'
processes=[];commands={}
for profile in ['native','fetch','pusht','rocket']:
 env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',SDL_VIDEODRIVER='dummy')
 env['PYTHONPATH']='.' if profile=='pusht' else '/private/tmp/se-contract-source-deps-20261004:/private/tmp/se-testing-docs-20261004/lib/python3.12/site-packages:.'
 files=[f'tests/contracts/test_{axis}.py' for axis in ['state','simulation','task','online']]
 if profile=='native':files+=['tests/contracts/test_native_acceptance.py']
 command=[python,'-m','pytest','-q','-rs',*files,'--contract-profile',profile,'--contract-source','/Users/samib/stable-worldmodel','--contract-candidate-manifest',str(manifest),'--contract-output',str(base/profile)]
 commands[profile]=dict(command=command,environment={key:env[key] for key in ['PYTHONPATH','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','SDL_VIDEODRIVER']})
 log=(base/(profile+'.log')).open('x');processes.append((profile,subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT),log))
(base/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
statuses=[]
for profile,process,log in processes:
 code=process.wait();log.close();statuses.append(code)
 (base/(profile+'-exit.txt')).write_text(str(code)+'\n');print(profile,code,flush=True)
assert statuses==[0]*4,statuses
