import importlib.util,json
from pathlib import Path
import numpy as np
from tests.helpers.reference.bridges import load_source
from tests.helpers.reference.dmc_semantics import DMCReference
from tests.helpers.reference.profiles import PROFILES
from tests.helpers.reference.semantics import compare_state
load_source('/Users/samib/stable-worldmodel','dmc')
modules={}
for name in ['reacher','dmc_first_family','dmc_continuation','dmc_aligned','dmc_humanoid']:
 spec=importlib.util.spec_from_file_location('baseline_'+name,Path('/private/tmp/se38-baseline-oracles')/(name+'_semantics.py'))
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);modules[name]=module
results=[]
for case in PROFILES['dmc']:
 domain=case.domain
 if domain=='reacher': old=modules['reacher'].ReacherReference(2)
 elif domain=='humanoid':old=modules['dmc_humanoid'].DMCHumanoidReference(2)
 elif domain in ['acrobot','pendulum','cartpole']:old=modules['dmc_first_family'].DMCFirstFamilyReference(domain,2)
 elif domain in ['cheetah','hopper','walker']:old=modules['dmc_continuation'].DMCContinuationReference(domain,2)
 else:old=modules['dmc_aligned'].DMCAlignedReference(domain,2)
 new=DMCReference(domain,2)
 try:
  for seed in [17,42]:
   compare_state(new.reset(seed),old.reset(seed))
   actions=np.random.default_rng(seed).uniform(-.2,.2,(16,2,case.width))
   for a in actions:compare_state(new.step(a),old.step(a))
   saved=old.get_state()
   new.reset(seed+100);old.reset(seed+99)
   new.set_state(saved);old.set_state(saved)
   compare_state(new.get_state(),old.get_state())
   for a in actions[:8]:compare_state(new.step(a),old.step(a))
   # Internal automatic reset boundary and cached Gaussian entropy.
   saved=old.get_state();saved['lifecycle','step_count'][0]=new.step_limit-1
   saved['lifecycle','reset_next_step'][1]=True
   saved['rng','has_gauss'].fill_(True);saved['rng','cached_gaussian'].fill_(.125)
   old.set_state(saved);new.set_state(saved)
   for a in actions[:3]:compare_state(new.step(a),old.step(a))
   results.append(dict(domain=domain,seed=seed,status='EXACT'))
  print(domain,'PASS',flush=True)
 finally:old.close();new.close()
Path('/private/tmp/se38-dmc-equivalence.json').write_text(json.dumps(results,indent=2)+'\n')
